import React, { useState, useCallback, useEffect, useMemo } from 'react';
import { ViewMode } from './types';
import { BreathConfig } from './services/audio/AudioTypes';
import { DEFAULT_UI_CONFIG, UIConfig, StyleContext, StyleEditor } from './components/system/StyleEditor';
import { PlanetaryTunerModule } from './components/modules/PlanetaryTunerModule';

const STATIC_METRICS: Record<string, unknown> = {
  coherenceScore: 0.85,
  dominantFreq: 0.1,
  lfHfRatio: 1.0,
  spectralState: 'HARMONIC_LOCKED',
  stateDescription: 'Pure Harmonic Aether Resonance',
  stateColor: '#06b6d4',
  vagalTone: 0.8,
  stressIndex: 12,
  alphaPower: 0.75,
  thetaPower: 0.65,
  entropy: 0.15,
};

export const App: React.FC = () => {
  const [viewMode, setViewMode] = useState<ViewMode>('PLAYER');
  const [uiConfig, setUiConfig] = useState<UIConfig>(() => DEFAULT_UI_CONFIG);
  const [showStyleEditor, setShowStyleEditor] = useState(false);
  const [, setShowInfo] = useState(false);

  const [isVisualizerImmersion, setIsVisualizerImmersion] = useState(false);

  const handleBreathConfigChange = useCallback((config: BreathConfig) => {
    // Pure sound & breath pace handler
  }, []);

  useEffect(() => {
    document.documentElement.style.fontSize = `${(uiConfig.textScale || 1.0) * 100}%`;
  }, [uiConfig.textScale]);

  const mode = useMemo(() => ({
    card: 'bg-[#0b0e14]/80',
    text: 'text-slate-200',
    heading: 'text-white',
    subtext: 'text-slate-400',
    muted: 'text-slate-500',
    iconBg: 'bg-white/5',
    modalBg: 'bg-slate-950',
    modalBorder: 'border-white/10',
    dockBar: 'bg-slate-900/90 border-t border-slate-800',
    bg: 'bg-[#020617]'
  }), []);

  const theme = useMemo(() => ({
    primary: `text-[${uiConfig.primaryColor}]`,
    bg: `bg-[${uiConfig.primaryColor}]`,
    border: `border-[${uiConfig.primaryColor}]`,
    hex: uiConfig.primaryColor
  }), [uiConfig.primaryColor]);

  return (
    <StyleContext.Provider value={uiConfig}>
      <div
        className="absolute inset-0 w-full h-full overflow-hidden flex flex-col overscroll-none"
        style={{
          backgroundColor: uiConfig.appBgColor,
          fontFamily: uiConfig.fontTheme === 'SPIRITUAL' ? 'Cinzel, serif' : uiConfig.fontTheme === 'CYBER' ? 'Share Tech Mono, monospace' : 'Space Grotesk, sans-serif'
        }}
      >
        <div className="flex-1 relative overflow-hidden min-h-0 w-full flex flex-col">
          <PlanetaryTunerModule
            id="tuner"
            index={0}
            metrics={STATIC_METRICS}
            bpm={60}
            coherence={0.88}
            lastBeatTime={0}
            mode={mode}
            theme={theme}
            isDarkMode={true}
            isMinimized={false}
            viewMode={viewMode}
            sensorMode="AETHER"
            isPowered={true}
            standalone={true}
            isSimulating={false}
            isCoherenceSimulated={false}
            onToggleMinimize={() => {}}
            onTogglePower={() => {}}
            onDragStart={() => {}}
            onDragOver={() => {}}
            onDrop={() => {}}
            onOpenInfo={() => setShowInfo(true)}
            onBreathConfigChange={handleBreathConfigChange}
            isVisualizerImmersion={isVisualizerImmersion}
            onToggleVisualizerImmersion={(forced?: boolean) => setIsVisualizerImmersion(prev => typeof forced === 'boolean' ? forced : !prev)}
            onToggleViewMode={() => setViewMode(v => v === 'PLAYER' ? 'STUDIO' : 'PLAYER')}
            onOpenStyleEditor={() => setShowStyleEditor(prev => !prev)}
            showStyleEditor={showStyleEditor}
          />
        </div>

        {showStyleEditor && (
          <StyleEditor
            config={uiConfig}
            onChange={setUiConfig}
            onClose={() => setShowStyleEditor(false)}
            onReset={() => setUiConfig(DEFAULT_UI_CONFIG)}
          />
        )}
      </div>
    </StyleContext.Provider>
  );
};