import React, { useState } from 'react';
import { Info, Waves, Music, Atom } from 'lucide-react';
import { UIConfig } from '../../system/StyleEditor';
import { Fader } from '../../ui/Faders';

interface Props {
    audio: Record<string, unknown>; // AudioController
    uiConfig: UIConfig;
}

const InfoBox = ({ title, desc, isOpen }: { title: string, desc: string, isOpen: boolean }) => (
    isOpen ? (
        <div className="col-span-2 p-2 mb-2 bg-white/5 border border-white/10 rounded text-[9px] text-slate-300 leading-relaxed animate-in slide-in-from-top-1">
            <strong className="block text-white mb-1 uppercase tracking-widest">{title}</strong>
            {desc}
        </div>
    ) : null
);

export const CoherenceFeedbackDesigner: React.FC<Props> = ({ 
    audio, uiConfig 
}) => {
    const { feedbackConfig, setFeedbackConfig: onFeedbackChange } = audio;
    const updateFeedback = (key: string, val: unknown) => onFeedbackChange({ ...feedbackConfig, [key]: val });
    const [activeInfo, setActiveInfo] = useState<string | null>(null);

    const toggleInfo = (id: string) => setActiveInfo(activeInfo === id ? null : id);

    return (
        <div className="p-3 border rounded space-y-4" style={{ backgroundColor: `rgba(${uiConfig.cardRgb}, 0.2)`, borderColor: `rgba(${uiConfig.borderRgb}, 0.1)` }}>
            <div className="grid grid-cols-1 gap-3">
                <div className="space-y-1"><div className="flex justify-between text-[8px] uppercase tracking-wide text-slate-400"><span>Smoothing</span><span style={{ color: uiConfig.primaryColor }}>{feedbackConfig.sensitivity.toFixed(2)}</span></div><Fader value={feedbackConfig.sensitivity} min={0.01} max={0.5} step={0.01} onChange={(v:number) => updateFeedback('sensitivity', v)} color="#94a3b8" uiConfig={uiConfig} /></div>
                <div className="space-y-1"><div className="flex justify-between text-[8px] uppercase tracking-wide text-slate-400"><span>Threshold</span><span style={{ color: uiConfig.primaryColor }}>{(feedbackConfig.threshold * 100).toFixed(0)}%</span></div><Fader value={feedbackConfig.threshold} min={0} max={1} step={0.05} onChange={(v:number) => updateFeedback('threshold', v)} color="#facc15" uiConfig={uiConfig} /></div>
                <div className="space-y-1"><div className="flex justify-between text-[8px] uppercase tracking-wide text-slate-400"><span>Depth</span><span style={{ color: uiConfig.primaryColor }}>{(feedbackConfig.depth * 100).toFixed(0)}%</span></div><Fader value={feedbackConfig.depth} min={0} max={1} step={0.05} onChange={(v:number) => updateFeedback('depth', v)} color="#22d3ee" uiConfig={uiConfig} /></div>
            </div>

            <div className="pt-2 border-t border-white/10 grid grid-cols-2 gap-2">
                <div className="col-span-1 flex flex-col gap-1">
                    <div className="flex gap-1"><button onClick={() => updateFeedback('isHarmonicBloom', !feedbackConfig.isHarmonicBloom)} className={`flex-1 p-2 rounded border text-[8px] font-bold flex items-center justify-between gap-2 transition-all ${feedbackConfig.isHarmonicBloom ? 'bg-rose-500/20 text-rose-400 border-rose-500/50' : 'bg-slate-800 text-slate-500 border-slate-700'}`}><div className="flex items-center gap-2"><Waves size={12} /> BLOOM</div><div className={`w-2 h-2 rounded-full ${feedbackConfig.isHarmonicBloom ? 'bg-rose-400 shadow-[0_0_5px_currentColor]' : 'bg-slate-600'}`} /></button><button onClick={() => toggleInfo('bloom')} className="p-2 rounded border border-white/5 hover:bg-white/10 text-slate-500"><Info size={10}/></button></div>
                </div>
                <InfoBox isOpen={activeInfo === 'bloom'} title="Spatial Wanderer" desc="Unlocks the stereo field. Sounds will physically travel around your head (Binaural Panning), slowing down as you enter flow states." />

                <div className="col-span-1 flex flex-col gap-1">
                    <div className="flex gap-1"><button onClick={() => updateFeedback('isAngelChord', !feedbackConfig.isAngelChord)} className={`flex-1 p-2 rounded border text-[8px] font-bold flex items-center justify-between gap-2 transition-all ${feedbackConfig.isAngelChord ? 'bg-amber-500/20 text-amber-400 border-amber-500/50' : 'bg-slate-800 text-slate-500 border-slate-700'}`}><div className="flex items-center gap-2"><Music size={12} /> ANGEL</div><div className={`w-2 h-2 rounded-full ${feedbackConfig.isAngelChord ? 'bg-amber-400 shadow-[0_0_5px_currentColor]' : 'bg-slate-600'}`} /></button><button onClick={() => toggleInfo('angel')} className="p-2 rounded border border-white/5 hover:bg-white/10 text-slate-500"><Info size={10}/></button></div>
                </div>

                <div className="col-span-1 flex flex-col gap-1">
                    <div className="flex gap-1"><button onClick={() => updateFeedback('isCrystallize', !feedbackConfig.isCrystallize)} className={`flex-1 p-2 rounded border text-[8px] font-bold flex items-center justify-between gap-2 transition-all ${feedbackConfig.isCrystallize ? 'bg-cyan-500/20 text-cyan-400 border-cyan-500/50' : 'bg-slate-800 text-slate-500 border-slate-700'}`}><div className="flex items-center gap-2"><Atom size={12} /> CRYSTAL</div><div className={`w-2 h-2 rounded-full ${feedbackConfig.isCrystallize ? 'bg-cyan-400 shadow-[0_0_5px_currentColor]' : 'bg-slate-600'}`} /></button><button onClick={() => toggleInfo('crystal')} className="p-2 rounded border border-white/5 hover:bg-white/10 text-slate-500"><Info size={10}/></button></div>
                </div>

                <div className="col-span-2 grid grid-cols-2 gap-2">
                    <InfoBox isOpen={activeInfo === 'angel'} title="Circadian Rhythm Alignment" desc="Harmonizes sounds to the 'Angel Frequency' series." />
                    <InfoBox isOpen={activeInfo === 'crystal'} title="Hydro-Dynamic Resolution" desc="Modulates water physics. Low Coherence = Turbid noise. High Coherence = Discrete, crystalline droplets." />
                </div>
            </div>
        </div>
    );
};