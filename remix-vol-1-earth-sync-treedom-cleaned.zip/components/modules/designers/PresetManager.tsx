import React, { useState } from 'react';
import { Save, Trash2, Check, Download, Code } from 'lucide-react';
import { usePlanetaryController } from '../../../hooks/usePlanetaryController';
import { HarmonicColorWheelId } from '../../../data/colorWheels';

export interface Preset {
    id: string;
    name: string;
    category: 'FACTORY' | 'USER' | 'AETHER';
    volumes: Record<string, number>;
    mutes: Record<string, boolean>;
    stackMutes?: Record<string, boolean>;
    reverbConfig?: Record<string, unknown>;
    delayConfig?: Record<string, unknown>;
    attackTime?: number;
    releaseTime?: number;
    timestamp?: number;
    binauralFreqs?: Record<string, number>;
    kickConfig?: Record<string, unknown>;
    heartHarmonicVols?: number[];
    heartHarmonicMutes?: boolean[];
    breathConfig?: Record<string, unknown>;
    globalTranspose?: number;
    snakeConfig?: Record<string, unknown>;
    feedbackConfig?: Record<string, unknown>;
    baseAperture?: number;
    immersionConfig?: Record<string, unknown>;
    latticeConfig?: Record<string, unknown>;
    modulations?: Record<string, unknown>;
    modulationMap?: Record<string, unknown>;
    colorWheelId?: HarmonicColorWheelId;
}

interface PresetManagerProps {
    presets: Preset[];
    activePresetId: string | null;
    onLoadPreset: (preset: Preset) => void;
    onDeletePreset: (id: string) => void;
    onOpenSaveModal: () => void;
    uiConfig: Record<string, unknown>;
    controller?: ReturnType<typeof usePlanetaryController>; 
}

export const PresetManager: React.FC<PresetManagerProps> = ({ 
    presets, 
    activePresetId, 
    onLoadPreset, 
    onDeletePreset, 
    onOpenSaveModal, 
    controller 
}) => {
    const [copied, setCopied] = useState(false);

    const handleCopyPresetJSON = () => {
        if (!controller?.loopDataRef?.current) return;
        
        const state = controller.loopDataRef.current;
        
        const exportedPreset: Preset = {
            id: `factory_preset_${Date.now()}`,
            name: "NEW EXPORTED PRESET",
            category: "FACTORY",
            volumes: state.volumes,
            mutes: state.mutes,
            stackMutes: state.stackMutes,
            reverbConfig: state.reverbConfig,
            delayConfig: state.delayConfig,
            attackTime: state.attackTime,
            releaseTime: state.releaseTime,
            binauralFreqs: state.binauralFreqs,
            kickConfig: state.kickConfig,
            heartHarmonicVols: state.heartHarmonicVols,
            heartHarmonicMutes: state.heartHarmonicMutes,
            breathConfig: state.breathConfig,
            globalTranspose: state.globalTranspose,
            snakeConfig: state.snakeConfig,
            feedbackConfig: state.feedbackConfig,
            baseAperture: state.baseAperture,
            immersionConfig: state.immersionConfig,
            latticeConfig: state.latticeConfig,
            modulations: state.modulations,
            modulationMap: state.modMap
        };

        const jsonString = JSON.stringify(exportedPreset, null, 4);
        navigator.clipboard.writeText(jsonString).then(() => {
            setCopied(true);
            setTimeout(() => setCopied(false), 2000);
        });
    };

    return (
        <div className="flex flex-col h-full bg-transparent text-white animate-in slide-in-from-top-4 fade-in duration-300">
            {/* Top Toolbar */}
            <div className="flex items-center justify-between px-4 py-3 border-b border-white/5 bg-black/20 shrink-0">
                <div className="flex items-center gap-3">
                    <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Memory Bank</span>
                    <span className="px-2 py-0.5 rounded-full bg-white/10 text-[9px] font-bold font-mono text-slate-300">{presets.length} slots</span>
                </div>
                
                <div className="flex items-center gap-2">
                    {/* NEW: Developer Copy Button */}
                    {controller && (
                        <button 
                            onClick={handleCopyPresetJSON}
                            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border transition-all active:scale-95 ${copied ? 'bg-emerald-500 border-emerald-400 text-black shadow-[0_0_15px_rgba(16,185,129,0.4)]' : 'bg-black/40 border-white/10 text-slate-300 hover:text-white hover:bg-white/10 hover:border-white/20'}`}
                            title="Developer: Copy Current State as JSON"
                        >
                            {copied ? <Check size={12} className="stroke-[3]" /> : <Code size={12} />}
                            <span className="text-[9px] font-bold uppercase tracking-widest">{copied ? 'JSON COPIED' : 'COPY JSON'}</span>
                        </button>
                    )}

                    {/* Standard User Save Button */}
                    <button 
                        onClick={onOpenSaveModal}
                        className="flex items-center gap-2 px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg transition-all shadow-[0_0_15px_rgba(6,182,212,0.2)] hover:shadow-[0_0_20px_rgba(6,182,212,0.4)] active:scale-95 border border-cyan-400/50"
                    >
                        <Save size={12} />
                        <span className="text-[9px] font-bold uppercase tracking-widest drop-shadow-md">Save State</span>
                    </button>
                </div>
            </div>

            {/* Scrolling Preset List */}
            <div className="flex-1 overflow-y-auto p-4 space-y-2">
                {presets.map(preset => {
                    const isActive = activePresetId === preset.id;
                    const isFactory = preset.category === 'FACTORY';
                    return (
                        <div 
                            key={preset.id}
                            className={`group relative flex items-center justify-between p-3 rounded-xl border transition-all duration-200 cursor-pointer ${isActive ? 'bg-cyan-900/20 border-cyan-500/50 shadow-[0_0_15px_rgba(6,182,212,0.15)]' : 'bg-black/30 border-white/5 hover:bg-white/5 hover:border-white/10'}`}
                            onClick={() => onLoadPreset(preset)}
                        >
                            <div className="flex flex-col min-w-0 pr-4">
                                <div className="flex items-center gap-2 mb-1">
                                    <span className={`text-xs font-bold truncate transition-colors ${isActive ? 'text-cyan-400 drop-shadow-md' : 'text-slate-200 group-hover:text-white'}`}>
                                        {preset.name}
                                    </span>
                                    {isActive && <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse shadow-[0_0_5px_currentColor]" />}
                                </div>
                                <div className="flex items-center gap-2 text-[9px] font-mono">
                                    <span className={`px-1.5 py-0.5 rounded uppercase font-bold tracking-widest ${isFactory ? 'bg-indigo-500/20 text-indigo-400' : 'bg-amber-500/20 text-amber-400'}`}>
                                        {preset.category}
                                    </span>
                                </div>
                            </div>
                            
                            <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                <button 
                                    onClick={(e) => { e.stopPropagation(); onLoadPreset(preset); }}
                                    className={`p-2 rounded-lg transition-colors ${isActive ? 'bg-cyan-500 text-black' : 'bg-white/10 text-slate-300 hover:text-white hover:bg-white/20'}`}
                                >
                                    <Download size={14} />
                                </button>
                                {!isFactory && (
                                    <button 
                                        onClick={(e) => { e.stopPropagation(); onDeletePreset(preset.id); }}
                                        className="p-2 rounded-lg bg-black/50 border border-white/10 text-slate-500 hover:text-rose-400 hover:border-rose-500/30 hover:bg-rose-500/10 transition-colors"
                                    >
                                        <Trash2 size={14} />
                                    </button>
                                )}
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
    );
};