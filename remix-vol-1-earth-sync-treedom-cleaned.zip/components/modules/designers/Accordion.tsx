import React from 'react';
import { Volume2, VolumeX, ChevronDown, ChevronRight, Headphones, Lock, Unlock, Waves, Spline } from 'lucide-react';
import { Fader } from '../../ui/Faders';
import { UIConfig } from '../../system/StyleEditor';
import { KickDesigner } from './KickDesigner';
import { HEART_HARMONIC_DEFS } from '../visuals/shared';

interface ChannelRowProps {
    ch: { id: string; name: string; freq: number; octave?: number; noteLabel?: string; };
    volume: number;
    isMuted: boolean;
    isActive: boolean;
    onVolumeChange: (id: string, vol: number) => void;
    onMuteToggle: (id: string) => void;
    uiConfig: UIConfig;
}

export const ChannelRow = React.memo(({ ch, volume, isMuted, isActive, onVolumeChange, onMuteToggle, uiConfig }: ChannelRowProps) => {
    return (
        <div className={`flex items-center gap-2 py-1 px-2 rounded ${isActive ? 'bg-white/10' : ''}`}>
            <button onClick={() => onMuteToggle(ch.id)} className={isMuted ? 'text-red-400' : 'text-slate-400'}>
                {isMuted ? <VolumeX size={10} /> : <Volume2 size={10} />}
            </button>
            <div className="flex-1">
                <div className="flex justify-between">
                    <span className="text-[9px]" style={{ color: uiConfig.textColor as string }}>{ch.name}</span>
                    <span className="text-[9px] opacity-50" style={{ color: uiConfig.textColor as string }}>{ch.freq.toFixed(2)}Hz</span>
                </div>
                <Fader value={volume} onChange={(v: number) => onVolumeChange(ch.id, v)} color={isActive ? '#22d3ee' : '#64748b'} disabled={isMuted} uiConfig={uiConfig} />
            </div>
        </div>
    );
});

interface AccordionProps {
    type: string;
    color: string;
    title: string;
    channels: { id: string; name: string; freq: number; octave?: number; noteLabel?: string; }[];
    isExpanded: boolean;
    onToggleExpand: (type: string) => void;
    audio: Record<string, unknown>; // AudioController
    temporal: Record<string, unknown>; // TemporalController
    audioSys?: Record<string, unknown>; // AudioSystemController
    activeId: string | null;
    uiConfig: UIConfig;
    bpm?: number;
}

export const Accordion = React.memo((props: AccordionProps) => {
    const { type, color, title, channels, isExpanded, onToggleExpand, audio, temporal, audioSys, activeId, uiConfig, bpm } = props;

    // Destructure domain controllers
    const { volumes, mutes, stackMutes, handleVolumeChange: onVolumeChange, handleMuteToggle: onMuteToggle, handleToggleStackMute, heartHarmonicVols, heartHarmonicMutes, handleHeartHarmonicVolChange, handleHeartHarmonicMuteToggle } = audio;
    const { kickConfig, setKickConfig: onKickConfigChange, kickPresets, activeKickPresetId, handleSelectKickPreset, handleSaveKickPreset, handleDeleteKickPreset, binauralFreqs, binauralLocks, handleBinauralChange, setBinauralLocks, snakeConfig, handleSnakeConfigChange: onSnakeConfigChange } = temporal;

    const isStackMuted = stackMutes[type];
    const binauralFreq = binauralFreqs[type];
    const isBinauralLocked = binauralLocks[type];
    
    const onBinauralLockToggle = () => setBinauralLocks((prev: Record<string, boolean>) => ({...prev, [type]: !prev[type]}));
    const onTestKick = () => { if (audioSys?.audioEnabled && audioSys?.audioCtx) audioSys.triggerHeartPulse(audioSys.audioCtx.currentTime, { kickConfig, heartHarmonicVols }); };

    return (
        <div className="transition-colors bg-opacity-50">
            <div className="flex justify-between p-3 cursor-pointer hover:bg-white/5" onClick={() => onToggleExpand(type)}>
                <div className="flex items-center gap-2">
                    <div className="w-1 h-4 rounded" style={{ backgroundColor: color }} />
                    <span className="text-[10px] font-bold" style={{ color: uiConfig.textColor }}>{title}</span>
                </div>
                <div className="flex items-center gap-2">
                    <button onClick={(e) => { e.stopPropagation(); handleToggleStackMute(type); }} className={`text-[8px] px-1 border rounded ${isStackMuted ? 'border-red-500 text-red-400' : 'border-slate-600 text-slate-500'}`}>{isStackMuted ? 'MUTED' : 'ACTIVE'}</button>
                    {isExpanded ? <ChevronDown size={12} color={uiConfig.textColor} /> : <ChevronRight size={12} color={uiConfig.textColor} />}
                </div>
            </div>
            
            {isExpanded && (
                <div className="p-2 bg-black/20">
                    {type === 'HEART' ? (
                        <>
                            <div className="flex gap-2 mb-3">
                                <button onClick={() => onSnakeConfigChange && onSnakeConfigChange('mode', 'HARMONIC')} className={`flex-1 py-1.5 text-[9px] font-bold rounded flex items-center justify-center gap-1.5 border transition-all ${snakeConfig?.mode === 'HARMONIC' ? 'bg-rose-500/20 border-rose-500/50 text-rose-400' : 'bg-slate-800 border-slate-700 text-slate-500'}`}><Waves size={10} /> HARMONIC</button>
                                <button onClick={() => onSnakeConfigChange && onSnakeConfigChange('mode', 'SNAKE')} className={`flex-1 py-1.5 text-[9px] font-bold rounded flex items-center justify-center gap-1.5 border transition-all ${snakeConfig?.mode === 'SNAKE' ? 'bg-rose-500/20 border-rose-500/50 text-rose-400' : 'bg-slate-800 border-slate-700 text-slate-500'}`}><Spline size={10} /> SNAKE TONE</button>
                            </div>

                            {snakeConfig?.mode === 'SNAKE' ? (
                                <div className="p-3 border rounded space-y-4 mb-4" style={{ backgroundColor: `rgba(${uiConfig.cardRgb}, 0.2)`, borderColor: `rgba(${uiConfig.borderRgb}, 0.1)` }}>
                                    <div className="flex justify-between items-center text-[9px] font-bold text-slate-500 uppercase tracking-widest"><span>Gliding Binaural</span><span className="text-rose-400 font-mono">{((bpm || 60) / 60).toFixed(2)} Hz Base</span></div>
                                    <div className="space-y-1"><div className="flex justify-between text-[10px] text-slate-300"><span>Snake Volume</span><span className="font-mono text-rose-400">{(snakeConfig.vol * 100).toFixed(0)}%</span></div><Fader value={snakeConfig.vol} onChange={(v: number) => onSnakeConfigChange && onSnakeConfigChange('vol', v)} color="#fb7185" uiConfig={uiConfig} /></div>
                                    <div className="space-y-1"><div className="flex justify-between text-[10px] text-slate-300"><span>Snake Transpose</span><span className="font-mono text-rose-400">{snakeConfig.transpose > 0 ? '+' : ''}{snakeConfig.transpose} OCT</span></div><Fader value={snakeConfig.transpose} min={-2} max={6} step={0.5} onChange={(v: number) => onSnakeConfigChange && onSnakeConfigChange('transpose', v)} color="#f43f5e" uiConfig={uiConfig} /></div>
                                    <div className="space-y-1"><div className="flex justify-between text-[10px] text-slate-300"><span>Glide Time</span><span className="font-mono text-rose-400">{snakeConfig.glide.toFixed(1)}s</span></div><Fader value={snakeConfig.glide} min={0.1} max={5.0} step={0.1} onChange={(v: number) => onSnakeConfigChange && onSnakeConfigChange('glide', v)} color="#fbbf24" uiConfig={uiConfig} /></div>
                                    <div className="pt-2 border-t border-white/10"><div className="flex justify-between items-center mb-2"><span className="text-[9px] text-slate-300 uppercase tracking-widest">Binaural Pulse</span><button onClick={() => onSnakeConfigChange && onSnakeConfigChange('isBinaural', !snakeConfig.isBinaural)} className={`px-2 py-0.5 rounded text-[9px] font-bold border transition-colors ${snakeConfig.isBinaural ? 'bg-cyan-500/20 text-cyan-400 border-cyan-500/50' : 'bg-slate-800 text-slate-500 border-slate-600'}`}>{snakeConfig.isBinaural ? "SYNCED" : "OFF"}</button></div>{snakeConfig.isBinaural && (<div className="flex justify-between items-center bg-black/20 p-2 rounded border border-white/5"><span className="text-[9px] text-slate-400">Global Sync</span><span className="text-[10px] font-mono text-cyan-400 font-bold">{binauralFreq?.toFixed(2)} Hz</span></div>)}</div>
                                </div>
                            ) : (
                                <div className="mb-4 space-y-2">
                                    <div className="flex items-center justify-between px-1 mb-1"><span className="text-[9px] font-bold uppercase tracking-widest opacity-60" style={{ color: uiConfig.textColor }}>Dynamic Harmonic Ladder</span><span className="text-[9px] font-mono font-bold text-rose-400">{((bpm || 60) / 60).toFixed(2)} Hz Base</span></div>
                                    {HEART_HARMONIC_DEFS.map((def, i) => {
                                        const freq = ((bpm || 60) / 60) * def.mult;
                                        return (
                                            <div key={i} className="flex items-center gap-2 py-1 px-2 rounded">
                                                <button onClick={() => handleHeartHarmonicMuteToggle(i)} className={heartHarmonicMutes && heartHarmonicMutes[i] ? 'text-red-400' : 'text-slate-400'}>{heartHarmonicMutes && heartHarmonicMutes[i] ? <VolumeX size={10} /> : <Volume2 size={10} />}</button>
                                                <div className="flex-1"><div className="flex justify-between"><span className="text-[9px]" style={{ color: uiConfig.textColor }}>{def.label}</span><span className="text-[9px] opacity-50" style={{ color: uiConfig.textColor }}>{freq.toFixed(2)}Hz</span></div><Fader value={heartHarmonicVols ? heartHarmonicVols[i] : 0} onChange={(v: number) => handleHeartHarmonicVolChange(i, v)} color="#fb7185" disabled={heartHarmonicMutes ? heartHarmonicMutes[i] : false} uiConfig={uiConfig}/></div>
                                            </div>
                                        );
                                    })}
                                </div>
                            )}
                            
                            {kickConfig && onKickConfigChange && (
                                <KickDesigner 
                                    config={kickConfig} onChange={onKickConfigChange} volume={volumes ? (volumes['HEART_KICK'] ?? 0.8) : 0.8} 
                                    onVolumeChange={(v: number) => onVolumeChange && onVolumeChange('HEART_KICK', v)} 
                                    isMuted={mutes ? (mutes['HEART_KICK'] ?? false) : false} onMuteToggle={() => onMuteToggle && onMuteToggle('HEART_KICK')} 
                                    onTestKick={onTestKick} presets={kickPresets} activePresetId={activeKickPresetId} 
                                    onSelectKickPreset={handleSelectKickPreset} onSaveKickPreset={handleSaveKickPreset} 
                                    onDeleteKickPreset={handleDeleteKickPreset} uiConfig={uiConfig} 
                                />
                            )}
                        </>
                    ) : (
                        <>
                            <div className="mb-3 p-3 rounded border" style={{ backgroundColor: `rgba(${uiConfig.cardRgb}, 0.2)`, borderColor: `rgba(${uiConfig.borderRgb}, 0.1)` }}>
                                <div className="flex items-center justify-between mb-2">
                                    <div className="flex items-center gap-2"><Headphones size={12} className={isBinauralLocked ? "text-slate-500" : "text-cyan-400"} /><span className="text-[10px] font-bold uppercase tracking-widest opacity-70" style={{ color: uiConfig.textColor }}>Binaural Entrainment</span></div>
                                    <button onClick={onBinauralLockToggle} className={`flex items-center gap-1 px-2 py-0.5 rounded text-[9px] font-bold border transition-all ${isBinauralLocked ? 'border-slate-600 text-slate-500' : 'border-cyan-500 text-cyan-400 bg-cyan-900/20'}`}>{isBinauralLocked ? <Lock size={8} /> : <Unlock size={8} />}{isBinauralLocked ? "LOCKED" : "TUNING"}</button>
                                </div>
                                <div className="flex justify-between items-center mb-1 px-1"><span className="text-[9px] font-bold uppercase tracking-wider opacity-60" style={{ color: uiConfig.textColor }}>Beat Frequency</span><span className={`text-[11px] font-mono font-bold ${isBinauralLocked ? "text-slate-500" : "text-cyan-400"}`}>{(binauralFreq || 0).toFixed(2)} Hz</span></div>
                                <div className={`mt-1 transition-all duration-300 ${isBinauralLocked ? 'opacity-50 pointer-events-none grayscale' : 'opacity-100'}`}><Fader value={binauralFreq || 0} min={0.1} max={40} step={0.01} onChange={(v:number) => handleBinauralChange && handleBinauralChange(type, v)} color={isBinauralLocked ? "#64748b" : "#22d3ee"} uiConfig={uiConfig} /><div className="flex justify-between text-[9px] font-mono mt-1 opacity-50" style={{ color: uiConfig.textColor }}><span>0.1 Hz (Delta)</span><span>40.0 Hz (Gamma)</span></div></div>
                                <div className="mt-2 text-[9px] font-mono px-2 py-1 rounded border text-center flex justify-between opacity-80" style={{ backgroundColor: `rgba(0,0,0,0.2)`, borderColor: `rgba(${uiConfig.borderRgb}, 0.1)`, color: uiConfig.textColor }}><span>Carrier (L)</span><span>+</span><span className="text-cyan-500 font-bold">{(binauralFreq || 0).toFixed(2)}Hz</span><span>=</span><span>Signal (R)</span></div>
                            </div>
                            
                            {channels.map((c: { id: string; name: string; freq: number; octave?: number; noteLabel?: string; }) => (
                                <ChannelRow key={c.id} ch={c} volume={volumes ? (volumes[c.id] ?? 0) : 0} isMuted={mutes ? (mutes[c.id] ?? false) : false} isActive={activeId === c.id} onVolumeChange={onVolumeChange} onMuteToggle={onMuteToggle} uiConfig={uiConfig} />
                            ))}
                        </>
                    )}
                </div>
            )}
        </div>
    );
});