import React from 'react';
import { Accordion } from './Accordion';
import { UIConfig } from '../../system/StyleEditor';
import { UNIVERSAL_CHANNELS } from '../visuals/shared';
import { Atom } from 'lucide-react';

interface Props {
    uiConfig: UIConfig;
    audio: Record<string, unknown>; // AudioController
    temporal: Record<string, unknown>; // TemporalController
    activeId: string | null;
    expanded: Record<string, boolean>;
    onToggleExpand: (type: string) => void;
    activeBank: string;
    onBankChange: (bank: string) => void;
}

export const LatticeFeedbackDesigner: React.FC<Props> = ({
    uiConfig, audio, temporal, activeId, expanded, onToggleExpand
}) => {
    return (
        <div className="space-y-3">
            <div className="flex gap-2 p-2 rounded bg-black/20 border border-white/5 items-center justify-center">
                <span className="text-[9px] font-bold uppercase tracking-widest text-amber-400 flex items-center gap-2">
                    <Atom size={12} /> Universal Bank Active
                </span>
            </div>

            <div className="space-y-1">
                <Accordion 
                    type="UNIVERSAL" 
                    color="#f59e0b" 
                    title="UNIVERSAL (GM)" 
                    channels={UNIVERSAL_CHANNELS} 
                    isExpanded={expanded['UNIVERSAL']} 
                    onToggleExpand={onToggleExpand} 
                    audio={audio}
                    temporal={temporal}
                    activeId={activeId} 
                    uiConfig={uiConfig} 
                />
            </div>
        </div>
    );
};    