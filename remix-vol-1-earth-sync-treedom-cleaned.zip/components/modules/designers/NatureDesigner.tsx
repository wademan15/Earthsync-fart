import React from 'react';
import { Trees, Clock, Sun, Moon, ChevronDown, CloudRain, Waves, Flame, Wind, Feather } from 'lucide-react';
import { UIConfig } from '../../system/StyleEditor';
import { Fader, ModulationFader } from '../../ui/Faders';

interface Props {
    atmosphere: Record<string, unknown>; // AtmosphereController
    modulation: Record<string, unknown>; // ModulationController
    uiConfig: UIConfig;
}

export const NatureDesigner: React.FC<Props> = ({ 
    atmosphere, modulation, uiConfig
}) => {
    const { natureConfig, setNatureConfig: onNatureChange } = atmosphere;
    const { modulations, handleModulationChange: onModulationChange } = modulation;

    const updateNature = (key: string, val: string | number) => onNatureChange({ ...natureConfig, [key]: val });
    const BIOMES = ['TEMPERATE', 'DEEP_WOODS', 'RAINFOREST', 'WETLAND'];

    return (
        <div className="p-3 border rounded space-y-4" style={{ backgroundColor: `rgba(${uiConfig.cardRgb}, 0.2)`, borderColor: `rgba(${uiConfig.borderRgb}, 0.1)` }}>
            <div className="flex justify-between items-center pb-2 border-b border-white/10">
                <span className="text-[9px] font-bold uppercase tracking-widest text-emerald-400 flex items-center gap-2"><Trees size={12} /> Zen Garden</span>
                <div className="flex gap-2">
                    <div className="flex bg-slate-900/50 rounded border border-white/10 p-0.5">
                        <button onClick={() => updateNature('timeMode', 'AUTO')} className={`p-1 rounded ${natureConfig.timeMode === 'AUTO' ? 'bg-white/20 text-white' : 'text-slate-500 hover:text-slate-300'}`} title="Auto (Real-time)"><Clock size={10} /></button>
                        <button onClick={() => updateNature('timeMode', 'DAY')} className={`p-1 rounded ${natureConfig.timeMode === 'DAY' ? 'bg-amber-500/20 text-amber-400' : 'text-slate-500 hover:text-slate-300'}`} title="Force Day (Birds)"><Sun size={10} /></button>
                        <button onClick={() => updateNature('timeMode', 'NIGHT')} className={`p-1 rounded ${natureConfig.timeMode === 'NIGHT' ? 'bg-indigo-500/20 text-indigo-400' : 'text-slate-500 hover:text-slate-300'}`} title="Force Night (Crickets)"><Moon size={10} /></button>
                    </div>
                    <div className="relative">
                        <select value={natureConfig.biome} onChange={(e) => updateNature('biome', e.target.value)} className="bg-black/40 text-[9px] font-mono border rounded px-2 py-1 outline-none appearance-none cursor-pointer hover:bg-white/5 transition-colors focus:border-emerald-500" style={{ borderColor: `rgba(${uiConfig.borderRgb}, 0.2)`, color: uiConfig.textColor }}>
                            {BIOMES.map(b => <option key={b} value={b} className="bg-slate-950 text-slate-200">{b.replace('_', ' ')}</option>)}
                        </select>
                        <ChevronDown size={10} className="absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none opacity-50" style={{ color: uiConfig.textColor }}/>
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-1 gap-3">
                <div className="space-y-1"><div className="flex justify-between items-center text-[8px] uppercase tracking-wide text-slate-400"><span className="flex items-center gap-1"><CloudRain size={10} className="text-blue-400"/> Rain</span><span style={{ color: uiConfig.primaryColor }}>{(natureConfig.rainVol * 100).toFixed(0)}%</span></div><div className="relative"><ModulationFader value={natureConfig.rainVol} min={0} max={1} step={0.05} onStaticChange={(v) => updateNature('rainVol', v)} color="#60a5fa" uiConfig={uiConfig} modNode={modulations['rainVol']} onModChange={(n) => onModulationChange('rainVol', n)} /></div></div>
                <div className="space-y-1"><div className="flex justify-between items-center text-[8px] uppercase tracking-wide text-slate-400"><span className="flex items-center gap-1"><Waves size={10} className="text-cyan-400"/> Stream</span><span style={{ color: uiConfig.primaryColor }}>{(natureConfig.streamVol * 100).toFixed(0)}%</span></div><div className="relative"><ModulationFader value={natureConfig.streamVol} min={0} max={1} step={0.05} onStaticChange={(v) => updateNature('streamVol', v)} color="#22d3ee" uiConfig={uiConfig} modNode={modulations['streamVol']} onModChange={(n) => onModulationChange('streamVol', n)} /></div></div>
                <div className="space-y-1"><div className="flex justify-between items-center text-[8px] uppercase tracking-wide text-slate-400"><span className="flex items-center gap-1"><Flame size={10} className="text-orange-500"/> Hearth</span><span style={{ color: uiConfig.primaryColor }}>{(natureConfig.fireVol * 100).toFixed(0)}%</span></div><div className="relative"><ModulationFader value={natureConfig.fireVol} min={0} max={1} step={0.05} onStaticChange={(v) => updateNature('fireVol', v)} color="#f97316" uiConfig={uiConfig} modNode={modulations['fireVol']} onModChange={(n) => onModulationChange('fireVol', n)} /></div></div>
                <div className="space-y-1"><div className="flex justify-between items-center text-[8px] uppercase tracking-wide text-slate-400"><span className="flex items-center gap-1"><Wind size={10} className="text-green-300"/> Canopy</span><span style={{ color: uiConfig.primaryColor }}>{(natureConfig.windVol * 100).toFixed(0)}%</span></div><div className="relative"><ModulationFader value={natureConfig.windVol} min={0} max={1} step={0.05} onStaticChange={(v) => updateNature('windVol', v)} color="#86efac" uiConfig={uiConfig} modNode={modulations['windVol']} onModChange={(n) => onModulationChange('windVol', n)} /></div></div>
                
                <div className="pt-2 border-t border-white/5 space-y-2">
                    <div className="space-y-1"><div className="flex justify-between items-center text-[8px] uppercase tracking-wide text-slate-400"><span className="flex items-center gap-1"><Feather size={10} className="text-pink-400"/> Birdsong</span><span style={{ color: uiConfig.primaryColor }}>{(natureConfig.birdVol * 100).toFixed(0)}%</span></div><Fader value={natureConfig.birdVol} min={0} max={1} step={0.05} onChange={(v:number) => updateNature('birdVol', v)} color="#f472b6" uiConfig={uiConfig} /></div>
                    <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-1"><div className="flex justify-between text-[7px] text-slate-500 uppercase"><span>Density</span></div><Fader value={natureConfig.birdDensity} min={0} max={1} step={0.1} onChange={(v:number) => updateNature('birdDensity', v)} color="#64748b" uiConfig={uiConfig} /></div>
                        <div className="space-y-1"><div className="flex justify-between text-[7px] text-slate-500 uppercase"><span>Diversity</span></div><Fader value={natureConfig.birdDiversity} min={0} max={1} step={0.1} onChange={(v:number) => updateNature('birdDiversity', v)} color="#a855f7" uiConfig={uiConfig} /></div>
                    </div>
                </div>
            </div>
        </div>
    );
};