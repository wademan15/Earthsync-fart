import React, { useState } from 'react';
import { Volume2, VolumeX, ChevronDown, Save, Trash2, Waves, Activity, Zap, Heart, Wind, Music2, Timer } from 'lucide-react';
import { KickConfig } from '../../services/audio/AudioTypes';
import { UIConfig } from '../system/StyleEditor';
import { Fader } from '../../ui/Faders';
import { KickPreset, DEFAULT_KICK_CONFIG, DEFAULT_KICK_PRESETS } from '../../services/audio/heartStyles';

export type { KickPreset };
export { DEFAULT_KICK_CONFIG, DEFAULT_KICK_PRESETS };

interface Props {
    config?: KickConfig;
    onChange: (c: KickConfig) => void;
    volume?: number;
    onVolumeChange: (v: number) => void;
    isMuted?: boolean;
    onMuteToggle: () => void;
    onTestKick: () => void;
    presets?: KickPreset[];
    activePresetId?: string;
    onSelectKickPreset: (p: KickPreset) => void;
    onSaveKickPreset: () => void;
    onDeleteKickPreset: (id: string) => void;
    uiConfig: UIConfig;
}

export const KickDesigner: React.FC<Props> = ({ 
    config = DEFAULT_KICK_CONFIG, onChange, volume = 0.6, onVolumeChange, isMuted = false, onMuteToggle, 
    onTestKick, presets = DEFAULT_KICK_PRESETS, activePresetId = 'cardiac_thud', onSelectKickPreset, 
    onSaveKickPreset, onDeleteKickPreset, uiConfig 
}) => {
    const activeCfg = { ...DEFAULT_KICK_CONFIG, ...config };
    const safeVolume = typeof volume === 'number' && !isNaN(volume) ? volume : 0.6;
    const baseFreq = activeCfg.baseFreq ?? activeCfg.freq ?? 48;
    const pitchDecay = activeCfg.pitchDecay ?? 0.07;
    const ampDecay = activeCfg.ampDecay ?? activeCfg.decay ?? 0.35;
    const clickLevel = activeCfg.clickLevel ?? 0.08;
    const saturation = activeCfg.saturation ?? 15;
    const lpfCutoff = activeCfg.lpfCutoff ?? 160;
    const waveType = activeCfg.waveType ?? (activeCfg.type?.toLowerCase() === 'triangle' ? 'triangle' : 'sine');
    const syncMode = activeCfg.syncMode || 'BREATH';
    const doubleBeat = activeCfg.doubleBeat !== false;

    const update = <K extends keyof KickConfig>(key: K, val: KickConfig[K]) => onChange({ ...activeCfg, [key]: val });
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const activePreset = presets.find((p: KickPreset) => p.id === activePresetId) || presets[0] || DEFAULT_KICK_PRESETS[0];
    
    return (
        <div className="p-3 border space-y-4" style={{backgroundColor: `rgba(${uiConfig.cardRgb}, ${Math.min(1, uiConfig.bgOpacity + 0.2)})`, borderColor: `rgba(${uiConfig.borderRgb}, ${uiConfig.borderOpacity})`, borderRadius: `${uiConfig.borderRadius}px`}}>
            <div className="flex items-center gap-2 pb-2 border-b" style={{ borderColor: `rgba(${uiConfig.borderRgb}, ${uiConfig.borderOpacity})` }}>
                <span className="text-[10px] font-bold uppercase px-1 shrink-0 opacity-60 flex items-center gap-1" style={{ color: uiConfig.textColor }}><Heart size={12} className="text-rose-400"/> Heartbeat</span>
                <div className="relative flex-1">
                    <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="w-full flex items-center justify-between rounded-md px-2 py-1 border hover:opacity-100 opacity-80 text-[10px] font-mono transition-all" style={{ backgroundColor: `rgba(${uiConfig.borderRgb}, 0.1)`, borderColor: `rgba(${uiConfig.borderRgb}, 0.2)`, color: uiConfig.textColor as string }}><span>{activePreset ? activePreset.name : 'Custom'}</span><ChevronDown size={10} className={`transition-transform ${isMenuOpen ? 'rotate-180' : ''}`} /></button>
                    {isMenuOpen && (<><div className="fixed inset-0 z-30" onClick={() => setIsMenuOpen(false)} /><div className="absolute top-full left-0 right-0 mt-1 border rounded-md shadow-xl z-40 max-h-32 overflow-y-auto" style={{ backgroundColor: `rgb(${uiConfig.cardRgb})`, borderColor: `rgba(${uiConfig.borderRgb}, 0.5)` }}>{presets.map((p: KickPreset) => (<div key={p.id} className="flex items-center justify-between hover:bg-white/5 group px-1"><button onClick={() => { onSelectKickPreset(p); setIsMenuOpen(false); }} className="flex-1 text-left py-1.5 px-2 text-[10px] font-mono hover:opacity-100 opacity-70 truncate" style={{ color: uiConfig.textColor as string }}>{p.name}</button>{!DEFAULT_KICK_PRESETS.find(dp => dp.id === p.id) && (<button onClick={(e) => { e.stopPropagation(); onDeleteKickPreset(p.id); }} className="p-1 opacity-50 hover:opacity-100 hover:text-red-400 transition-colors" style={{ color: uiConfig.textColor as string }}><Trash2 size={10} /></button>)}</div>))}</div></>)}
                </div>
                <button onClick={onSaveKickPreset} className="p-1 rounded bg-rose-500/10 text-rose-400 border border-rose-500/30 hover:bg-rose-500/20"><Save size={12} /></button>
            </div>

            {/* SYNC MODE & PATTERN */}
            <div className="space-y-2">
                <div className="text-[9px] font-bold uppercase tracking-wider text-rose-300 opacity-80">Rhythmic Entrainment Lock</div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-1">
                    <button 
                        onClick={() => update('syncMode', 'BREATH')} 
                        className={`py-1.5 px-1.5 text-[9px] font-bold rounded flex items-center justify-center gap-1 border transition-all ${syncMode === 'BREATH' ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50 shadow-[0_0_10px_rgba(6,182,212,0.2)]' : 'bg-white/5 text-white/50 border-white/10 hover:text-white'}`}
                    >
                        <Wind size={10}/> Breath (RSA)
                    </button>
                    <button 
                        onClick={() => {
                            onChange({ ...activeCfg, syncMode: 'BREATH_COUNT', syncToSeconds: true });
                        }} 
                        className={`py-1.5 px-1.5 text-[9px] font-bold rounded flex items-center justify-center gap-1 border transition-all ${syncMode === 'BREATH_COUNT' ? 'bg-rose-500/20 text-rose-300 border-rose-500/50 shadow-[0_0_10px_rgba(244,63,94,0.2)]' : 'bg-white/5 text-white/50 border-white/10 hover:text-white'}`}
                        title="1 beat per second hitting turnarounds on inhale/exhale"
                    >
                        <Timer size={10}/> 1s Count
                    </button>
                    <button 
                        onClick={() => update('syncMode', 'BINAURAL')} 
                        className={`py-1.5 px-1.5 text-[9px] font-bold rounded flex items-center justify-center gap-1 border transition-all ${syncMode === 'BINAURAL' ? 'bg-purple-500/20 text-purple-300 border-purple-500/50 shadow-[0_0_10px_rgba(168,85,247,0.2)]' : 'bg-white/5 text-white/50 border-white/10 hover:text-white'}`}
                    >
                        <Music2 size={10}/> Binaural
                    </button>
                    <button 
                        onClick={() => update('syncMode', 'STEADY')} 
                        className={`py-1.5 px-1.5 text-[9px] font-bold rounded flex items-center justify-center gap-1 border transition-all ${syncMode === 'STEADY' ? 'bg-rose-500/20 text-rose-300 border-rose-500/50 shadow-[0_0_10px_rgba(244,63,94,0.2)]' : 'bg-white/5 text-white/50 border-white/10 hover:text-white'}`}
                    >
                        <Heart size={10}/> Steady
                    </button>
                </div>
                
                <div className="flex gap-2 items-center justify-between pt-1">
                    <span className="text-[10px] opacity-70">Acoustic Signature</span>
                    <button 
                        onClick={() => update('doubleBeat', !doubleBeat)}
                        className={`px-3 py-1 rounded text-[9px] font-bold border transition-colors ${doubleBeat ? 'bg-rose-500/20 text-rose-300 border-rose-500/40' : 'bg-white/5 text-white/50 border-white/10'}`}
                    >
                        {doubleBeat ? 'Lub-Dub (Double)' : 'Single Thud'}
                    </button>
                </div>
            </div>

            <div className="flex items-center gap-3 mb-2">
                <button onClick={onMuteToggle} className={`p-1.5 rounded ${isMuted ? 'text-red-400 bg-red-500/10' : 'opacity-60 hover:opacity-100'}`} style={!isMuted ? { color: uiConfig.textColor } : {}}>
                    {isMuted ? <VolumeX size={14} /> : <Volume2 size={14} />}
                </button>
                <div className="flex-1">
                    <div className="flex justify-between mb-1 text-[10px] font-bold text-rose-400 uppercase tracking-wider">
                        <span>Heartbeat Volume</span>
                        <span>{(safeVolume * 100).toFixed(0)}%</span>
                    </div>
                    <Fader value={safeVolume} onChange={onVolumeChange} color="#fb7185" uiConfig={uiConfig} />
                </div>
                <button onClick={onTestKick} className="px-3 py-1.5 bg-rose-500/20 text-rose-400 hover:bg-rose-500 hover:text-white border border-rose-500/50 rounded text-[10px] font-bold uppercase transition-all">
                    TEST
                </button>
            </div>
            
            {/* STACKED CONTROL GROUPS */}
            <div className="grid grid-cols-1 gap-2">
                <div className="p-2 rounded border flex flex-col gap-2" style={{ backgroundColor: `rgba(${uiConfig.cardRgb}, 0.3)`, borderColor: `rgba(${uiConfig.borderRgb}, 0.1)` }}>
                    <div className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-widest opacity-60" style={{ color: uiConfig.textColor as string }}><Waves size={10} /> Tone</div>
                    <div className="flex gap-1">
                        <button onClick={() => update('waveType', 'sine')} className={`flex-1 py-1 text-[9px] rounded border ${waveType === 'sine' ? 'bg-rose-500 text-white border-rose-500' : 'border-slate-700 text-slate-500'}`}>SINE</button>
                        <button onClick={() => update('waveType', 'triangle')} className={`flex-1 py-1 text-[9px] rounded border ${waveType === 'triangle' ? 'bg-rose-500 text-white border-rose-500' : 'border-slate-700 text-slate-500'}`}>TRI</button>
                    </div>
                    <div>
                        <div className="flex justify-between text-[10px] mb-0.5 opacity-70" style={{ color: uiConfig.textColor as string }}>
                            <span>Tune</span>
                            <span className="font-mono">{baseFreq}Hz</span>
                        </div>
                        <Fader value={baseFreq} min={30} max={80} step={1} onChange={(v: number) => { update('baseFreq', v); update('freq', v); }} color="#fb7185" uiConfig={uiConfig} />
                    </div>
                </div>

                <div className="p-2 rounded border flex flex-col gap-2" style={{ backgroundColor: `rgba(${uiConfig.cardRgb}, 0.3)`, borderColor: `rgba(${uiConfig.borderRgb}, 0.1)` }}>
                    <div className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-widest opacity-60" style={{ color: uiConfig.textColor as string }}><Activity size={10} /> Shape</div>
                    <div>
                        <div className="flex justify-between text-[10px] mb-0.5 opacity-70" style={{ color: uiConfig.textColor as string }}>
                            <span>Punch</span>
                            <span className="font-mono">{(pitchDecay * 1000).toFixed(0)}ms</span>
                        </div>
                        <Fader value={pitchDecay} min={0.01} max={0.3} step={0.01} onChange={(v: number) => update('pitchDecay', v)} color="#fb7185" uiConfig={uiConfig} />
                    </div>
                    <div>
                        <div className="flex justify-between text-[10px] mb-0.5 opacity-70" style={{ color: uiConfig.textColor as string }}>
                            <span>Boom</span>
                            <span className="font-mono">{(ampDecay * 1000).toFixed(0)}ms</span>
                        </div>
                        <Fader value={ampDecay} min={0.1} max={1.5} step={0.05} onChange={(v: number) => { update('ampDecay', v); update('decay', v); }} color="#fb7185" uiConfig={uiConfig} />
                    </div>
                </div>

                <div className="p-2 rounded border flex flex-col gap-2" style={{ backgroundColor: `rgba(${uiConfig.cardRgb}, 0.3)`, borderColor: `rgba(${uiConfig.borderRgb}, 0.1)` }}>
                    <div className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-widest opacity-60" style={{ color: uiConfig.textColor as string }}><Zap size={10} /> Resonance</div>
                    <div>
                        <div className="flex justify-between text-[10px] mb-0.5 opacity-70" style={{ color: uiConfig.textColor as string }}>
                            <span>Valve Click</span>
                            <span className="font-mono">{(clickLevel * 100).toFixed(0)}%</span>
                        </div>
                        <Fader value={clickLevel} min={0} max={0.5} step={0.01} onChange={(v: number) => update('clickLevel', v)} color="#e2e8f0" uiConfig={uiConfig} />
                    </div>
                    <div>
                        <div className="flex justify-between text-[10px] mb-0.5 opacity-70" style={{ color: uiConfig.textColor as string }}>
                            <span>Sub Warmth</span>
                            <span className="font-mono">{saturation.toFixed(0)}%</span>
                        </div>
                        <Fader value={saturation} min={0} max={100} step={1} onChange={(v: number) => update('saturation', v)} color="#fbbf24" uiConfig={uiConfig} />
                    </div>
                </div>
            </div>

            <div className="px-1">
                <div className="flex justify-between text-[10px] mb-0.5 opacity-70" style={{ color: uiConfig.textColor as string }}>
                    <span>Chest Filter (LPF)</span>
                    <span className="font-mono">{lpfCutoff.toFixed(0)} Hz</span>
                </div>
                <Fader value={lpfCutoff} min={80} max={1200} step={10} onChange={(v: number) => update('lpfCutoff', v)} color="#38bdf8" uiConfig={uiConfig} />
            </div>
        </div>
    );
};
