import React from 'react';
import { Brain, Headphones, Eye, Zap, Orbit, Spline, ChevronDown, Music, GitBranch, Wind, Network, Activity } from 'lucide-react';
import { ENTRAINMENT_MODES } from '../visuals/shared';
import { UIConfig } from '../../system/StyleEditor';
import { Fader } from '../../ui/Faders';
import { EntrainmentLayerSelector } from './EntrainmentLayerSelector';
import { resolveActiveLayers, EntrainmentLayer } from '../../../services/audio/AudioTypes';

interface Props {
    atmosphere: Record<string, unknown>; 
    temporal: Record<string, unknown>;   
    uiConfig: UIConfig;
}

export const ImmersionDesigner: React.FC<Props> = ({ 
    atmosphere, temporal, uiConfig 
}) => {
    const { immersionConfig: config, setImmersionConfig: onChange } = atmosphere;
    const { binauralFreqs, handleGlobalEntrainmentChange: onEntrainmentChange } = temporal;
    const entrainmentFreq = binauralFreqs ? binauralFreqs['UNIVERSAL'] : 8.0;

    const update = (key: string, val: string | number | boolean) => onChange && onChange({ ...(config as object), [key]: val });
    const updateConfig = (updates: Record<string, unknown>) => onChange && onChange({ ...(config as object), ...updates });

    const activeLayers = resolveActiveLayers(config as any);

    const handleToggleLayer = (layer: EntrainmentLayer) => {
        const next = activeLayers.includes(layer)
            ? activeLayers.filter(l => l !== layer)
            : [...activeLayers, layer];
        if (next.length === 0) return;
        const nextMode = next.length > 1
            ? 'HYBRID'
            : (next[0] === 'isochronic' ? 'ISOCHRONIC' : next[0] === 'monaural' ? 'MONAURAL' : 'BINAURAL');
        updateConfig({ activeLayers: next, pulseMode: nextMode });
    };

    return (
        <div className="p-3 border space-y-4" style={{ backgroundColor: `rgba(${uiConfig.cardRgb}, 0.2)`, borderColor: `rgba(${uiConfig.borderRgb}, 0.1)`, borderRadius: uiConfig.borderRadius }}>
            
            <div className="space-y-2 pb-3 border-b border-white/10">
                <div className="flex justify-between items-center text-[10px] font-bold uppercase tracking-widest text-slate-300">
                    <span className="flex items-center gap-2"><Brain size={12} className="text-cyan-400" /> Target Frequency</span>
                    {typeof entrainmentFreq === 'number' && (<span className="font-mono text-cyan-400 opacity-80">{entrainmentFreq.toFixed(2)} Hz</span>)}
                </div>
                <div className="relative">
                    <select className={`w-full bg-black/40 text-[10px] font-mono border rounded px-3 py-2 outline-none appearance-none cursor-pointer hover:bg-white/5 transition-colors focus:border-cyan-500 ${config.isPerfectFifth || config.isFractalSync ? 'opacity-50' : 'opacity-100'}`} style={{ borderColor: `rgba(${uiConfig.borderRgb}, 0.2)`, color: uiConfig.textColor }} onChange={(e) => onEntrainmentChange && onEntrainmentChange(Number(e.target.value))} value={ENTRAINMENT_MODES.some(m => Math.abs(m.freq - (entrainmentFreq || 0)) < 0.001) ? entrainmentFreq : 'CUSTOM'} disabled={config.isPerfectFifth || config.isFractalSync}>
                        {ENTRAINMENT_MODES.map((mode) => (<option key={mode.name} value={mode.freq} className="bg-slate-950 text-slate-200">{mode.name}</option>))}
                        {!ENTRAINMENT_MODES.some(m => Math.abs(m.freq - (entrainmentFreq || 0)) < 0.001) && (
                            <option value="CUSTOM" className="bg-slate-950 text-cyan-300">Custom ({typeof entrainmentFreq === 'number' ? entrainmentFreq.toFixed(2) : entrainmentFreq} Hz)</option>
                        )}
                    </select>
                    <ChevronDown size={12} className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none opacity-50" style={{ color: uiConfig.textColor }}/>
                </div>
                <div className="flex items-center gap-2 pt-1">
                    <span className="text-[9px] font-bold uppercase tracking-wider text-slate-400">Custom Hz:</span>
                    <input 
                        type="number" 
                        step="0.01" 
                        min="0.01" 
                        max="1000" 
                        value={typeof entrainmentFreq === 'number' ? entrainmentFreq : 8.0}
                        onChange={(e) => {
                            const val = parseFloat(e.target.value);
                            if (!isNaN(val) && val > 0 && onEntrainmentChange) {
                                onEntrainmentChange(val);
                            }
                        }}
                        disabled={config.isPerfectFifth || config.isFractalSync}
                        className="flex-1 bg-black/50 border border-white/10 focus:border-cyan-400 rounded px-2 py-1 text-xs font-mono text-cyan-300 outline-none"
                    />
                </div>
                <div className="text-[9px] text-slate-500 pl-1">{config.isPerfectFifth ? "Harmonic Mode Active" : config.isFractalSync ? "Fractal Sync Active" : (ENTRAINMENT_MODES.find(m => m.freq === entrainmentFreq)?.desc || "Custom Tuning")}</div>
            </div>

            <div className="space-y-3">
                
                <div className="pb-3 border-b border-white/10">
                    <EntrainmentLayerSelector
                        activeLayers={activeLayers}
                        onToggleLayer={handleToggleLayer}
                        isConjugatePhase={config.isConjugatePhase}
                        onToggleConjugatePhase={(val) => update('isConjugatePhase', val)}
                        isochronicHardEdge={config.isochronicHardEdge}
                        onToggleIsochronicHardEdge={(val) => update('isochronicHardEdge', val)}
                        isPACGated={config.isPACGated}
                        onTogglePACGated={(val) => update('isPACGated', val)}
                        variant="inline"
                    />
                </div>

                {/* COMPOSER MATRIX UPDATE WITH INTENSITY SLIDER */}
                <div className="flex flex-col pb-2 border-b border-white/10 gap-2">
                    <div className="flex justify-between items-center">
                        <div className="flex flex-col">
                            <span className="text-[10px] font-bold uppercase tracking-widest text-slate-300 flex items-center gap-2">
                                <Activity size={12} className="text-pink-400" /> 
                                Composer Pulse Matrix
                            </span>
                            <span className="text-[8px] text-slate-500 max-w-[180px]">
                                Warps the 4-beat rhythm structure based on clinical algorithms.
                            </span>
                        </div>
                        <select 
                            className="bg-black/40 text-[8px] font-mono border border-white/10 rounded px-2 py-1 outline-none cursor-pointer text-pink-400 focus:border-pink-500"
                            value={config.composerWarp || 'LINEAR'} 
                            onChange={(e) => update('composerWarp', e.target.value)}
                        >
                            <option value="LINEAR">LINEAR (OFF)</option>
                            <option value="BEETHOVEN">BEETHOVEN (WILL)</option>
                            <option value="MOZART">MOZART (LIGHTNESS)</option>
                            <option value="HAYDN">HAYDN (AWE)</option>
                            <option value="SCHUBERT">SCHUBERT (LONGING)</option>
                            <option value="CHOPIN">CHOPIN (RUBATO)</option>
                            <option value="BACH">BACH (PRECISE)</option>
                            <option value="BRAHMS">BRAHMS (SWEEP)</option>
                        </select>
                    </div>
                    
                    {config.composerWarp && config.composerWarp !== 'LINEAR' && (
                        <div className="pl-4 pr-2 pt-1 animate-in slide-in-from-top-1">
                            <div className="flex justify-between text-[9px] text-slate-400 mb-1">
                                <span>Sentic Fluidity (Intensity)</span>
                                <span className="font-mono text-pink-400">{((config.composerIntensity ?? 1.0) * 100).toFixed(0)}%</span>
                            </div>
                            <Fader 
                                value={config.composerIntensity ?? 1.0} 
                                min={0} 
                                max={1.0} 
                                step={0.05} 
                                onChange={(v:number) => update('composerIntensity', v)} 
                                color="#f472b6" 
                                uiConfig={uiConfig} 
                            />
                        </div>
                    )}
                </div>

                <div className="flex justify-between items-center pb-2 border-b border-white/10">
                    <div className="flex flex-col">
                        <span className="text-[10px] font-bold uppercase tracking-widest text-slate-300 flex items-center gap-2">
                            <Network size={12} className={config.isTimeCrystal ? (config.pulseMode === 'ISOCHRONIC' ? "text-rose-400" : "text-cyan-400") : "text-slate-500"} /> 
                            Time Crystal Mode
                        </span>
                        <span className="text-[8px] text-slate-500 max-w-[180px]">
                            Applies an aperiodic topological sequence to the pulse mode.
                        </span>
                    </div>
                    <div className="flex flex-col items-end gap-1">
                        <button onClick={() => update('isTimeCrystal', !config.isTimeCrystal)} className={`w-10 h-5 rounded-full flex items-center p-0.5 transition-colors ${config.isTimeCrystal ? (config.pulseMode === 'ISOCHRONIC' ? 'bg-rose-500' : 'bg-cyan-500') : 'bg-slate-700'}`}><div className={`w-4 h-4 bg-white rounded-full shadow-sm transform transition-transform ${config.isTimeCrystal ? 'translate-x-5' : 'translate-x-0'}`} /></button>
                        {config.isTimeCrystal && (
                            <select className="bg-black/40 text-[8px] font-mono border border-white/10 rounded px-1 py-0.5 outline-none cursor-pointer text-cyan-400" value={config.timeCrystalTopology || 'FIBONACCI'} onChange={(e) => update('timeCrystalTopology', e.target.value)}>
                                <option value="FIBONACCI">FIBONACCI</option>
                                <option value="PRIME">PRIME METRIC</option>
                                <option value="THUE_MORSE">THUE-MORSE</option>
                                <option value="PERIOD_DOUBLE">PERIOD 2T</option>
                            </select>
                        )}
                    </div>
                </div>
                
                <div className="flex flex-col pb-2 border-b border-white/10 gap-2">
                    <div className="flex justify-between items-center">
                        <div className="flex flex-col"><span className="text-[10px] font-bold uppercase tracking-widest text-slate-300 flex items-center gap-2"><Music size={12} className="text-indigo-400" /> Harmonic Fifth</span><span className="text-[8px] text-slate-500 max-w-[180px]">Disables beats. Pitches Right Ear up a Perfect Fifth (3:2).</span></div>
                        <button onClick={() => { 
                            const nextConfig = { ...config, isPerfectFifth: !config.isPerfectFifth };
                            if (!config.isPerfectFifth) nextConfig.isFractalSync = false;
                            onChange(nextConfig); 
                        }} className={`w-10 h-5 rounded-full flex items-center p-0.5 transition-colors ${config.isPerfectFifth ? 'bg-indigo-500' : 'bg-slate-700'}`}><div className={`w-4 h-4 bg-white rounded-full shadow-sm transform transition-transform ${config.isPerfectFifth ? 'translate-x-5' : 'translate-x-0'}`} /></button>
                    </div>
                    {config.isPerfectFifth && (<div className="flex items-center justify-between pl-4 pr-1 py-1 bg-white/5 rounded"><span className="text-[9px] font-bold uppercase text-slate-400 flex items-center gap-2"><Wind size={10} /> Breath Link</span><button onClick={() => update('isPerfectFifthBreathSync', !config.isPerfectFifthBreathSync)} className={`px-2 py-0.5 rounded text-[8px] font-bold uppercase border transition-all ${config.isPerfectFifthBreathSync ? 'bg-indigo-500/20 text-indigo-400 border-indigo-500/50' : 'bg-slate-800 text-slate-500 border-slate-700'}`}>{config.isPerfectFifthBreathSync ? "GLIDE (1:1 → 3:2)" : "STATIC (3:2)"}</button></div>)}
                </div>

                <div className="flex justify-between items-center pb-2 border-b border-white/10">
                    <div className="flex flex-col"><span className="text-[10px] font-bold uppercase tracking-widest text-slate-300 flex items-center gap-2"><GitBranch size={12} className="text-emerald-400" /> Fractal Sync</span><span className="text-[8px] text-slate-500 max-w-[180px]">Locks beat frequency to a power-of-2 division of the carrier.</span></div>
                    <button onClick={() => { 
                        const nextConfig = { ...config, isFractalSync: !config.isFractalSync };
                        if (!config.isFractalSync) nextConfig.isPerfectFifth = false;
                        onChange(nextConfig); 
                    }} className={`w-10 h-5 rounded-full flex items-center p-0.5 transition-colors ${config.isFractalSync ? 'bg-emerald-500' : 'bg-slate-700'}`}><div className={`w-4 h-4 bg-white rounded-full shadow-sm transform transition-transform ${config.isFractalSync ? 'translate-x-5' : 'translate-x-0'}`} /></button>
                </div>

                <div className="flex justify-between items-center pb-2 border-b border-white/10">
                    <div className="flex flex-col"><span className="text-[10px] font-bold uppercase tracking-widest text-slate-300 flex items-center gap-2"><Eye size={12} className="text-amber-400" /> Photic Strobe</span><span className="text-[8px] text-slate-500 max-w-[180px]">Synchronizes screen opacity to the beat frequency.</span></div>
                    <button onClick={() => update('isPhoticStrobe', !config.isPhoticStrobe)} className={`w-10 h-5 rounded-full flex items-center p-0.5 transition-colors ${config.isPhoticStrobe ? 'bg-amber-500' : 'bg-slate-700'}`}><div className={`w-4 h-4 bg-white rounded-full shadow-sm transform transition-transform ${config.isPhoticStrobe ? 'translate-x-5' : 'translate-x-0'}`} /></button>
                </div>
                {config.isPhoticStrobe && (<div className="pl-4 pr-2"><div className="flex justify-between text-[9px] text-slate-400 mb-1"><span>Strobe Depth</span><span>{(config.strobeOpacity * 100).toFixed(0)}%</span></div><Fader value={config.strobeOpacity} min={0} max={0.5} step={0.01} onChange={(v:number) => update('strobeOpacity', v)} color="#fbbf24" uiConfig={uiConfig} /></div>)}

                <div className="flex justify-between items-center pb-2 border-b border-white/10">
                    <div className="flex flex-col"><span className="text-[10px] font-bold uppercase tracking-widest text-slate-300 flex items-center gap-2"><Orbit size={12} className="text-emerald-400" /> Golden Panner</span><span className="text-[8px] text-slate-500 max-w-[180px]">Slowly rotates the 3D soundfield to prevent neural habituation.</span></div>
                    <button onClick={() => update('isGoldenPanner', !config.isGoldenPanner)} className={`w-10 h-5 rounded-full flex items-center p-0.5 transition-colors ${config.isGoldenPanner ? 'bg-emerald-500' : 'bg-slate-700'}`}><div className={`w-4 h-4 bg-white rounded-full shadow-sm transform transition-transform ${config.isGoldenPanner ? 'translate-x-5' : 'translate-x-0'}`} /></button>
                </div>

                <div className="flex justify-between items-center">
                    <div className="flex flex-col"><span className="text-[10px] font-bold uppercase tracking-widest text-slate-300 flex items-center gap-2"><Spline size={12} className="text-purple-400" /> Carrier Drift</span><span className="text-[8px] text-slate-500 max-w-[180px]">Micro-pitch shifts (+/- 2Hz) the carrier frequency over time.</span></div>
                    <button onClick={() => update('isCarrierDrift', !config.isCarrierDrift)} className={`w-10 h-5 rounded-full flex items-center p-0.5 transition-colors ${config.isCarrierDrift ? 'bg-purple-500' : 'bg-slate-700'}`}><div className={`w-4 h-4 bg-white rounded-full shadow-sm transform transition-transform ${config.isCarrierDrift ? 'translate-x-5' : 'translate-x-0'}`} /></button>
                </div>
            </div>
        </div>
    );
};