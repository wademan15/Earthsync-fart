import React from 'react';
import { Sliders, Shield, Play, Pause, Square, Sparkles, Maximize, Minimize, Atom, X, Cpu, Info } from 'lucide-react';
import { EarthSyncLogo } from '../../ui/EarthSyncLogo';
import { AudioMixerModal } from '../AudioMixerModal';
import { ExperiencePreset } from '../../types';

export interface TunerTopHeaderProps {
  uiConfig: {
    appBgColor?: string;
    textColor?: string;
    primaryColor?: string;
    borderRgb?: string;
    borderOpacity?: number;
    [key: string]: unknown;
  };
  isAudioMixerOpen: boolean;
  onToggleAudioMixer: () => void;
  onCloseAudioMixer: () => void;
  controller: any;
  onOpenBreathArchitect: () => void;
  isPolyvagalModalOpen: boolean;
  onTogglePolyvagalModal: () => void;
  isExperienceActive: boolean;
  isExperiencePaused: boolean;
  isMasterPlaying?: boolean;
  isMasterPaused?: boolean;
  onToggleMasterPlay?: () => void;
  activeExperience: ExperiencePreset | null;
  activeBlockIndex: number;
  blockProgress: number;
  currentExpCycle: number;
  onTogglePlayExperience: (preset?: ExperiencePreset) => void;
  onStopExperience: () => void;
  isExperienceModalOpen: boolean;
  onToggleExperienceModal: () => void;
  isVisualizerImmersion: boolean;
  onToggleVisualizerImmersion: () => void;
  viewMode?: string;
  onToggleViewMode?: () => void;
  onOpenStyleEditor?: () => void;
  showStyleEditor?: boolean;
  onOpenInfo?: () => void;
  starterExperiences: ExperiencePreset[];
}

export const TunerTopHeader: React.FC<TunerTopHeaderProps> = ({
  uiConfig,
  isAudioMixerOpen,
  onToggleAudioMixer,
  onCloseAudioMixer,
  controller,
  onOpenBreathArchitect,
  isPolyvagalModalOpen,
  onTogglePolyvagalModal,
  isExperienceActive,
  isExperiencePaused,
  isMasterPlaying,
  isMasterPaused,
  onToggleMasterPlay,
  activeExperience,
  activeBlockIndex,
  blockProgress,
  onTogglePlayExperience,
  onStopExperience,
  isExperienceModalOpen,
  onToggleExperienceModal,
  isVisualizerImmersion,
  onToggleVisualizerImmersion,
  viewMode,
  onToggleViewMode,
  onOpenStyleEditor,
  showStyleEditor,
  onOpenInfo,
  starterExperiences
}) => {
  if (isVisualizerImmersion) return null;

  return (
    <header
      className="flex items-center justify-between px-3 sm:px-6 py-2.5 sm:py-3 border-b z-50 shrink-0 transition-colors duration-300 relative"
      style={{
        backgroundColor: uiConfig.appBgColor,
        borderColor: `rgba(${uiConfig.borderRgb || '255,255,255'}, ${uiConfig.borderOpacity ?? 0.1})`
      }}
    >
      <div className="flex items-center gap-2 sm:gap-3 min-w-0">
        <EarthSyncLogo
          className="h-7 sm:h-9 w-auto shrink-0"
          mainColor={uiConfig.textColor}
          accentColor={uiConfig.primaryColor}
        />
        <span className="text-[11px] font-semibold tracking-widest uppercase text-cyan-400/80 hidden sm:inline-block border-l border-white/10 pl-3 truncate">
          Breath Pacer
        </span>
      </div>

      <div className="flex items-center gap-1 sm:gap-2 shrink-0">
        {/* Audio Mixer Controls Button & Dropdown */}
        <div className="relative">
          <button
            onClick={onToggleAudioMixer}
            title="Audio Mixer & Controls"
            aria-label="Audio Mixer & Controls"
            className={`flex items-center justify-center gap-1.5 p-2 sm:px-2.5 sm:py-1.5 rounded-full border transition-all duration-200 text-xs font-semibold min-w-[34px] min-h-[34px] ${
              isAudioMixerOpen
                ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40 shadow-[0_0_12px_rgba(6,182,212,0.25)]'
                : 'bg-transparent text-slate-400 border-white/10 hover:text-white hover:border-white/25 hover:bg-white/5'
            }`}
          >
            <Sliders size={14} className={isAudioMixerOpen ? 'text-cyan-400' : ''} />
            <span className="hidden md:inline text-[10px] uppercase font-bold tracking-wider">Mixer</span>
          </button>

          {isAudioMixerOpen && (
            <React.Suspense fallback={null}>
              <AudioMixerModal
                isOpen={isAudioMixerOpen}
                onClose={onCloseAudioMixer}
                controller={controller}
                onOpenBreathArchitect={onOpenBreathArchitect}
              />
            </React.Suspense>
          )}
        </div>

        {/* Polyvagal Neuromodulation Button & Pulse Indicator */}
        <div className="relative">
          <button
            onClick={onTogglePolyvagalModal}
            title="Polyvagal Neuromodulation & Middle-Ear Acoustic Conditioning"
            aria-label="Polyvagal Neuromodulation"
            className={`flex items-center justify-center gap-1.5 p-2 sm:px-2.5 sm:py-1.5 rounded-full border transition-all duration-200 text-xs font-semibold min-w-[34px] min-h-[34px] ${
              isPolyvagalModalOpen
                ? 'bg-emerald-500/25 text-emerald-300 border-emerald-500/50 shadow-[0_0_14px_rgba(16,185,129,0.35)]'
                : controller.audio?.polyvagalConfig?.enabled && !controller.audio?.polyvagalConfig?.isEmergencyGrounded
                ? 'bg-emerald-950/50 text-emerald-400 border-emerald-500/40 shadow-[0_0_8px_rgba(16,185,129,0.2)]'
                : 'bg-transparent text-slate-400 border-white/10 hover:text-white hover:border-white/25 hover:bg-white/5'
            }`}
          >
            <div className="relative flex items-center justify-center">
              <Shield
                size={14}
                className={
                  controller.audio?.polyvagalConfig?.enabled && !controller.audio?.polyvagalConfig?.isEmergencyGrounded
                    ? 'text-emerald-400'
                    : ''
                }
              />
              {controller.audio?.polyvagalConfig?.enabled && !controller.audio?.polyvagalConfig?.isEmergencyGrounded && (
                <span className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
              )}
            </div>
            <span className="hidden md:inline text-[10px] uppercase font-bold tracking-wider">Polyvagal</span>
          </button>
        </div>

        {/* Master Play / Pause & Experience Designer Controls */}
        <div className="flex items-center gap-1 bg-black/40 p-0.5 rounded-full border border-white/10 shadow-sm backdrop-blur-sm">
          <button
            onClick={() => {
              if (onToggleMasterPlay) {
                onToggleMasterPlay();
              } else if (isExperienceActive) {
                onTogglePlayExperience();
              } else {
                onTogglePlayExperience(activeExperience || starterExperiences[0]);
              }
            }}
            title={
              (isMasterPlaying !== undefined ? isMasterPlaying : isExperienceActive && !isExperiencePaused)
                ? 'Pause System (Audio, Breath, Progression & Experience)'
                : (isMasterPaused !== undefined ? isMasterPaused : isExperiencePaused)
                  ? 'Resume System (All Audio & Pacing)'
                  : isExperienceActive
                    ? 'Play Experience'
                    : `Play (${activeExperience?.name || starterExperiences[0]?.name || 'Audio & Pacer'})`
            }
            aria-label={
              (isMasterPlaying !== undefined ? isMasterPlaying : isExperienceActive && !isExperiencePaused)
                ? 'Pause System'
                : (isMasterPaused !== undefined ? isMasterPaused : isExperiencePaused)
                  ? 'Resume System'
                  : 'Play System'
            }
            className={`flex items-center justify-center gap-1.5 p-2 sm:px-2.5 sm:py-1.5 rounded-full font-bold text-xs transition-all duration-200 min-w-[34px] min-h-[34px] ${
              (isMasterPlaying !== undefined ? isMasterPlaying : isExperienceActive && !isExperiencePaused)
                ? 'bg-emerald-500/25 text-emerald-300 border border-emerald-500/50 shadow-[0_0_12px_rgba(16,185,129,0.35)] hover:bg-emerald-500/35'
                : (isMasterPaused !== undefined ? isMasterPaused : isExperiencePaused)
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30'
                  : 'bg-teal-500/20 text-teal-300 border border-teal-500/30 hover:bg-teal-500/30 hover:border-teal-400/50'
            }`}
          >
            {(isMasterPlaying !== undefined ? isMasterPlaying : isExperienceActive && !isExperiencePaused) ? (
              <Pause size={13} className="fill-current" />
            ) : (
              <Play size={13} className="fill-current ml-0.5" />
            )}
            <span className="hidden sm:inline text-[10px] uppercase font-bold tracking-wider">
              {(isMasterPlaying !== undefined ? isMasterPlaying : isExperienceActive && !isExperiencePaused)
                ? 'Pause'
                : (isMasterPaused !== undefined ? isMasterPaused : isExperiencePaused)
                  ? 'Resume'
                  : 'Play'}
            </span>
          </button>

          {/* Active Block Progress & Phase Indicator */}
          {isExperienceActive && (
            <div className="hidden lg:flex items-center gap-2 px-2 py-0.5 text-[10px] font-medium text-slate-300 bg-white/5 rounded-full border border-white/10">
              <div className="flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-emerald-300 font-semibold truncate max-w-[110px]">
                  {activeExperience?.blocks[activeBlockIndex]?.label || `Phase ${activeBlockIndex + 1}`}
                </span>
              </div>
              <span className="text-slate-400 text-[9px] tabular-nums">
                {Math.max(
                  0,
                  Math.ceil((activeExperience?.blocks[activeBlockIndex]?.durationSeconds || 4) * (1 - blockProgress))
                )}
                s
              </span>
              <div className="w-8 h-1.5 bg-white/10 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-teal-400 to-emerald-400 transition-all duration-75"
                  style={{ width: `${Math.round(blockProgress * 100)}%` }}
                />
              </div>
            </div>
          )}

          {/* Stop Button */}
          {isExperienceActive && (
            <button
              onClick={onStopExperience}
              title="Stop Experience"
              aria-label="Stop Experience"
              className="p-1.5 rounded-full text-slate-400 hover:text-rose-400 hover:bg-rose-500/15 transition-all min-w-[30px] min-h-[30px] flex items-center justify-center"
            >
              <Square size={11} className="fill-current" />
            </button>
          )}

          {/* Open Designer Modal Button */}
          <button
            onClick={onToggleExperienceModal}
            title="Experience Designer & Synchronized Acoustic-Breath Sequences"
            aria-label="Experience Designer"
            className={`flex items-center justify-center gap-1.5 p-2 sm:px-2.5 sm:py-1.5 rounded-full border transition-all duration-200 text-xs font-semibold min-w-[34px] min-h-[34px] ${
              isExperienceModalOpen
                ? 'bg-amber-500/25 text-amber-300 border-amber-500/50 shadow-[0_0_14px_rgba(245,158,11,0.35)]'
                : 'bg-transparent text-slate-400 border-transparent hover:text-white hover:bg-white/5'
            }`}
          >
            <Sparkles size={13} className={isExperienceActive ? 'text-amber-400' : ''} />
            <span className="hidden md:inline text-[10px] uppercase font-bold tracking-wider">Designer</span>
          </button>
        </div>

        {/* Visualizer Fullscreen Button */}
        <button
          onClick={onToggleVisualizerImmersion}
          title={isVisualizerImmersion ? 'Exit Visualizer Fullscreen' : 'Visualizer Fullscreen Immersion'}
          aria-label={isVisualizerImmersion ? 'Exit Visualizer Fullscreen' : 'Visualizer Fullscreen Immersion'}
          className={`flex items-center justify-center gap-1.5 p-2 sm:px-2.5 sm:py-1.5 rounded-full border transition-all duration-200 text-xs font-semibold min-w-[34px] min-h-[34px] ${
            isVisualizerImmersion
              ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40 shadow-[0_0_12px_rgba(6,182,212,0.25)]'
              : 'bg-transparent text-slate-400 border-white/10 hover:text-white hover:border-white/25 hover:bg-white/5'
          }`}
        >
          {isVisualizerImmersion ? <Minimize size={14} /> : <Maximize size={14} />}
          <span className="hidden lg:inline text-[10px] uppercase font-bold tracking-wider">Fullscreen</span>
        </button>

        {/* Designer Studio / Player Mode Toggle */}
        {onToggleViewMode && (
          <button
            onClick={onToggleViewMode}
            title={viewMode === 'PLAYER' ? 'Switch to Designer Studio' : 'Return to Player View'}
            className={`p-2 rounded-full border transition-colors min-w-[34px] min-h-[34px] flex items-center justify-center ${
              viewMode === 'STUDIO'
                ? 'bg-white/15 text-white border-white/30'
                : 'bg-transparent text-slate-500 border-transparent hover:text-white hover:bg-white/5'
            }`}
          >
            {viewMode === 'PLAYER' ? <Atom size={15} /> : <X size={15} />}
          </button>
        )}

        {/* Theme / Style Editor (Studio only) */}
        {viewMode === 'STUDIO' && onOpenStyleEditor && (
          <button
            onClick={onOpenStyleEditor}
            title="Theme & Style Editor"
            className={`p-2 rounded-full border transition-colors min-w-[34px] min-h-[34px] flex items-center justify-center ${
              showStyleEditor
                ? 'bg-white/15 text-white border-white/30'
                : 'bg-transparent text-slate-500 border-transparent hover:text-white hover:bg-white/5'
            }`}
          >
            <Cpu size={15} />
          </button>
        )}

        {/* Info Button */}
        {onOpenInfo && (
          <button
            onClick={onOpenInfo}
            title="Info & Telemetry"
            className="p-2 rounded-full border transition-colors bg-transparent text-slate-500 border-transparent hover:text-white hover:bg-white/5 min-w-[34px] min-h-[34px] flex items-center justify-center"
          >
            <Info size={15} />
          </button>
        )}
      </div>
    </header>
  );
};
export default TunerTopHeader;
