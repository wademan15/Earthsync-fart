import React, { useState } from 'react';
import { ChevronDown, VolumeX, GitBranch, Layers } from 'lucide-react';
import { TuningTemperament, PresetType, HarmonicChannel } from './visuals/shared';
import { EntrainmentLayerSelector } from './designers/EntrainmentLayerSelector';
import { EntrainmentLayer } from '../../services/audio/AudioTypes';
import { FrequencyPresetGrid } from './tuner/FrequencyPresetGrid';
import { CategoryFilterBar } from './tuner/CategoryFilterBar';

interface TunerBottomPillProps {
  binauralFreq: number;
  isFractalSync: boolean;
  pulseMode: string;
  activeLayers?: EntrainmentLayer[];
  isLayersDropdownOpen?: boolean;
  onToggleLayersDropdown?: () => void;
  onCloseLayersDropdown?: () => void;
  onToggleLayer?: (layer: EntrainmentLayer) => void;
  isConjugatePhase?: boolean;
  onToggleConjugatePhase?: (val: boolean) => void;
  isochronicHardEdge?: boolean;
  onToggleIsochronicHardEdge?: (val: boolean) => void;
  isPACGated?: boolean;
  onTogglePACGated?: (val: boolean) => void;
  activeToneArray: PresetType;
  totalActiveTones: number;
  musicPitchRef?: number;
  musicTemperament?: TuningTemperament;
  isProgressionActive: boolean;
  isFreqDropdownOpen: boolean;
  isToneArrayDropdownOpen: boolean;
  customBinauralInput: string;
  presets: readonly { id: string; name: string; channels: HarmonicChannel[] }[];
  onToggleFreqDropdown: () => void;
  onCloseFreqDropdown: () => void;
  onToggleToneArrayDropdown: () => void;
  onCloseToneArrayDropdown: () => void;
  onCustomBinauralInputChange: (val: string) => void;
  onApplyCustomBinauralFreq: () => void;
  onSelectEntrainmentMode: (freq: number) => void;
  onTogglePulseMode: () => void;
  onSelectToneArray: (pkgId: PresetType) => void;
  onOpenCustomToneModal: () => void;
  onOpenMusicTuningModal?: () => void;
  onOpenProgressionModal: () => void;
  onClearAllTones: () => void;
  onToggleFractalSync: () => void;
  getChannelsForPreset: (pkgId: string) => HarmonicChannel[];
  isChannelActive: (channelId: string) => boolean;
}

export const TunerBottomPill: React.FC<TunerBottomPillProps> = ({
  binauralFreq,
  isFractalSync,
  pulseMode,
  activeLayers,
  isLayersDropdownOpen,
  onToggleLayersDropdown,
  onCloseLayersDropdown,
  onToggleLayer,
  isConjugatePhase,
  onToggleConjugatePhase,
  isochronicHardEdge,
  onToggleIsochronicHardEdge,
  isPACGated,
  onTogglePACGated,
  activeToneArray,
  totalActiveTones,
  isProgressionActive,
  isFreqDropdownOpen,
  isToneArrayDropdownOpen,
  customBinauralInput,
  presets,
  onToggleFreqDropdown,
  onCloseFreqDropdown,
  onToggleToneArrayDropdown,
  onCloseToneArrayDropdown,
  onCustomBinauralInputChange,
  onApplyCustomBinauralFreq,
  onSelectEntrainmentMode,
  onTogglePulseMode,
  onSelectToneArray,
  onOpenCustomToneModal,
  onOpenProgressionModal,
  onClearAllTones,
  onToggleFractalSync,
  getChannelsForPreset,
  isChannelActive,
}) => {
  const [internalLayersOpen, setInternalLayersOpen] = useState(false);
  const isLayersOpen = isLayersDropdownOpen !== undefined ? isLayersDropdownOpen : internalLayersOpen;
  const toggleLayersOpen = onToggleLayersDropdown || (() => setInternalLayersOpen(prev => !prev));
  const closeLayersOpen = onCloseLayersDropdown || (() => setInternalLayersOpen(false));

  const resolvedLayers: EntrainmentLayer[] = activeLayers || (
    pulseMode === 'BINAURAL' ? ['BINAURAL'] :
    pulseMode === 'ISOCHRONIC' ? ['ISOCHRONIC'] :
    pulseMode === 'MONAURAL' ? ['MONAURAL'] :
    pulseMode === 'OFF' ? [] :
    ['BINAURAL']
  );

  const getLayerLabel = () => {
    if (resolvedLayers.length === 0) return 'NO BEATS';
    if (resolvedLayers.length === 1) {
      if (resolvedLayers[0] === 'BINAURAL') return 'BIN';
      if (resolvedLayers[0] === 'ISOCHRONIC') return 'ISO';
      if (resolvedLayers[0] === 'MONAURAL') return 'MON';
    }
    return `${resolvedLayers.length} LAYERS`;
  };

  const getPillColor = () => {
    if (resolvedLayers.length === 0) return 'text-slate-500 border-white/5 bg-transparent';
    if (resolvedLayers.length > 1) return 'bg-purple-500/25 text-purple-200 border-purple-500/40 shadow-[0_0_10px_rgba(168,85,247,0.2)]';
    if (resolvedLayers.includes('BINAURAL')) return 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30';
    if (resolvedLayers.includes('ISOCHRONIC')) return 'bg-amber-500/20 text-amber-300 border-amber-500/30';
    if (resolvedLayers.includes('MONAURAL')) return 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30';
    return 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30';
  };

  return (
    <>
      {/* Brainwave Entrainment Frequency Selector */}
      <FrequencyPresetGrid
        binauralFreq={binauralFreq}
        isFractalSync={isFractalSync}
        isOpen={isFreqDropdownOpen}
        customBinauralInput={customBinauralInput}
        onToggleDropdown={onToggleFreqDropdown}
        onCloseDropdown={onCloseFreqDropdown}
        onCustomInputChange={onCustomBinauralInputChange}
        onApplyCustomFreq={onApplyCustomBinauralFreq}
        onSelectEntrainmentMode={onSelectEntrainmentMode}
      />

      {/* Entrainment Architecture Layer Selector Popover Dropdown */}
      <div className="relative shrink-0 flex items-center">
        <button
          onClick={(e) => {
            e.stopPropagation();
            toggleLayersOpen();
          }}
          className={`flex items-center gap-1 px-1.5 sm:px-2 py-0.5 sm:py-1 rounded text-[8px] sm:text-[9px] font-bold uppercase tracking-wider transition-all border shrink-0 ${getPillColor()}`}
          title="Entrainment Architecture: Layer Binaural, Isochronic & Monaural Beats"
        >
          <Layers size={9} className="shrink-0 opacity-80" />
          <span>{getLayerLabel()}</span>
          <ChevronDown size={8} className="opacity-70 shrink-0" />
        </button>

        {isLayersOpen && (
          <>
            <div className="fixed inset-0 z-40" onClick={(e) => { e.stopPropagation(); closeLayersOpen(); }} />
            <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 bg-slate-950/95 backdrop-blur-xl border border-white/10 rounded-xl shadow-2xl overflow-hidden z-50 animate-in fade-in zoom-in-95 duration-150 flex flex-col">
              <EntrainmentLayerSelector
                activeLayers={resolvedLayers}
                onToggleLayer={(layer) => {
                  if (onToggleLayer) {
                    onToggleLayer(layer);
                  } else {
                    onTogglePulseMode();
                  }
                }}
                isConjugatePhase={isConjugatePhase}
                onToggleConjugatePhase={onToggleConjugatePhase}
                isochronicHardEdge={isochronicHardEdge}
                onToggleIsochronicHardEdge={onToggleIsochronicHardEdge}
                isPACGated={isPACGated}
                onTogglePACGated={onTogglePACGated}
                variant="popover"
              />
            </div>
          </>
        )}
      </div>

      {/* Tone Array Package Selector Dropdown */}
      <CategoryFilterBar
        activeToneArray={activeToneArray}
        totalActiveTones={totalActiveTones}
        presets={presets}
        isToneArrayDropdownOpen={isToneArrayDropdownOpen}
        isProgressionActive={isProgressionActive}
        onToggleDropdown={onToggleToneArrayDropdown}
        onCloseDropdown={onCloseToneArrayDropdown}
        onSelectToneArray={onSelectToneArray}
        onOpenCustomToneModal={onOpenCustomToneModal}
        onOpenProgressionModal={onOpenProgressionModal}
        onClearAllTones={onClearAllTones}
        getChannelsForPreset={getChannelsForPreset}
        isChannelActive={isChannelActive}
      />

      {totalActiveTones > 0 && (
        <button
          onClick={onClearAllTones}
          className="flex items-center gap-0.5 sm:gap-1 px-1.5 sm:px-2 py-0.5 sm:py-1 rounded text-[8px] sm:text-[9px] font-bold uppercase tracking-wider bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 hover:text-rose-100 border border-rose-500/40 transition-all shrink-0 active:scale-95"
          title="Clear all active tones across all arrays"
        >
          <VolumeX size={10} className="sm:w-[11px] sm:h-[11px]" />
          <span className="hidden sm:inline">Clear</span>
          <span>({totalActiveTones})</span>
        </button>
      )}

      {/* Fractal Sync Toggle */}
      <button
        onClick={onToggleFractalSync}
        className={`p-1 sm:p-1.5 rounded-full transition-colors shrink-0 ${isFractalSync ? 'text-emerald-400 bg-emerald-500/10 animate-pulse' : 'text-slate-600 hover:text-slate-400'}`}
        title={isFractalSync ? 'Fractal Sync: ON' : 'Fractal Sync: OFF'}
      >
        <GitBranch size={12} className="sm:w-[14px] sm:h-[14px]" />
      </button>
    </>
  );
};
