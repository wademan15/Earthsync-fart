import React, { useState, useEffect, useLayoutEffect, useRef, useCallback, useContext, useMemo } from 'react';
import { 
  ChevronDown, ChevronRight, ChevronLeft, Globe, 
  Check, Pause, Grid, Heart, X, RotateCcw, Music, Save
} from 'lucide-react';
import { ViewMode, SensorMode } from '../../types';
import { StyleContext, DEFAULT_UI_CONFIG } from '../system/StyleEditor';
import { ErrorBoundary } from '../system/ErrorBoundary';
import { Fader, ModulationFader } from '../ui/Faders';
import { VisualizerCanvas } from './VisualizerCanvas'; 
import { SystemMonitor } from './visuals/SystemMonitor'; 
import { VISUALIZER_MODES, VISUALIZER_PLUGINS } from './visuals/VisualizerRegistry'; 
import { EarthSyncLogo } from '../ui/EarthSyncLogo'; 
import { getPacerColors } from '../../services/audio/pacerStyles';

import { BreathDesigner, TideMeter, DEFAULT_BREATH_PRESETS, PatternPreviewBar, CATEGORY_GRADIENTS, CATEGORY_ICONS, CATEGORY_ACCENT, BreathPreset } from './designers/BreathDesigner';
import { type HarmonicPackage } from './designers/HarmonicPackageMenu'; 
import { TheKnob } from './TheKnob';
import { HarmonicDock } from './HarmonicDock';
import { TunerBottomPill } from './TunerBottomPill';
import { TunerTopHeader } from './tuner/TunerTopHeader';
import { ImmersionExperienceOverlay } from './tuner/ImmersionExperienceOverlay';
import { BreathArchitectSheet } from './tuner/BreathArchitectSheet';
import { CustomToneArrayModal } from './tuner/CustomToneArrayModal';
import { TuningControlsDeck } from './tuner/TuningControlsDeck';
import { StudioPanelsDrawer } from './tuner/StudioPanelsDrawer';

const HarmonicPackageMenu = React.lazy(() => import('./designers/HarmonicPackageMenu').then(m => ({ default: m.HarmonicPackageMenu })));
const MusicalTuningModal = React.lazy(() => import('./MusicalTuningModal').then(m => ({ default: m.MusicalTuningModal })));
const MusicalProgressionModal = React.lazy(() => import('./MusicalProgressionModal').then(m => ({ default: m.MusicalProgressionModal })));
const AudioMixerModal = React.lazy(() => import('./AudioMixerModal').then(m => ({ default: m.AudioMixerModal })));
const PolyvagalModal = React.lazy(() => import('./PolyvagalModal').then(m => ({ default: m.PolyvagalModal })));
const ExperienceDesignerModal = React.lazy(() => import('./ExperienceDesignerModal').then(m => ({ default: m.ExperienceDesignerModal })));
import { 
  ExperienceDef, 
  ExperienceBlock, 
  STARTER_EXPERIENCES, 
  resolveBlockFrequencies 
} from '../../services/audio/experienceDesigner';
import { 
  MOOD_CATEGORIES, 
  MusicalMood, 
  ProgressionDef, 
  getChordFrequencies,
  getNextGenerativeChordIndex,
  ResolvedChordNote,
  getAllMoodCategories,
  loadCustomProgressions
} from '../../services/audio/chordProgressions';
import { computeVoiceLeading } from '../../services/audio/ChordGlideEngine';

import { usePlanetaryController } from '../../hooks/usePlanetaryController';
import { HarmonicColorWheelId } from '../../data/colorWheels';
import { getActiveColorWheelId, setActiveColorWheelId, subscribeColorWheel } from '../../services/kinematics/color';
import { UNIVERSAL_CHANNELS, ALL_CHANNELS, CHORD_VOICE_CHANNELS, ENTRAINMENT_MODES, PRESETS, PresetType, getMerrickColor, HarmonicChannel, createChannel, DEFAULT_CUSTOM_CHANNELS, KNOB_CHANNELS, TuningTemperament, TEMPERAMENTS, calculateMusicalScaleFreqs, MUSIC_SCALE_CHANNELS } from './visuals/shared';
import { resolveActiveLayers, EntrainmentLayer } from '../../services/audio/AudioTypes';

interface Props {
  metrics: Record<string, unknown>; 
  bpm: number; coherence: number; lastBeatTime: number; mode: string;
  theme: Record<string, unknown>; isDarkMode: boolean; id: string; index: number; isMinimized: boolean;
  onToggleMinimize?: (id: string) => void; onDragStart?: (e: React.DragEvent, index: number) => void;
  onDragOver?: (e: React.DragEvent, index: number) => void; onDrop?: (e: React.DragEvent, index: number) => void;
  onOpenInfo?: () => void; onTogglePower?: (id: string) => void; isPowered?: boolean;
  standalone?: boolean; isSimulating?: boolean; onSimBpmChange?: (bpm: number) => void; 
  onSimCoherenceChange?: (enabled: boolean) => void; isCoherenceSimulated?: boolean;
  viewMode: ViewMode; sensorMode: SensorMode | null; onBreathConfigChange?: (config: Record<string, unknown>) => void;
  isVisualizerImmersion?: boolean;
  onToggleVisualizerImmersion?: (forced?: boolean) => void;
  onToggleViewMode?: () => void;
  onOpenStyleEditor?: () => void;
  showStyleEditor?: boolean;
}

export type LayoutProfile = 'MOBILE_PORTRAIT' | 'MOBILE_LANDSCAPE' | 'DESKTOP';
export interface LayoutElement { x: number; y: number; scale: number; opacity: number; }
export interface LayoutProfileData { mandala: LayoutElement; pacer: LayoutElement; header: LayoutElement; topButtons: LayoutElement; pill: LayoutElement; dock: LayoutElement; meter: LayoutElement; menuBtn: LayoutElement; sideNav: LayoutElement; uiX: number; footerY: number; meterScale: number; }
const elem = (y: number, x: number = 0, scale: number = 1, opacity: number = 1): LayoutElement => ({ x, y, scale, opacity });

const LAYOUT_DEFAULTS: Record<LayoutProfile, LayoutProfileData> = {
    MOBILE_PORTRAIT: { mandala: elem(0.046, 0.00, 1.40, 1.0), pacer: elem(0.046, 0.00, 1.15, 1.0), header: elem(-5.00, 0.00, 1.00, 1.0), topButtons: elem(1.10, 0.00, 1.00, 1.0), pill: elem(4.18, 0.00, 1.00, 1.0), dock: elem(-0.10, 0.00, 1.00, 1.0), meter: elem(0.00, 0.00, 1.00, 1.0), menuBtn: elem(1.10, 1.00, 1.00, 1.0), sideNav: elem(-1.40, 0.50, 0.70, 0.60), uiX: 0, footerY: 0, meterScale: 1.0 },
    MOBILE_LANDSCAPE: { mandala: elem(0.046, 0, 1.15), pacer: elem(0.046, 0, 1.00), header: elem(1.0), topButtons: elem(2.5), pill: elem(4.80), dock: elem(0.00), meter: elem(0), menuBtn: elem(1.0, 1.0), sideNav: elem(0, 1.0), uiX: 0, footerY: 0, meterScale: 1.0 },
    DESKTOP: { mandala: elem(0.046, 0, 1.0), pacer: elem(0.046, 0, 0.75), header: elem(1.0), topButtons: elem(2.5), pill: elem(5.40), dock: elem(0.10), meter: elem(0), menuBtn: elem(2.0, 2.0), sideNav: elem(0, 2.0), uiX: 0, footerY: 0, meterScale: 1.0 }
};

export {
  SENTIC_EMOTION_META,
  generateSenticSvgPath,
  COMPOSER_WARP_PRESETS,
  PULSE_PRESETS,
  PACER_BELL_TONES,
  PACER_BELL_KEYS,
  PACER_TIDE_TEXTURES,
  getBellPitchHz
} from './tuner/TuningControlsDeck';

const ToastNotification = ({ 
    message, 
    visible, 
    style 
}: { 
    message: string; 
    visible: boolean; 
    style?: React.CSSProperties; 
}) => (
    <div 
        className={`absolute z-[60] pointer-events-none transition-all duration-300 ease-out ${
            visible ? 'opacity-100 translate-y-0 scale-100' : 'opacity-0 translate-y-2 scale-95'
        }`}
        style={style}
    >
        <div className="bg-black/90 backdrop-blur-md border border-cyan-500/40 text-cyan-300 px-3.5 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-widest shadow-[0_0_20px_rgba(6,182,212,0.25)] flex items-center gap-2">
            <Check size={12} className="text-cyan-400" />
            <span>{message}</span>
        </div>
    </div>
);

// Fast storage cache to eliminate synchronous localStorage main-thread blocking during mount
const storageCache: Record<string, string | null> = {};
const getCachedStorage = (key: string): string | null => {
  if (key in storageCache) return storageCache[key];
  try {
    const val = typeof window !== 'undefined' ? localStorage.getItem(key) : null;
    storageCache[key] = val;
    return val;
  } catch {
    return null;
  }
};

const setCachedStorage = (key: string, value: string): void => {
  storageCache[key] = value;
  if (typeof window === 'undefined') return;
  const save = () => {
    try {
      localStorage.setItem(key, value);
    } catch (e) {
      console.warn(`[Storage] Failed to save key "${key}":`, e);
    }
  };
  if ('requestIdleCallback' in window) {
    (window as any).requestIdleCallback(save);
  } else {
    setTimeout(save, 16);
  }
};

interface HarmonicDockItemProps { label: string; icon: React.ElementType; isActive: boolean; onClick: () => void; onContextMenu?: (e: React.MouseEvent) => void; color?: string; }
const HarmonicDockItem = ({ label, icon: Icon, isActive, onClick, onContextMenu, color }: HarmonicDockItemProps) => ( <button onClick={onClick} onContextMenu={onContextMenu} className={`flex flex-col items-center gap-1 shrink-0 p-1 transition-all duration-300 ${isActive ? 'scale-110' : 'hover:scale-105'}`} style={{ minWidth: '0' }}> <div className={`w-8 h-8 rounded-full flex items-center justify-center border transition-all duration-300 ${isActive ? 'bg-zinc-950 border-opacity-100 shadow-[0_0_12px_currentColor]' : 'bg-zinc-950 border-white/20 text-slate-500'}`} style={{ color: isActive ? color : undefined, borderColor: isActive ? color : undefined }}><Icon size={14} className={isActive ? "animate-pulse" : ""} /></div> <span className={`text-[7px] font-bold uppercase tracking-wider whitespace-nowrap overflow-hidden text-ellipsis max-w-[80px] drop-shadow-md ${isActive ? 'text-white' : 'text-slate-400'}`} style={{textShadow: '0 2px 4px rgba(0,0,0,0.8)'}}>{label}</span> </button> );

interface PianoKeyItemProps { 
    label: string; 
    isActive: boolean; 
    onClick: () => void; 
    onContextMenu?: (e: React.MouseEvent) => void; 
    color?: string; 
    note?: string; 
    isChordTone?: boolean;
    isUserActive?: boolean;
}
const PianoKeyItem = ({ label, isActive, onClick, onContextMenu, color, note, isChordTone, isUserActive }: PianoKeyItemProps) => { 
    const isBlackKey = note?.includes('#'); 
    const cleanId = `piano-key-${label.toLowerCase().replace(/[^a-z0-9]/g, '')}`;
    const keyActive = isActive || isUserActive || isChordTone;
    
    return ( 
        <button 
            id={cleanId}
            onClick={onClick} 
            onContextMenu={onContextMenu} 
            title={`${label} (${isUserActive ? 'User Active - Click to mute' : isChordTone ? 'Chord Tone - Click to play manual tone' : 'Muted - Click to play'})`}
            className={`relative flex flex-col items-center justify-end shrink-0 transition-all duration-150 border overflow-hidden ${
                isBlackKey 
                    ? 'w-[4.8vw] sm:w-[22px] h-6 z-10 -mx-[2.4vw] sm:-mx-[11px] self-start rounded-b-sm shadow-md' 
                    : 'w-[7.5vw] sm:w-[34px] h-10 z-0 rounded-b-md shadow-sm'
            } ${
                keyActive 
                    ? 'scale-[1.03] z-20' 
                    : isBlackKey 
                        ? 'bg-zinc-900 border-white/10 hover:bg-zinc-800' 
                        : 'bg-zinc-100 border-zinc-300 hover:bg-white'
            }`} 
            style={{ 
                color: keyActive ? (color || '#38bdf8') : undefined, 
                borderColor: keyActive ? (color || '#38bdf8') : (isBlackKey ? 'rgba(255,255,255,0.2)' : 'rgba(0,0,0,0.25)'), 
                backgroundColor: isUserActive 
                    ? (color || '#38bdf8') 
                    : isChordTone 
                        ? (isBlackKey ? '#27272a' : '#e4e4e7') 
                        : (isBlackKey ? '#18181b' : '#f4f4f5'),
                boxShadow: isUserActive 
                    ? `0 0 14px ${color || '#38bdf8'}, inset 0 0 8px rgba(255,255,255,0.4)` 
                    : isChordTone 
                        ? `0 0 10px ${color || '#38bdf8'}` 
                        : undefined
            }}
        > 
            {isUserActive && (
                <span 
                    className="absolute top-1 w-1.5 h-1.5 rounded-full bg-white animate-pulse shadow-[0_0_6px_#fff]" 
                />
            )}
            {isChordTone && !isUserActive && (
                <span 
                    className="absolute top-1 w-1.5 h-1.5 rounded-full border border-white animate-ping"
                    style={{ backgroundColor: color || '#38bdf8' }}
                />
            )}
            <span className={`font-bold mb-0.5 tracking-tighter ${
                isUserActive 
                    ? 'text-white drop-shadow-[0_1px_3px_rgba(0,0,0,0.9)] text-[8px]' 
                    : isChordTone 
                        ? (isBlackKey ? 'text-white text-[7px]' : 'text-zinc-900 text-[8px]') 
                        : isBlackKey 
                            ? 'text-[7px] text-zinc-300' 
                            : 'text-[8px] text-zinc-800'
            }`}>
                {label}
            </span> 
        </button> 
    ); 
};

export const PlanetaryTunerModule = React.memo<Props>((props) => {
  const uiConfig = useContext(StyleContext) || DEFAULT_UI_CONFIG;
  const controller = usePlanetaryController(props);
  const physicsEngine = controller.lattice || (controller as Record<string, unknown>).physics;
  
  const hasSensors = props.sensorMode !== 'AETHER' && props.sensorMode !== null && props.sensorMode !== undefined;

  const activeId = null;
  const [showSystemMonitor, setShowSystemMonitor] = useState(false); 
  const [isBpmScanning, setIsBpmScanning] = useState(false);
  const [toast, setToast] = useState<{ message: string, visible: boolean }>({ message: '', visible: false });

  const [activeToneArray, setActiveToneArray] = useState<PresetType>('UNIVERSAL');
  const [isToneArrayDropdownOpen, setIsToneArrayDropdownOpen] = useState(false);
  const [isCustomToneModalOpen, setIsCustomToneModalOpen] = useState(false);

  // The Knob (Rotary Dial Frequency Selector) State
  const [knobFreq, setKnobFreq] = useState<number>(() => {
    try {
      const saved = getCachedStorage('ppl_knob_freq');
      if (saved) {
        const parsed = parseFloat(saved);
        if (!isNaN(parsed) && parsed >= 20 && parsed <= 2000) return parsed;
      }
    } catch {}
    return 432.0;
  });

  const handleKnobFreqChange = useCallback((newFreq: number) => {
    setKnobFreq(newFreq);
    setCachedStorage('ppl_knob_freq', newFreq.toString());
    if (controller.loopDataRef && controller.loopDataRef.current) {
      if (!controller.loopDataRef.current.customFrequencies) {
        controller.loopDataRef.current.customFrequencies = {};
      }
      controller.loopDataRef.current.customFrequencies['UNIVERSAL_799'] = newFreq;
    }
  }, [controller.loopDataRef]);

  // Phase Conjugate / Harmonic Cascade Custom Frequencies
  const [customFrequencies, setCustomFrequencies] = useState<Record<string, number>>({});

  // Musical Keyboard Scale State (Concert Pitch & Temperament)
  const [musicPitchRef, setMusicPitchRef] = useState<number>(() => {
    try {
      const saved = getCachedStorage('ppl_music_pitch');
      if (saved) {
        const parsed = parseFloat(saved);
        if (!isNaN(parsed) && parsed >= 380 && parsed <= 480) return parsed;
      }
    } catch {}
    return 440.0;
  });

  const [musicTemperament, setMusicTemperament] = useState<TuningTemperament>(() => {
    try {
      const saved = getCachedStorage('ppl_music_temperament') as TuningTemperament;
      if (saved && saved !== '12TET' && TEMPERAMENTS.some(t => t.id === saved)) return saved;
    } catch {}
    // The chord engine and default progressions (e.g. Ocean of Calm) are authored in pure Just Intonation
    return 'JUST_INTONATION';
  });

  const [musicOctaveShift, setMusicOctaveShift] = useState<number>(() => {
    try {
      const saved = getCachedStorage('ppl_music_octave_shift');
      if (saved) {
        const parsed = parseInt(saved, 10);
        if (!isNaN(parsed) && parsed >= -2 && parsed <= 2) return parsed;
      }
    } catch {}
    return 0;
  });

  const [isMusicTuningModalOpen, setIsMusicTuningModalOpen] = useState(false);
  const [isProgressionModalOpen, setIsProgressionModalOpen] = useState(false);

  // Musical Mode: Mood & Chord Progressions State
  // STRICT USER DIRECTIVE: Music mode is OFF by default upon boot
  const [isProgressionActive, setIsProgressionActive] = useState<boolean>(false);

  // Load custom user progressions from localStorage
  const [customProgressions, setCustomProgressions] = useState<ProgressionDef[]>(() => {
    return loadCustomProgressions();
  });

  const allMoodCategories = useMemo(() => {
    return getAllMoodCategories(customProgressions);
  }, [customProgressions]);

  const [activeMood, setActiveMood] = useState<MusicalMood>(() => {
    try {
      const saved = getCachedStorage('ppl_active_mood') as MusicalMood;
      if (saved && MOOD_CATEGORIES.some(m => m.mood === saved)) return saved;
    } catch {}
    return 'SERENITY';
  });

  const [activeProgressionId, setActiveProgressionId] = useState<string>(() => {
    try {
      const saved = getCachedStorage('ppl_active_progression_id');
      if (saved) return saved;
    } catch {}
    return 'serenity_ocean';
  });

  const [isCustomPitchOpen, setIsCustomPitchOpen] = useState(false);
  const [currentChordIndex, setCurrentChordIndex] = useState<number>(0);
  const [progressionAdvanceMode, setProgressionAdvanceMode] = useState<'BREATH_CYCLE' | 'BREATH_PHASE' | 'BREATH_EXHALE' | 'MANUAL'>('BREATH_PHASE');
  const [isHarmonicDrone, setIsHarmonicDrone] = useState(false);

  // Universal Master Play / Pause State (Synchronizes all audio voices, breath pacer, experience runner, and progressions)
  const [isMasterPaused, setIsMasterPaused] = useState<boolean>(false);
  const isMasterPausedRef = useRef<boolean>(false);
  isMasterPausedRef.current = isMasterPaused;
  const masterPauseTimeRef = useRef<number>(0);
  const progressionAnimFrameRef = useRef<number | null>(null);

  // Get active progression object from all categories (including custom)
  const currentMoodObj = useMemo(() => {
    return allMoodCategories.find(m => m.mood === activeMood) || allMoodCategories[0];
  }, [allMoodCategories, activeMood]);

  const currentProgressionObj = useMemo(() => {
    return currentMoodObj.progressions.find(p => p.id === activeProgressionId) 
      || allMoodCategories.flatMap(m => m.progressions).find(p => p.id === activeProgressionId)
      || currentMoodObj.progressions[0]
      || allMoodCategories[0].progressions[0];
  }, [currentMoodObj, allMoodCategories, activeProgressionId]);

  // Automatically switch to preferred tuning when a progression is selected to prevent dissonance
  const applyProgressionTuning = useCallback((prog: ProgressionDef) => {
    if (prog.recommendedTemperament) {
      setMusicTemperament(prog.recommendedTemperament);
      try {
        localStorage.setItem('ppl_music_temperament', prog.recommendedTemperament);
      } catch {}
    }
    if (prog.recommendedPitch) {
      setMusicPitchRef(prog.recommendedPitch);
      try {
        localStorage.setItem('ppl_music_pitch', prog.recommendedPitch.toString());
      } catch {}
    }
  }, []);

  const handleSelectMood = useCallback((mood: MusicalMood) => {
    setActiveMood(mood);
    try {
      localStorage.setItem('ppl_active_mood', mood);
    } catch {}
    const categories = getAllMoodCategories(loadCustomProgressions());
    const newMoodObj = categories.find(m => m.mood === mood) || categories[0];
    if (newMoodObj && newMoodObj.progressions.length > 0) {
      const firstProg = newMoodObj.progressions[0];
      setActiveProgressionId(firstProg.id);
      try {
        localStorage.setItem('ppl_active_progression_id', firstProg.id);
      } catch {}
      // Automatically apply preferred tuning for this mood/progression
      applyProgressionTuning(firstProg);
    }
    setCurrentChordIndex(0);
  }, [applyProgressionTuning]);

  const handleSelectProgression = useCallback((progId: string) => {
    setActiveProgressionId(progId);
    try {
      localStorage.setItem('ppl_active_progression_id', progId);
    } catch {}
    const allProgs = getAllMoodCategories(loadCustomProgressions()).flatMap(m => m.progressions);
    const prog = allProgs.find(p => p.id === progId);
    if (prog) {
      // Automatically switch to preferred tuning to avoid dissonance
      applyProgressionTuning(prog);
    }
    setCurrentChordIndex(0);
  }, [applyProgressionTuning]);

  const handleSaveAndActivateProgression = useCallback((prog: ProgressionDef) => {
    const updatedCustom = loadCustomProgressions();
    setCustomProgressions(updatedCustom);
    setActiveMood(prog.mood);
    try { localStorage.setItem('ppl_active_mood', prog.mood); } catch {}
    setActiveProgressionId(prog.id);
    try { localStorage.setItem('ppl_active_progression_id', prog.id); } catch {}
    applyProgressionTuning(prog);
    setIsProgressionActive(true);
    try { localStorage.setItem('ppl_chord_progression_active', 'true'); } catch {}
    setActiveToneArray('MUSIC_SCALE');
    setCurrentChordIndex(0);
    if (controller.temporal.entrainmentMode === 'SILENT') {
      controller.temporal.setEntrainmentMode('SYNCED');
    }
    if ((controller.temporal.entrainmentMode === 'SYNCED' || controller.temporal.entrainmentMode === 'SILENT') && !controller.temporal.isBreathActive) {
      controller.temporal.setIsBreathActive(true);
      controller.temporal.setBreathStartTime(performance.now() / 1000);
    }
    if (!controller.audioSys.audioEnabled) {
      controller.audioSys.setAudioEnabled(true);
      controller.audioSys.initAudio(
        controller.atmosphere.reverbConfig,
        controller.temporal.breathConfig,
        controller.temporal.binauralFreqs,
        controller.atmosphere.delayConfig
      );
    }
    setToast({ message: `Activated "${prog.name}" with preferred tuning`, visible: true });
    setTimeout(() => setToast(t => ({ ...t, visible: false })), 2000);
  }, [applyProgressionTuning, controller]);

  const handleToggleProgression = useCallback(() => {
    setIsProgressionActive(prev => {
      const next = !prev;
      try {
        localStorage.setItem('ppl_chord_progression_active', next.toString());
      } catch {}
      if (next) {
        // Automatically activate MUSIC_SCALE array so the keyboard dock is shown and tuned
        setActiveToneArray('MUSIC_SCALE');
        // Ensure preferred tuning is applied for active progression
        if (currentProgressionObj) {
          applyProgressionTuning(currentProgressionObj);
        }
        if (controller.temporal.entrainmentMode === 'SILENT') {
          controller.temporal.setEntrainmentMode('SYNCED');
        }
        if ((controller.temporal.entrainmentMode === 'SYNCED' || controller.temporal.entrainmentMode === 'SILENT') && !controller.temporal.isBreathActive) {
          controller.temporal.setIsBreathActive(true);
          controller.temporal.setBreathStartTime(performance.now() / 1000);
        }
        if (!controller.audioSys.audioEnabled) {
          controller.audioSys.setAudioEnabled(true);
          controller.audioSys.initAudio(
            controller.atmosphere.reverbConfig,
            controller.temporal.breathConfig,
            controller.temporal.binauralFreqs,
            controller.atmosphere.delayConfig
          );
        }
      }
      return next;
    });
  }, [currentProgressionObj, applyProgressionTuning, controller]);

  const handleAdvanceChord = useCallback((dir: 1 | -1) => {
    if (!currentProgressionObj || currentProgressionObj.chords.length === 0) return;
    const len = currentProgressionObj.chords.length;
    if (dir === 1 && controller.audio.chordGlideConfig?.generativeDrift) {
      setCurrentChordIndex(prev => getNextGenerativeChordIndex(prev, len, currentProgressionObj.mood));
    } else {
      setCurrentChordIndex(prev => (prev + dir + len) % len);
    }
  }, [currentProgressionObj, controller.audio.chordGlideConfig?.generativeDrift]);

  const handleMusicPitchChange = useCallback((newPitch: number) => {
    setMusicPitchRef(newPitch);
    try {
      localStorage.setItem('ppl_music_pitch', newPitch.toString());
    } catch {}
  }, []);

  const handleMusicTemperamentChange = useCallback((newTemp: TuningTemperament) => {
    setMusicTemperament(newTemp);
    try {
      localStorage.setItem('ppl_music_temperament', newTemp);
    } catch {}
  }, []);

  const handleMusicOctaveShiftChange = useCallback((newShift: number) => {
    setMusicOctaveShift(newShift);
    try {
      localStorage.setItem('ppl_music_octave_shift', newShift.toString());
    } catch {}
  }, []);

  const musicScaleChannels = useMemo(() => {
    const freqs = calculateMusicalScaleFreqs(musicPitchRef, musicTemperament, 3 + musicOctaveShift, 3);
    return freqs.map((item, idx) => 
      createChannel(
        'UNIVERSAL',
        800 + idx,
        item.freq,
        () => 8.0,
        0.8,
        item.note,
        item.octave
      )
    );
  }, [musicPitchRef, musicTemperament, musicOctaveShift]);

  // Custom Tone Array Management
  const [customChannels, setCustomChannels] = useState<HarmonicChannel[]>(() => {
    try {
      const saved = getCachedStorage('ppl_custom_channels');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed.map((item: any, i: number) => ({
            id: item.id || `UNIVERSAL_${700 + i}`,
            type: 'UNIVERSAL',
            name: item.name || `Tone ${i + 1}`,
            noteLabel: item.noteLabel || item.name || `${item.freq}Hz`,
            freq: Number(item.freq) || (100 * (i + 1)),
            multiplier: (Number(item.freq) || 100) / 256.0,
            binauralBeat: 8.0,
            defaultVol: item.defaultVol || 0.8
          }));
        }
      }
    } catch (e) {
      console.error("Failed to load custom channels", e);
    }
    return DEFAULT_CUSTOM_CHANNELS;
  });

  const customFreqMap = useMemo(() => {
    const map: Record<string, number> = { ...customFrequencies };
    customChannels.forEach(ch => {
      map[ch.id] = ch.freq;
    });
    musicScaleChannels.forEach(ch => {
      map[ch.id] = ch.freq;
    });
    map['UNIVERSAL_799'] = knobFreq;
    return map;
  }, [customFrequencies, customChannels, musicScaleChannels, knobFreq]);

  useLayoutEffect(() => {
    if (controller.loopDataRef && controller.loopDataRef.current) {
      controller.loopDataRef.current.customFrequencies = {
        ...(controller.loopDataRef.current.customFrequencies || {}),
        ...customFreqMap
      };
    }
  }, [customFreqMap, controller.loopDataRef]);

  const updateCustomChannel = (index: number, key: 'freq' | 'name' | 'noteLabel', value: any) => {
    setCustomChannels(prev => {
      const next = [...prev];
      if (next[index]) {
        const updated = { ...next[index], [key]: value };
        if (key === 'freq') {
          const num = parseFloat(value) || 100;
          updated.freq = num;
          updated.multiplier = num / 256.0;
        }
        if (key === 'name' && !updated.noteLabel) {
          updated.noteLabel = value;
        }
        next[index] = updated;
        setCachedStorage('ppl_custom_channels', JSON.stringify(next));
      }
      return next;
    });
  };

  const addCustomChannel = () => {
    if (customChannels.length >= 16) {
      setToast({ message: 'Max 16 Custom Tones', visible: true });
      setTimeout(() => setToast(t => ({...t, visible: false})), 1500);
      return;
    }
    setCustomChannels(prev => {
      const nextIdx = prev.length;
      const newFreq = 432 + (nextIdx * 50);
      const newChannel = createChannel('UNIVERSAL', 700 + nextIdx, newFreq, () => 8.0, 0.8, `Tone ${nextIdx + 1} (${newFreq}Hz)`);
      const next = [...prev, newChannel];
      setCachedStorage('ppl_custom_channels', JSON.stringify(next));
      return next;
    });
  };

  const removeCustomChannel = (index: number) => {
    if (customChannels.length <= 1) return;
    setCustomChannels(prev => {
      const next = prev.filter((_, i) => i !== index);
      setCachedStorage('ppl_custom_channels', JSON.stringify(next));
      return next;
    });
  };

  const resetCustomChannelsToDefault = () => {
    setCustomChannels(DEFAULT_CUSTOM_CHANNELS);
    setCachedStorage('ppl_custom_channels', JSON.stringify(DEFAULT_CUSTOM_CHANNELS));
    setToast({ message: 'Custom Tones Reset', visible: true });
    setTimeout(() => setToast(t => ({...t, visible: false})), 1500);
  };

  const currentChordScaleIds = useMemo(() => {
    if (!isProgressionActive || !currentProgressionObj) return new Set<string>();
    const activeChord = currentProgressionObj.chords[currentChordIndex % currentProgressionObj.chords.length];
    if (!activeChord) return new Set<string>();
    const chordInfo = getChordFrequencies(activeChord, musicPitchRef, musicTemperament, musicOctaveShift);
    return new Set(chordInfo.notes.map(n => n.channelId));
  }, [isProgressionActive, currentProgressionObj, currentChordIndex, musicPitchRef, musicTemperament, musicOctaveShift]);

  const dockMutes = useMemo(() => {
    const m = { ...controller.audio.mutes };
    if (!isProgressionActive || !currentProgressionObj) return m;
    musicScaleChannels.forEach(ch => {
      const isUserActive = controller.audio.mutes[ch.id] === false;
      const isChordTone = currentChordScaleIds.has(ch.id);
      m[ch.id] = !(isUserActive || isChordTone);
    });
    return m;
  }, [isProgressionActive, currentProgressionObj, currentChordScaleIds, musicScaleChannels, controller.audio.mutes]);

  const totalActiveTones = useMemo(() => {
    const activeChs = activeToneArray === 'CUSTOM' ? customChannels : (activeToneArray === 'KNOB' ? KNOB_CHANNELS : (activeToneArray === 'MUSIC_SCALE' ? musicScaleChannels : ALL_CHANNELS));
    return activeChs.filter(ch => !dockMutes[ch.id]).length;
  }, [dockMutes, activeToneArray, customChannels, musicScaleChannels]);

  const clearAllTones = useCallback(() => {
    controller.audio.setMutes((prev: Record<string, boolean>) => {
      const next = { ...prev };
      ALL_CHANNELS.forEach(ch => {
        next[ch.id] = true;
      });
      CHORD_VOICE_CHANNELS.forEach(ch => {
        next[ch.id] = true;
      });
      customChannels.forEach(ch => {
        next[ch.id] = true;
      });
      musicScaleChannels.forEach(ch => {
        next[ch.id] = true;
      });
      return next;
    });
    setToast({ message: 'All Tones Cleared', visible: true });
    setTimeout(() => setToast(t => ({...t, visible: false})), 1500);
  }, [controller.audio, customChannels, musicScaleChannels]);

  const [showHarmonicMenu, setShowHarmonicMenu] = useState(false);
  const [isFreqDropdownOpen, setIsFreqDropdownOpen] = useState(false);
  const [isLayersDropdownOpen, setIsLayersDropdownOpen] = useState(false);
  const [customBinauralInput, setCustomBinauralInput] = useState<string>(() => {
    return (controller.temporal.binauralFreqs['UNIVERSAL'] || 8.0).toFixed(2);
  });

  useEffect(() => {
    const universalBinaural = controller.temporal.binauralFreqs['UNIVERSAL'];
    if (universalBinaural !== undefined) {
      setCustomBinauralInput(universalBinaural.toFixed(2));
    }
  }, [controller.temporal.binauralFreqs['UNIVERSAL']]);

  const applyCustomBinauralFreq = (freqVal?: number) => {
    const val = freqVal !== undefined ? freqVal : parseFloat(customBinauralInput);
    if (!isNaN(val) && val > 0) {
      controller.temporal.handleGlobalEntrainmentChange(val);
      setIsFreqDropdownOpen(false);
      setToast({ message: `Entrainment: ${val.toFixed(2)} Hz`, visible: true });
      setTimeout(() => setToast(t => ({...t, visible: false})), 1500);
    }
  };
  const [dockPosition, setDockPosition] = useState<'BOTTOM' | 'TOP'>('BOTTOM');
  
  // RESTORED: Audio Mixer State
  const [isAudioMixerOpen, setIsAudioMixerOpen] = useState(false);
  const [isPolyvagalModalOpen, setIsPolyvagalModalOpen] = useState(false);
  const [audioMixerTab, setAudioMixerTab] = useState<'volumes' | 'eq'>('volumes');
  const [activeColorWheelId, setActiveColorWheelIdState] = useState<HarmonicColorWheelId>(() => getActiveColorWheelId());

  useEffect(() => {
    return subscribeColorWheel((id) => {
      setActiveColorWheelIdState(id);
    });
  }, []);
  const [mixerExpanded, setMixerExpanded] = useState<Record<string, boolean>>({ breath: true });
  // Visualizer Fullscreen Immersion Mode (hides all UI overlays & top header so user can purely gaze at the visualizer)
  const [localVisualizerImmersion, setLocalVisualizerImmersion] = useState(false);
  const isVisualizerImmersion = props.isVisualizerImmersion !== undefined ? props.isVisualizerImmersion : localVisualizerImmersion;
  const toggleVisualizerImmersion = useCallback((forced?: boolean) => {
    if (props.onToggleVisualizerImmersion) {
      props.onToggleVisualizerImmersion(forced);
    } else {
      setLocalVisualizerImmersion(prev => typeof forced === 'boolean' ? forced : !prev);
    }
  }, [props.onToggleVisualizerImmersion]);

  // Immersion HUD visibility auto-hide on inactivity
  const [isImmersionHudVisible, setIsImmersionHudVisible] = useState(true);
  const immersionHudTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (!isVisualizerImmersion) {
      setIsImmersionHudVisible(true);
      return;
    }
    const wakeHud = () => {
      setIsImmersionHudVisible(true);
      if (immersionHudTimerRef.current) clearTimeout(immersionHudTimerRef.current);
      immersionHudTimerRef.current = setTimeout(() => {
        setIsImmersionHudVisible(false);
      }, 3500);
    };
    wakeHud();
    window.addEventListener('mousemove', wakeHud, { passive: true });
    window.addEventListener('touchstart', wakeHud, { passive: true });
    return () => {
      if (immersionHudTimerRef.current) clearTimeout(immersionHudTimerRef.current);
      window.removeEventListener('mousemove', wakeHud);
      window.removeEventListener('touchstart', wakeHud);
    };
  }, [isVisualizerImmersion]);

  const [layoutDebug, setLayoutDebug] = useState<{ show: boolean; activeProfile: LayoutProfile; profiles: Record<LayoutProfile, LayoutProfileData>; }>({ show: false, activeProfile: 'DESKTOP', profiles: LAYOUT_DEFAULTS });
  
  const [showBreathSheet, setShowBreathSheet] = useState(false); 
  const [breathSheetTab, setBreathSheetTab] = useState<'PRESETS' | 'CUSTOM'>('PRESETS');
  const [customInhale, setCustomInhale] = useState<number>(4.0);
  const [customHoldIn, setCustomHoldIn] = useState<number>(2.0);
  const [customExhale, setCustomExhale] = useState<number>(6.0);
  const [customHoldOut, setCustomHoldOut] = useState<number>(0.0);
  const [customPresetTitle, setCustomPresetTitle] = useState<string>('');
  const [deckPreviewId, setDeckPreviewId] = useState<string | null>(null); 
  const [showSaveModal, setShowSaveModal] = useState(false);
  const [newPresetName, setNewPresetName] = useState('');
  const [isSaveDefault, setIsSaveDefault] = useState(false);

  const { onBreathConfigChange } = props;
  const breathInhale = controller.temporal.breathConfig.inhale;
  const breathHoldIn = controller.temporal.breathConfig.holdIn;
  const breathExhale = controller.temporal.breathConfig.exhale;
  const breathHoldOut = controller.temporal.breathConfig.holdOut;

  useEffect(() => {
    if (onBreathConfigChange) {
      onBreathConfigChange(controller.temporal.breathConfig);
    }
  }, [breathInhale, breathHoldIn, breathExhale, breathHoldOut, onBreathConfigChange]);

  useEffect(() => {
    if (showBreathSheet) {
      setCustomInhale(breathInhale ?? 4.0);
      setCustomHoldIn(breathHoldIn ?? 2.0);
      setCustomExhale(breathExhale ?? 6.0);
      setCustomHoldOut(breathHoldOut ?? 0.0);
    }
  }, [showBreathSheet, breathInhale, breathHoldIn, breathExhale, breathHoldOut]);

  useEffect(() => {
      const handleResize = () => {
          const w = window.innerWidth; const h = window.innerHeight;
          const mobile = w < 768; const landscape = w > h;
          const targetProfile: LayoutProfile = mobile ? (landscape ? 'MOBILE_LANDSCAPE' : 'MOBILE_PORTRAIT') : 'DESKTOP';
          setLayoutDebug(prev => { 
              if (prev.show || prev.activeProfile === targetProfile) return prev; 
              return { ...prev, activeProfile: targetProfile }; 
          });
      };
      window.addEventListener('resize', handleResize);
      handleResize(); 
      return () => window.removeEventListener('resize', handleResize);
  }, []);

  const currentLayout = layoutDebug.profiles[layoutDebug.activeProfile];
  const handleLayoutChange = useCallback((target: keyof LayoutProfileData, axis: 'x' | 'y' | 'scale' | 'opacity' | null, value: number) => { 
      setLayoutDebug(prev => { 
          const profile = prev.activeProfile; 
          const currentData = prev.profiles[profile]; 
          const newProfiles = { ...prev.profiles };
          const data = { ...currentData };

          if (axis && (target === 'mandala' || target === 'pacer')) {
              if (axis === 'x' || axis === 'y') {
                  // Unified behavior: X/Y move together
                  data.mandala = { ...(data.mandala as LayoutElement), [axis]: value };
                  data.pacer = { ...(data.pacer as LayoutElement), [axis]: value };
              } else {
                  // Scale and Opacity remain unique to the element
                  data[target] = { ...(data[target] as LayoutElement), [axis]: value };
              }
          } else if (axis && typeof data[target] === 'object') { 
              data[target] = { ...(data[target] as LayoutElement), [axis]: value }; 
          } else if (typeof data[target] === 'object' && 'y' in (data[target] as LayoutElement)) { 
              data[target] = { ...(data[target] as LayoutElement), y: value }; 
          } else { 
              (data as any)[target] = value; 
          }

          newProfiles[profile] = data;
          return { ...prev, profiles: newProfiles };
      }); 
  }, []);

  const [breathPresetsList, setBreathPresetsList] = useState<BreathPreset[]>(() => {
    try {
      const saved = getCachedStorage('breath_presets');
      if (saved) {
        return [...DEFAULT_BREATH_PRESETS, ...JSON.parse(saved)];
      }
    } catch (e) {
      console.error(e);
    }
    return DEFAULT_BREATH_PRESETS;
  });

  const allBreathPresets = breathPresetsList;
  const previewPreset = allBreathPresets.find(p => p.id === deckPreviewId) || allBreathPresets[0];
  const groupedPresets = { 
    RELAX: allBreathPresets.filter(p => p.category === 'RELAX'), 
    BALANCE: allBreathPresets.filter(p => p.category === 'BALANCE'), 
    ENERGY: allBreathPresets.filter(p => p.category === 'ENERGY'), 
    PERFORMANCE: allBreathPresets.filter(p => p.category === 'PERFORMANCE'), 
  };

  const saveCustomBreathPreset = () => {
    if (!customPresetTitle.trim()) {
      setToast({ message: 'Enter a preset name', visible: true });
      setTimeout(() => setToast(t => ({...t, visible: false})), 1500);
      return;
    }
    const newPreset: BreathPreset = {
      id: `custom_${Date.now()}`,
      name: customPresetTitle.trim(),
      category: 'BALANCE',
      description: 'User-designed custom breath pattern.',
      benefits: ['✨ Custom Pattern', '🌬️ Paced Cycle'],
      config: {
        inhale: customInhale,
        holdIn: customHoldIn,
        exhale: customExhale,
        holdOut: customHoldOut
      }
    };
    const customOnly = breathPresetsList.filter(p => !DEFAULT_BREATH_PRESETS.some(dp => dp.id === p.id));
    const updated = [...customOnly, newPreset];
    setCachedStorage('breath_presets', JSON.stringify(updated));
    const fullList = [...DEFAULT_BREATH_PRESETS, ...updated];
    setBreathPresetsList(fullList);
    setDeckPreviewId(newPreset.id);
    setCustomPresetTitle('');
    setToast({ message: `Saved "${newPreset.name}"`, visible: true });
    setTimeout(() => setToast(t => ({...t, visible: false})), 1500);
  };

  // ----------------------------------------------------------------------
  // BREATH PACER CHORD PROGRESSION SYNCHRONIZER
  // Advances musical chords strictly on the start of Inhale and/or start of Exhale
  // Never advances during Hold-In or Hold-Out / Pause periods
  // ----------------------------------------------------------------------
  const prevBreathPhaseRef = useRef<string>('IDLE');

  useEffect(() => {
    if (!isProgressionActive) {
      prevBreathPhaseRef.current = 'IDLE';
      if (progressionAnimFrameRef.current) {
        cancelAnimationFrame(progressionAnimFrameRef.current);
        progressionAnimFrameRef.current = null;
      }
      return;
    }

    const checkBreathProgression = () => {
      if (isMasterPausedRef.current) {
        progressionAnimFrameRef.current = requestAnimationFrame(checkBreathProgression);
        return;
      }

      const isBreathActive = controller.temporal.isBreathActive;
      const breathStartTime = controller.temporal.breathStartTime;
      const breathConfig = controller.temporal.breathConfig;

      if (!isBreathActive || !breathStartTime) {
        prevBreathPhaseRef.current = 'IDLE';
        progressionAnimFrameRef.current = requestAnimationFrame(checkBreathProgression);
        return;
      }

      const inhale = breathConfig?.inhale !== undefined ? Number(breathConfig.inhale) : 4;
      const holdIn = breathConfig?.holdIn !== undefined ? Number(breathConfig.holdIn) : 0;
      const exhale = breathConfig?.exhale !== undefined ? Number(breathConfig.exhale) : 6;
      const holdOut = breathConfig?.holdOut !== undefined ? Number(breathConfig.holdOut) : 0;
      const cycleDuration = Math.max(0.5, inhale + holdIn + exhale + holdOut);

      const now = performance.now() / 1000;
      const elapsed = Math.max(0, now - breathStartTime);
      const cycleProgress = elapsed % cycleDuration;

      // Determine current breath phase identically to TideMeter and VisualizerCanvas
      let phase: 'INHALE' | 'HOLD_IN' | 'EXHALE' | 'HOLD_OUT' = 'INHALE';
      if (cycleProgress < inhale) {
        phase = 'INHALE';
      } else if (holdIn > 0 && cycleProgress < inhale + holdIn) {
        phase = 'HOLD_IN';
      } else if (cycleProgress < inhale + holdIn + exhale) {
        phase = 'EXHALE';
      } else {
        phase = 'HOLD_OUT';
      }

      if (prevBreathPhaseRef.current === 'IDLE') {
        // Initial sync on activation: record current phase without premature trigger
        prevBreathPhaseRef.current = phase;
      } else if (phase !== prevBreathPhaseRef.current) {
        prevBreathPhaseRef.current = phase;

        // ONLY trigger chord advances on the exact start of INHALE or EXHALE
        // NEVER advance on HOLD_IN or HOLD_OUT (holds/pauses)
        if (progressionAdvanceMode === 'BREATH_PHASE') {
          // Advances strictly when entering INHALE or entering EXHALE
          if (phase === 'INHALE' || phase === 'EXHALE') {
            handleAdvanceChord(1);
          }
        } else if (progressionAdvanceMode === 'BREATH_CYCLE') {
          // Advances strictly on the start of INHALE (each new breath cycle)
          if (phase === 'INHALE') {
            handleAdvanceChord(1);
          }
        } else if ((progressionAdvanceMode as string) === 'BREATH_EXHALE') {
          // Advances strictly on the start of EXHALE
          if (phase === 'EXHALE') {
            handleAdvanceChord(1);
          }
        }
      }

      progressionAnimFrameRef.current = requestAnimationFrame(checkBreathProgression);
    };

    if (progressionAnimFrameRef.current) {
      cancelAnimationFrame(progressionAnimFrameRef.current);
    }
    progressionAnimFrameRef.current = requestAnimationFrame(checkBreathProgression);

    return () => {
      if (progressionAnimFrameRef.current) {
        cancelAnimationFrame(progressionAnimFrameRef.current);
        progressionAnimFrameRef.current = null;
      }
    };
  }, [
    isProgressionActive, 
    progressionAdvanceMode, 
    controller.temporal.isBreathActive, 
    controller.temporal.breathStartTime, 
    controller.temporal.breathConfig, 
    handleAdvanceChord
  ]);

  // Stable ref for audio mutes setter to prevent cyclic effect dependencies
  const setAudioMutesRef = useRef(controller.audio.setMutes);
  useEffect(() => {
    setAudioMutesRef.current = controller.audio.setMutes;
  });

  // Track progression active state transitions to cleanly release scale tones only when turning off
  const wasProgressionActiveRef = useRef(isProgressionActive);
  // Track currently sounding voice pitches by voice channel index (0 to 7) for individual voice-leading portamento
  const currentVoicePitchesRef = useRef<(number | null)[]>([]);

  // Apply active chord frequencies to the audio engine using persistent voice channels with voice leading
  useEffect(() => {
    if (!isProgressionActive) {
      if (controller.loopDataRef && controller.loopDataRef.current) {
        controller.loopDataRef.current.isMusicMode = false;
        controller.loopDataRef.current.currentChordRootNote = undefined;
        controller.loopDataRef.current.currentChordRootFreq = undefined;
      }
      return;
    }
    
    if (!currentProgressionObj || currentProgressionObj.chords.length === 0) return;
    
    const activeChord = currentProgressionObj.chords[currentChordIndex % currentProgressionObj.chords.length];
    if (!activeChord) return;

    const chordInfo = getChordFrequencies(activeChord, musicPitchRef, musicTemperament, musicOctaveShift, {
      adaptiveJustIntonation: controller.audio.chordGlideConfig?.adaptiveJustIntonation,
      voicingStyle: controller.audio.chordGlideConfig?.voicingStyle,
      lowIntervalLimit: controller.audio.chordGlideConfig?.lowIntervalLimit,
      abComparisonMode: controller.audio.chordGlideConfig?.abComparisonMode
    });
    const currentNotes = chordInfo.notes;

    // Calculate optimal individual voice leading assignments preserving common tones and gliding moving voices
    const voiceLeadingMode = controller.audio.chordGlideConfig?.voiceLeading || 'CLOSEST_PITCH';
    const plan = computeVoiceLeading(
      currentVoicePitchesRef.current,
      currentNotes,
      voiceLeadingMode
    );

    // Assign target frequencies to persistent chord voice channels in customFrequencies
    const voiceFreqMap: Record<string, number> = {};
    const voiceSourceFreqMap: Record<string, number> = {};
    const activeVoiceIds = new Set<string>();
    const nextVoicePitches: (number | null)[] = [...currentVoicePitchesRef.current];

    plan.assignments.forEach((asgn) => {
      if (asgn.voiceIndex < CHORD_VOICE_CHANNELS.length) {
        const voiceId = CHORD_VOICE_CHANNELS[asgn.voiceIndex].id;
        if (asgn.isDroppedVoice) {
          nextVoicePitches[asgn.voiceIndex] = null;
        } else {
          voiceFreqMap[voiceId] = asgn.targetFreq;
          if (asgn.sourceFreq) {
            voiceSourceFreqMap[voiceId] = asgn.sourceFreq;
          }
          activeVoiceIds.add(voiceId);
          nextVoicePitches[asgn.voiceIndex] = asgn.targetFreq;
        }
      }
    });

    currentVoicePitchesRef.current = nextVoicePitches;

    if (controller.loopDataRef && controller.loopDataRef.current) {
      const rootNoteFreq = chordInfo.notes.find(n => n.isRoot)?.freq || chordInfo.notes[0]?.freq;
      controller.loopDataRef.current.isMusicMode = true;
      controller.loopDataRef.current.currentChordRootNote = activeChord.root;
      controller.loopDataRef.current.currentChordRootFreq = rootNoteFreq;
      controller.loopDataRef.current.customFrequencies = {
        ...(controller.loopDataRef.current.customFrequencies || {}),
        ...voiceFreqMap
      };
      controller.loopDataRef.current.chordVoiceSourceFreqs = {
        ...(controller.loopDataRef.current.chordVoiceSourceFreqs || {}),
        ...voiceSourceFreqMap
      };
    }

    // Update mutes: unmute active persistent voice channels and mute unused voices & background channels
    setAudioMutesRef.current((prev: Record<string, boolean>) => {
      let isIdentical = true;
      for (const id of activeVoiceIds) {
        if (prev[id] !== false) {
          isIdentical = false;
          break;
        }
      }
      if (isIdentical) {
        for (const ch of CHORD_VOICE_CHANNELS) {
          if (!activeVoiceIds.has(ch.id) && prev[ch.id] !== true) {
            isIdentical = false;
            break;
          }
        }
      }
      if (isIdentical) return prev;

      const next = { ...prev };
      // If entering progression from off state, mute other channels to avoid duplicate / overlapping sound
      if (!wasProgressionActiveRef.current) {
        ALL_CHANNELS.forEach(ch => {
          next[ch.id] = true;
        });
        musicScaleChannels.forEach(ch => {
          next[ch.id] = true;
        });
      }
      // Update chord voice channel mutes
      CHORD_VOICE_CHANNELS.forEach(ch => {
        next[ch.id] = !activeVoiceIds.has(ch.id);
      });
      return next;
    });
  }, [isProgressionActive, currentChordIndex, currentProgressionObj, musicPitchRef, musicTemperament, musicOctaveShift, musicScaleChannels, controller.audio.chordGlideConfig]);

  // Clean up and release chord voices & scale channels ONLY when chord progression is turned OFF
  useEffect(() => {
    if (wasProgressionActiveRef.current && !isProgressionActive) {
      currentVoicePitchesRef.current = [];
      setAudioMutesRef.current((prev: Record<string, boolean>) => {
        let changed = false;
        const next = { ...prev };
        CHORD_VOICE_CHANNELS.forEach(ch => {
          if (next[ch.id] === false) {
            next[ch.id] = true;
            changed = true;
          }
        });
        musicScaleChannels.forEach(ch => {
          if (next[ch.id] === false) {
            next[ch.id] = true;
            changed = true;
          }
        });
        return changed ? next : prev;
      });
    }
    wasProgressionActiveRef.current = isProgressionActive;
  }, [isProgressionActive, musicScaleChannels]);

  const handleSelectChordIndex = useCallback((index: number) => {
    setCurrentChordIndex(index);
    if (!isProgressionActive) {
      setIsProgressionActive(true);
    }
  }, [isProgressionActive]);

  const handlePlaySingleChord = useCallback((chord: ChordDef) => {
    if (currentProgressionObj && currentProgressionObj.chords.length > 0) {
      const foundIdx = currentProgressionObj.chords.findIndex(c => c.name === chord.name);
      if (foundIdx !== -1) {
        handleSelectChordIndex(foundIdx);
        return;
      }
    }

    const chordInfo = getChordFrequencies(chord, musicPitchRef, musicTemperament, musicOctaveShift, {
      adaptiveJustIntonation: controller.audio.chordGlideConfig?.adaptiveJustIntonation,
      voicingStyle: controller.audio.chordGlideConfig?.voicingStyle,
      lowIntervalLimit: controller.audio.chordGlideConfig?.lowIntervalLimit,
      abComparisonMode: controller.audio.chordGlideConfig?.abComparisonMode
    });
    const currentNotes = chordInfo.notes;

    const voiceLeadingMode = controller.audio.chordGlideConfig?.voiceLeading || 'CLOSEST_PITCH';
    const plan = computeVoiceLeading(
      currentVoicePitchesRef.current,
      currentNotes,
      voiceLeadingMode
    );

    const voiceFreqMap: Record<string, number> = {};
    const activeVoiceIds = new Set<string>();
    const nextVoicePitches: (number | null)[] = [...currentVoicePitchesRef.current];

    plan.assignments.forEach((asgn) => {
      if (asgn.voiceIndex < CHORD_VOICE_CHANNELS.length) {
        const voiceId = CHORD_VOICE_CHANNELS[asgn.voiceIndex].id;
        if (asgn.isDroppedVoice) {
          nextVoicePitches[asgn.voiceIndex] = null;
        } else {
          voiceFreqMap[voiceId] = asgn.targetFreq;
          activeVoiceIds.add(voiceId);
          nextVoicePitches[asgn.voiceIndex] = asgn.targetFreq;
        }
      }
    });

    currentVoicePitchesRef.current = nextVoicePitches;

    if (controller.loopDataRef && controller.loopDataRef.current) {
      controller.loopDataRef.current.customFrequencies = {
        ...(controller.loopDataRef.current.customFrequencies || {}),
        ...voiceFreqMap
      };
    }

    controller.audio.setMutes((prev: Record<string, boolean>) => {
      const next = { ...prev };
      ALL_CHANNELS.forEach(ch => {
        next[ch.id] = true;
      });
      musicScaleChannels.forEach(ch => {
        next[ch.id] = true;
      });
      CHORD_VOICE_CHANNELS.forEach(ch => {
        next[ch.id] = !activeVoiceIds.has(ch.id);
      });
      return next;
    });
  }, [currentProgressionObj, handleSelectChordIndex, musicPitchRef, musicTemperament, musicOctaveShift, musicScaleChannels, controller.audio]);

  // --- EXPERIENCE DESIGNER & RUNNER ENGINE ---
  const [isExperienceModalOpen, setIsExperienceModalOpen] = useState<boolean>(false);
  const [isExperienceActive, setIsExperienceActive] = useState<boolean>(false);
  const [isExperiencePaused, setIsExperiencePaused] = useState<boolean>(false);
  const [activeExperience, setActiveExperience] = useState<ExperienceDef | null>(() => STARTER_EXPERIENCES[0] || null);
  const [activeBlockIndex, setActiveBlockIndex] = useState<number>(0);
  const [currentExpCycle, setCurrentExpCycle] = useState<number>(1);
  const [blockProgress, setBlockProgress] = useState<number>(0);
  const [activeSubPhase, setActiveSubPhase] = useState<BreathPhase>('INHALE');
  const [subCycleInfo, setSubCycleInfo] = useState<{ cycle: number; totalCycles: number } | null>(null);

  const expAnimFrameRef = useRef<number | null>(null);
  const expStateRef = useRef<{
    exp: ExperienceDef | null;
    blockIndex: number;
    blockStartTime: number;
    cycle: number;
    isActive: boolean;
    isPaused: boolean;
    pausedElapsed: number;
  }>({
    exp: null,
    blockIndex: 0,
    blockStartTime: 0,
    cycle: 1,
    isActive: false,
    isPaused: false,
    pausedElapsed: 0
  });

  const auditionTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Snapshot ref for clean state restoration upon stopping an experience
  const experienceStateSnapshotRef = useRef<{
    binauralFreqs: Record<string, number>;
    immersionConfig: Record<string, unknown>;
    breathConfig: Record<string, unknown>;
    kickConfig: Record<string, unknown>;
    feedbackConfig: Record<string, unknown>;
    mutes: Record<string, boolean>;
    entrainmentMode: string;
  } | null>(null);

  // Universal smooth parameter ramp across block boundaries to prevent clicks or sudden jumps
  const rampExperienceParameter = useCallback((
    from: number,
    to: number,
    durationSec: number,
    onStep: (val: number) => void
  ) => {
    if (Math.abs(from - to) < 0.001 || durationSec <= 0.04) {
      onStep(to);
      return;
    }
    const startTime = performance.now();
    const step = () => {
      const elapsed = (performance.now() - startTime) / 1000;
      const progress = Math.min(1.0, elapsed / durationSec);
      const eased = 0.5 - 0.5 * Math.cos(progress * Math.PI);
      const currentVal = from + (to - from) * eased;
      onStep(currentVal);
      if (progress < 1.0) {
        requestAnimationFrame(step);
      }
    };
    requestAnimationFrame(step);
  }, []);

  // Apply acoustic frequencies and voice leads for an experience block
  const applyExperienceBlock = useCallback((block: ExperienceBlock, pitchRef: number, temperament: TuningTemperament, glideSec?: number) => {
    if (!block) return;
    const resolved = resolveBlockFrequencies(block, pitchRef, temperament);
    const voiceFreqMap: Record<string, number> = {};
    const activeVoiceIds = new Set<string>();

    resolved.frequencies.forEach((freq, i) => {
      if (i < CHORD_VOICE_CHANNELS.length) {
        const voiceId = CHORD_VOICE_CHANNELS[i].id;
        voiceFreqMap[voiceId] = freq;
        activeVoiceIds.add(voiceId);
      }
    });

    if (controller.loopDataRef && controller.loopDataRef.current) {
      controller.loopDataRef.current.isMusicMode = true;
      controller.loopDataRef.current.customFrequencies = {
        ...(controller.loopDataRef.current.customFrequencies || {}),
        ...voiceFreqMap
      };
      controller.loopDataRef.current.chordGlideConfig = {
        ...(controller.loopDataRef.current.chordGlideConfig || {
          enabled: true,
          time: 0.4,
          curve: 'EXPONENTIAL',
          voiceLeading: 'CLOSEST_PITCH'
        }),
        enabled: true,
        time: glideSec ?? block.glideSeconds ?? 0.4
      };

      // Unmute active voices immediately in loopDataRef for instant audio responsiveness
      if (controller.loopDataRef.current.mutes) {
        CHORD_VOICE_CHANNELS.forEach(ch => {
          controller.loopDataRef.current.mutes[ch.id] = !activeVoiceIds.has(ch.id);
        });
      }

      // Ensure active chord channels have solid volume
      if (controller.loopDataRef.current.volumes) {
        CHORD_VOICE_CHANNELS.forEach(ch => {
          if (!controller.loopDataRef.current.volumes[ch.id] || controller.loopDataRef.current.volumes[ch.id] < 0.2) {
            controller.loopDataRef.current.volumes[ch.id] = 0.8;
          }
        });
      }
    }

    controller.audio.setMutes((prev: Record<string, boolean>) => {
      const next = { ...prev };
      CHORD_VOICE_CHANNELS.forEach(ch => {
        next[ch.id] = !activeVoiceIds.has(ch.id);
      });
      return next;
    });

    const effectiveGlide = typeof glideSec === 'number' ? glideSec : (block.glideSeconds ?? 0.4);

    // Multi-sensory block overrides (customized per-phase in Experience Designer)
    // 1. Entrainment frequency & layers (with universal boundary ramping)
    if (block.entrainment?.enabled) {
      if (typeof block.entrainment.frequencyHz === 'number' && block.entrainment.frequencyHz > 0) {
        const targetFreq = block.entrainment.frequencyHz;
        const currentFreq = controller.temporal.binauralFreqs['UNIVERSAL'] || 8.0;
        if (effectiveGlide > 0.06 && Math.abs(currentFreq - targetFreq) > 0.08) {
          rampExperienceParameter(currentFreq, targetFreq, effectiveGlide, (f) => {
            controller.temporal.handleGlobalEntrainmentChange(f);
          });
        } else {
          controller.temporal.handleGlobalEntrainmentChange(targetFreq);
        }
      }
      if (block.entrainment.layers && block.entrainment.layers.length > 0) {
        const layers = block.entrainment.layers;
        const nextMode = layers.length > 1 ? 'HYBRID' : (layers[0] === 'isochronic' ? 'ISOCHRONIC' : layers[0] === 'monaural' ? 'MONAURAL' : 'BINAURAL');
        controller.atmosphere.setImmersionConfig((prev: Record<string, unknown>) => ({
          ...prev,
          activeLayers: layers,
          pulseMode: nextMode
        }));
      }
    }

    // 2. Sentics emotion wave & modulation
    if (block.sentics?.enabled && block.sentics.emotion) {
      controller.temporal.setBreathConfig((prev: Record<string, unknown>) => ({
        ...prev,
        isSenticPacing: true,
        senticState: block.sentics!.emotion!,
        senticVibratoDepth: block.sentics!.intensity ?? 0.35,
        isTideAM: block.sentics!.tideAM ?? true,
        isTideFM: block.sentics!.tideFM ?? true,
      }));
    }

    // 2b. Breath Layer custom parameters (with universal boundary ramping for noise volume)
    if (block.breath?.enabled) {
      const targetNoiseVol = block.breath.noiseVolume;
      const currentNoiseVol = controller.temporal.breathConfig?.noiseVolume ?? 0.7;
      if (typeof targetNoiseVol === 'number' && effectiveGlide > 0.06 && Math.abs(currentNoiseVol - targetNoiseVol) > 0.05) {
        rampExperienceParameter(currentNoiseVol, targetNoiseVol, effectiveGlide, (v) => {
          controller.temporal.setBreathConfig((prev: Record<string, unknown>) => ({
            ...prev,
            breathVolume: v,
            noiseVolume: v
          }));
        });
      }

      const blockPattern = block.breathPattern;
      controller.temporal.setBreathConfig((prev: Record<string, unknown>) => ({
        ...prev,
        ...(blockPattern ? {
          inhale: blockPattern.inhale ?? 4,
          holdIn: blockPattern.holdIn ?? 0,
          exhale: blockPattern.exhale ?? 4,
          holdOut: blockPattern.holdOut ?? 0,
        } : {}),
        ...(block.breath?.noiseType ? { noiseType: block.breath.noiseType } : {}),
        ...(typeof block.breath?.noiseVolume === 'number' && effectiveGlide <= 0.06 ? { breathVolume: block.breath.noiseVolume, noiseVolume: block.breath.noiseVolume } : {}),
        ...(block.breath?.cueTone !== undefined ? { cueTone: block.breath.cueTone } : {}),
        ...(typeof block.breath?.cueVolume === 'number' ? { cueVolume: block.breath.cueVolume } : {}),
        ...(typeof block.breath?.cueOctave === 'number' ? { cueOctave: block.breath.cueOctave } : {}),
        ...(block.breath?.visualMode ? { pacerStyle: block.breath.visualMode, visualMode: block.breath.visualMode } : {}),
        ...(block.breath?.colorScheme ? { colorScheme: block.breath.colorScheme } : {}),
        ...(block.breath?.entrainmentMode ? { entrainmentMode: block.breath.entrainmentMode } : {}),
      }));
    }

    // 3. Heart & Pulse sync (with universal boundary ramping for BPM)
    if (block.heart?.enabled) {
      const targetBpm = block.heart.bpm;
      const currentBpm = controller.temporal.kickConfig?.bpm ?? 60;
      if (typeof targetBpm === 'number' && effectiveGlide > 0.06 && Math.abs(currentBpm - targetBpm) > 2) {
        rampExperienceParameter(currentBpm, targetBpm, effectiveGlide, (b) => {
          controller.temporal.setKickConfig((prev: Record<string, unknown>) => ({
            ...prev,
            bpm: Math.round(b)
          }));
        });
      }

      controller.temporal.setKickConfig((prev: Record<string, unknown>) => ({
        ...prev,
        syncMode: block.heart!.syncMode || prev.syncMode,
        ...(typeof targetBpm === 'number' && effectiveGlide <= 0.06 ? { bpm: targetBpm } : {}),
        volume: block.heart!.volume ?? prev.volume,
        ...(block.heart?.doubleBeat !== undefined ? { doubleBeat: block.heart.doubleBeat } : {}),
        ...(typeof block.heart?.baseFreq === 'number' ? { baseFreq: block.heart.baseFreq } : {}),
        ...(typeof block.heart?.lpfCutoff === 'number' ? { lpfCutoff: block.heart.lpfCutoff } : {}),
        ...(block.heart?.kickEnabled !== undefined ? { enabled: block.heart.kickEnabled } : {}),
      }));
    }

    // 4. Matrix & Crystal
    if (block.matrix?.enabled) {
      controller.atmosphere.setImmersionConfig((prev: Record<string, unknown>) => ({
        ...prev,
        ...(block.matrix?.composerWarp ? { composerWarp: block.matrix.composerWarp } : {}),
        ...(typeof block.matrix?.intensity === 'number' ? { composerWarpIntensity: block.matrix.intensity } : {}),
      }));
    }
    if (block.crystal?.enabled) {
      controller.atmosphere.setImmersionConfig((prev: Record<string, unknown>) => ({
        ...prev,
        isTimeCrystal: block.crystal!.isTimeCrystal ?? true,
        timeCrystalTopology: block.crystal!.topology || prev.timeCrystalTopology,
      }));
    }

    // 5. Visual Pulse
    if (block.pulse?.enabled) {
      controller.audio.setFeedbackConfig((prev: Record<string, unknown>) => ({
        ...prev,
        ...(block.pulse?.pulseStyle ? { pulseStyle: block.pulse.pulseStyle } : {}),
        ...(block.pulse?.pulseWaveform ? { pulseWaveform: block.pulse.pulseWaveform } : {}),
        ...(typeof block.pulse?.depth === 'number' ? { depth: block.pulse.depth } : {}),
        ...(block.pulse?.pulseCustomColor ? { pulseCustomColor: block.pulse.pulseCustomColor } : {}),
        ...(block.pulse?.pulseSync ? { pulseSync: block.pulse.pulseSync } : {}),
        ...(typeof block.pulse?.syncWithTimeCrystal === 'boolean' ? { syncWithTimeCrystal: block.pulse.syncWithTimeCrystal } : {}),
        ...(block.pulse?.timeCrystalTopology ? { timeCrystalTopology: block.pulse.timeCrystalTopology } : {}),
        ...(typeof block.pulse?.isUncoupled === 'boolean' ? { isUncoupled: block.pulse.isUncoupled } : {}),
        ...(typeof block.pulse?.customRateHz === 'number' ? { customRateHz: block.pulse.customRateHz } : {}),
      }));
    }
  }, [controller.loopDataRef, controller.audio, controller.temporal, controller.atmosphere, rampExperienceParameter]);

  // Stop running experience
  const handleStopExperience = useCallback(() => {
    if (expAnimFrameRef.current) {
      cancelAnimationFrame(expAnimFrameRef.current);
      expAnimFrameRef.current = null;
    }
    expStateRef.current.isActive = false;
    expStateRef.current.isPaused = false;
    expStateRef.current.pausedElapsed = 0;
    setIsExperienceActive(false);
    setIsExperiencePaused(false);
    isMasterPausedRef.current = false;
    setIsMasterPaused(false);
    setBlockProgress(0);
    setActiveSubPhase('INHALE');
    setSubCycleInfo(null);

    if (controller.loopDataRef && controller.loopDataRef.current) {
      controller.loopDataRef.current.isMusicMode = false;
      if (controller.loopDataRef.current.mutes) {
        CHORD_VOICE_CHANNELS.forEach(ch => {
          controller.loopDataRef.current.mutes[ch.id] = true;
        });
      }
    }

    // Immediately silence WebAudio lattice nodes so tones do not ring out
    if (controller.audioSys.graphRef.current) {
      const g = controller.audioSys.graphRef.current;
      const ctx = g.ctx;
      const t = ctx.currentTime;
      CHORD_VOICE_CHANNELS.forEach(ch => {
        const gainNode = g.latticeGains[ch.id];
        if (gainNode) {
          try {
            gainNode.gain.cancelScheduledValues(t);
            gainNode.gain.setValueAtTime(gainNode.gain.value, t);
            gainNode.gain.linearRampToValueAtTime(0.0001, t + 0.025);
          } catch { /* ignore */ }
        }
      });
    }

    controller.audio.setMutes((prev: Record<string, boolean>) => {
      const next = { ...prev };
      CHORD_VOICE_CHANNELS.forEach(ch => {
        next[ch.id] = true;
      });
      return next;
    });

    // Clean state restoration: revert parameters to snapshot captured prior to playback
    if (experienceStateSnapshotRef.current) {
      const snap = experienceStateSnapshotRef.current;
      if (snap.binauralFreqs) controller.temporal.setBinauralFreqs(snap.binauralFreqs);
      if (snap.immersionConfig) controller.atmosphere.setImmersionConfig(snap.immersionConfig);
      if (snap.breathConfig) controller.temporal.setBreathConfig(snap.breathConfig);
      if (snap.kickConfig) controller.temporal.setKickConfig(snap.kickConfig);
      if (snap.feedbackConfig) controller.audio.setFeedbackConfig(snap.feedbackConfig);
      if (snap.mutes) controller.audio.setMutes(snap.mutes);
      if (snap.entrainmentMode) controller.temporal.setEntrainmentMode(snap.entrainmentMode as any);
      experienceStateSnapshotRef.current = null;
    }
  }, [controller.loopDataRef, controller.audio, controller.audioSys, controller.temporal, controller.atmosphere]);

  // Start, pause/resume, or toggle experience
  const handleTogglePlayExperience = useCallback((experience?: ExperienceDef, options?: { autoImmerse?: boolean }) => {
    const targetExp = experience || activeExperience || STARTER_EXPERIENCES[0];

    // Auto-immersion trigger
    if (options?.autoImmerse) {
      setIsExperienceModalOpen(false);
      toggleVisualizerImmersion(true);
    }

    // If currently playing the exact same experience: toggle pause / resume
    if (isExperienceActive && activeExperience?.id === targetExp.id) {
      if (!isExperiencePaused) {
        // Pause: stop animation frame loop
        if (expAnimFrameRef.current) {
          cancelAnimationFrame(expAnimFrameRef.current);
          expAnimFrameRef.current = null;
        }
        const now = performance.now() / 1000;
        const currentElapsed = now - expStateRef.current.blockStartTime;
        expStateRef.current.isPaused = true;
        expStateRef.current.pausedElapsed = currentElapsed;
        setIsExperiencePaused(true);
        isMasterPausedRef.current = true;
        setIsMasterPaused(true);

        // Immediately silence all tone and chord voices so audio does not ring out while paused
        if (controller.loopDataRef && controller.loopDataRef.current) {
          controller.loopDataRef.current.isMasterPaused = true;
          controller.loopDataRef.current.isMusicMode = false;
          if (controller.loopDataRef.current.mutes) {
            CHORD_VOICE_CHANNELS.forEach(ch => {
              controller.loopDataRef.current.mutes[ch.id] = true;
            });
          }
        }

        // Direct WebAudio immediate silence for paused state
        if (controller.audioSys.graphRef.current) {
          const g = controller.audioSys.graphRef.current;
          const ctx = g.ctx;
          const t = ctx.currentTime;
          CHORD_VOICE_CHANNELS.forEach(ch => {
            const gainNode = g.latticeGains[ch.id];
            if (gainNode) {
              try {
                gainNode.gain.cancelScheduledValues(t);
                gainNode.gain.setValueAtTime(gainNode.gain.value, t);
                gainNode.gain.linearRampToValueAtTime(0.0001, t + 0.025);
              } catch { /* ignore */ }
            }
          });
        }

        controller.audio.setMutes((prev: Record<string, boolean>) => {
          const next = { ...prev };
          CHORD_VOICE_CHANNELS.forEach(ch => {
            next[ch.id] = true;
          });
          return next;
        });

        return;
      } else {
        // Resume
        const now = performance.now() / 1000;
        expStateRef.current.isPaused = false;
        expStateRef.current.blockStartTime = now - (expStateRef.current.pausedElapsed || 0);
        setIsExperiencePaused(false);
        isMasterPausedRef.current = false;
        setIsMasterPaused(false);
        if (controller.loopDataRef && controller.loopDataRef.current) {
          controller.loopDataRef.current.isMasterPaused = false;
        }

        // Ensure audio is running
        if (controller.audioSys.graphRef.current?.ctx?.state === 'suspended') {
          controller.audioSys.graphRef.current.ctx.resume().catch(console.warn);
        }
        if (!controller.audioSys.audioEnabled) {
          controller.toggleAudio();
        }

        // Re-apply the current block acoustic and harmonic voices on resume
        const currentBlock = expStateRef.current.exp?.blocks[expStateRef.current.blockIndex];
        if (currentBlock) {
          applyExperienceBlock(
            currentBlock,
            expStateRef.current.exp?.pitchRef || musicPitchRef,
            expStateRef.current.exp?.temperament || musicTemperament,
            0.1
          );
        }

        // Restart animation frame loop
        if (expAnimFrameRef.current) cancelAnimationFrame(expAnimFrameRef.current);

        const resumeTick = () => {
          const state = expStateRef.current;
          if (!state.isActive || state.isPaused || !state.exp || state.exp.blocks.length === 0) return;

          const currentTime = performance.now() / 1000;
          const currentBlock = state.exp.blocks[state.blockIndex];
          if (!currentBlock) return;

          const duration = Math.max(0.2, currentBlock.durationSeconds || 4.0);
          const elapsed = currentTime - state.blockStartTime;
          const progress = Math.min(1.0, elapsed / duration);

          setBlockProgress(progress);

          // Kinetic breath calculations with Sub-Breath Cycle Pattern support
          let radius = 0;
          let currentSubPhase: BreathPhase = currentBlock.breathPhase;

          const bp = currentBlock.breathPattern;
          if (bp && (bp.inhale > 0 || bp.exhale > 0)) {
            const oneLoop = (bp.inhale || 4) + (bp.holdIn || 0) + (bp.exhale || 4) + (bp.holdOut || 0);
            if (oneLoop > 0) {
              const currentCycle = Math.floor(elapsed / oneLoop) + 1;
              const loopTime = elapsed % oneLoop;
              const tIn = bp.inhale || 4;
              const tHoldIn = tIn + (bp.holdIn || 0);
              const tEx = tHoldIn + (bp.exhale || 4);

              if (loopTime < tIn) {
                currentSubPhase = 'INHALE';
                radius = Math.min(1.0, loopTime / Math.max(0.1, tIn));
              } else if (loopTime < tHoldIn) {
                currentSubPhase = 'HOLD_IN';
                radius = 1.0;
              } else if (loopTime < tEx) {
                currentSubPhase = 'EXHALE';
                const exProg = Math.min(1.0, (loopTime - tHoldIn) / Math.max(0.1, (bp.exhale || 4)));
                radius = 1.0 - exProg;
              } else {
                currentSubPhase = 'HOLD_OUT';
                radius = 0.0;
              }

              setActiveSubPhase(currentSubPhase);
              setSubCycleInfo({ cycle: Math.min(bp.cycles || 1, currentCycle), totalCycles: bp.cycles || 1 });
            }
          } else {
            if (currentBlock.breathPhase === 'INHALE') {
              radius = progress;
            } else if (currentBlock.breathPhase === 'HOLD_IN') {
              radius = 1.0;
            } else if (currentBlock.breathPhase === 'EXHALE') {
              radius = 1.0 - progress;
            } else if (currentBlock.breathPhase === 'HOLD_OUT') {
              radius = 0.0;
            } else {
              radius = 0.5 + 0.5 * Math.sin(progress * Math.PI * 2);
            }
            setActiveSubPhase(currentBlock.breathPhase);
            setSubCycleInfo(null);
          }

          if (controller.loopDataRef && controller.loopDataRef.current) {
            controller.loopDataRef.current.isBreathActive = true;
            controller.loopDataRef.current.breathPhase = currentSubPhase;
            controller.loopDataRef.current.breathRadius = radius;
          }

          // Advance block if duration reached
          if (elapsed >= duration) {
            let nextBlockIdx = state.blockIndex + 1;
            let nextCycle = state.cycle;

            if (nextBlockIdx >= state.exp.blocks.length) {
              if (state.exp.loopMode === 'CYCLE_COUNT' && nextCycle >= state.exp.targetCycles) {
                handleStopExperience();
                return;
              }
              nextBlockIdx = 0;
              nextCycle += 1;
            }

            state.blockIndex = nextBlockIdx;
            state.cycle = nextCycle;
            state.blockStartTime = currentTime - (elapsed - duration);

            setActiveBlockIndex(nextBlockIdx);
            setCurrentExpCycle(nextCycle);

            const nextBlock = state.exp.blocks[nextBlockIdx];
            if (nextBlock) {
              applyExperienceBlock(
                nextBlock,
                state.exp.pitchRef || musicPitchRef,
                state.exp.temperament || musicTemperament,
                nextBlock.glideSeconds
              );
            }
          }

          expAnimFrameRef.current = requestAnimationFrame(resumeTick);
        };

        expAnimFrameRef.current = requestAnimationFrame(resumeTick);
        return;
      }
    }

    // Starting new or different experience
    if (expAnimFrameRef.current) {
      cancelAnimationFrame(expAnimFrameRef.current);
      expAnimFrameRef.current = null;
    }

    // Stop music progression if running
    if (isProgressionActive) {
      setIsProgressionActive(false);
    }

    // Ensure audio system is turned on and AudioContext is un-suspended
    if (controller.audioSys.graphRef.current?.ctx?.state === 'suspended') {
      controller.audioSys.graphRef.current.ctx.resume().catch(console.warn);
    }
    if (!controller.audioSys.audioEnabled) {
      controller.toggleAudio();
    }

    // Capture pre-experience parameter snapshot if not already snapshotted
    if (!experienceStateSnapshotRef.current) {
      experienceStateSnapshotRef.current = {
        binauralFreqs: { ...(controller.temporal.binauralFreqs || {}) },
        immersionConfig: { ...(controller.atmosphere.immersionConfig || {}) },
        breathConfig: { ...(controller.temporal.breathConfig || {}) },
        kickConfig: { ...(controller.temporal.kickConfig || {}) },
        feedbackConfig: { ...(controller.audio.feedbackConfig || {}) },
        mutes: { ...(controller.audio.mutes || {}) },
        entrainmentMode: controller.temporal.entrainmentMode
      };
    }

    // Ensure entrainment mode is active so all channels and breath sync participate
    if (controller.temporal.entrainmentMode === 'SILENT') {
      controller.temporal.setEntrainmentMode('SYNCED');
    }
    controller.temporal.setIsBreathActive(true);

    if (controller.loopDataRef && controller.loopDataRef.current) {
      controller.loopDataRef.current.audioEnabled = true;
      controller.loopDataRef.current.isBreathActive = true;
      controller.loopDataRef.current.isMusicMode = true;
      if (!controller.loopDataRef.current.entrainmentMode || controller.loopDataRef.current.entrainmentMode === 'SILENT') {
        controller.loopDataRef.current.entrainmentMode = 'SYNCED';
      }
    }

    const now = performance.now() / 1000;
    expStateRef.current = {
      exp: targetExp,
      blockIndex: 0,
      blockStartTime: now,
      cycle: 1,
      isActive: true,
      isPaused: false,
      pausedElapsed: 0
    };

    setActiveExperience(targetExp);
    setActiveBlockIndex(0);
    setCurrentExpCycle(1);
    setBlockProgress(0);
    setIsExperienceActive(true);
    setIsExperiencePaused(false);
    isMasterPausedRef.current = false;
    setIsMasterPaused(false);
    if (controller.loopDataRef && controller.loopDataRef.current) {
      controller.loopDataRef.current.isMasterPaused = false;
    }

    // Apply first block sound immediately
    if (targetExp.blocks && targetExp.blocks.length > 0) {
      applyExperienceBlock(
        targetExp.blocks[0],
        targetExp.pitchRef || musicPitchRef,
        targetExp.temperament || musicTemperament,
        targetExp.blocks[0].glideSeconds
      );
    }

    // Main animation & breath sync ticker
    const tick = () => {
      const state = expStateRef.current;
      if (!state.isActive || state.isPaused || !state.exp || state.exp.blocks.length === 0) return;

      const currentTime = performance.now() / 1000;
      const currentBlock = state.exp.blocks[state.blockIndex];
      if (!currentBlock) return;

      const duration = Math.max(0.2, currentBlock.durationSeconds || 4.0);
      const elapsed = currentTime - state.blockStartTime;
      const progress = Math.min(1.0, elapsed / duration);

      setBlockProgress(progress);

      // Breath radius kinetic calculation with Sub-Breath Cycle Pattern support
      let radius = 0;
      let currentSubPhase: BreathPhase = currentBlock.breathPhase;

      const bp = currentBlock.breathPattern;
      if (bp && (bp.inhale > 0 || bp.exhale > 0)) {
        const oneLoop = (bp.inhale || 4) + (bp.holdIn || 0) + (bp.exhale || 4) + (bp.holdOut || 0);
        if (oneLoop > 0) {
          const currentCycle = Math.floor(elapsed / oneLoop) + 1;
          const loopTime = elapsed % oneLoop;
          const tIn = bp.inhale || 4;
          const tHoldIn = tIn + (bp.holdIn || 0);
          const tEx = tHoldIn + (bp.exhale || 4);

          if (loopTime < tIn) {
            currentSubPhase = 'INHALE';
            radius = Math.min(1.0, loopTime / Math.max(0.1, tIn));
          } else if (loopTime < tHoldIn) {
            currentSubPhase = 'HOLD_IN';
            radius = 1.0;
          } else if (loopTime < tEx) {
            currentSubPhase = 'EXHALE';
            const exProg = Math.min(1.0, (loopTime - tHoldIn) / Math.max(0.1, (bp.exhale || 4)));
            radius = 1.0 - exProg;
          } else {
            currentSubPhase = 'HOLD_OUT';
            radius = 0.0;
          }

          setActiveSubPhase(currentSubPhase);
          setSubCycleInfo({ cycle: Math.min(bp.cycles || 1, currentCycle), totalCycles: bp.cycles || 1 });
        }
      } else {
        if (currentBlock.breathPhase === 'INHALE') {
          radius = progress;
        } else if (currentBlock.breathPhase === 'HOLD_IN') {
          radius = 1.0;
        } else if (currentBlock.breathPhase === 'EXHALE') {
          radius = 1.0 - progress;
        } else if (currentBlock.breathPhase === 'HOLD_OUT') {
          radius = 0.0;
        } else {
          radius = 0.5 + 0.5 * Math.sin(progress * Math.PI * 2);
        }
        setActiveSubPhase(currentBlock.breathPhase);
        setSubCycleInfo(null);
      }

      if (controller.loopDataRef && controller.loopDataRef.current) {
        controller.loopDataRef.current.isBreathActive = true;
        controller.loopDataRef.current.breathPhase = currentSubPhase;
        controller.loopDataRef.current.breathRadius = radius;
      }

      // Check if current block duration reached
      if (elapsed >= duration) {
        let nextBlockIdx = state.blockIndex + 1;
        let nextCycle = state.cycle;

        if (nextBlockIdx >= state.exp.blocks.length) {
          // Completed full cycle
          if (state.exp.loopMode === 'CYCLE_COUNT' && nextCycle >= state.exp.targetCycles) {
            handleStopExperience();
            return;
          }
          nextBlockIdx = 0;
          nextCycle += 1;
        }

        state.blockIndex = nextBlockIdx;
        state.cycle = nextCycle;
        state.blockStartTime = currentTime - (elapsed - duration);

        setActiveBlockIndex(nextBlockIdx);
        setCurrentExpCycle(nextCycle);

        // Apply new block acoustics
        const nextBlock = state.exp.blocks[nextBlockIdx];
        if (nextBlock) {
          applyExperienceBlock(
            nextBlock,
            state.exp.pitchRef || musicPitchRef,
            state.exp.temperament || musicTemperament,
            nextBlock.glideSeconds
          );
        }
      }

      expAnimFrameRef.current = requestAnimationFrame(tick);
    };

    expAnimFrameRef.current = requestAnimationFrame(tick);
  }, [isExperienceActive, isExperiencePaused, activeExperience, isProgressionActive, controller, musicPitchRef, musicTemperament, applyExperienceBlock, handleStopExperience, toggleVisualizerImmersion]);

  // Jump to specific block
  const handleJumpToExperienceBlock = useCallback((targetIdx: number) => {
    if (!isExperienceActive || !activeExperience || targetIdx < 0 || targetIdx >= activeExperience.blocks.length) return;
    const now = performance.now() / 1000;
    expStateRef.current.blockIndex = targetIdx;
    expStateRef.current.blockStartTime = now;
    setActiveBlockIndex(targetIdx);
    setBlockProgress(0);

    const targetBlock = activeExperience.blocks[targetIdx];
    applyExperienceBlock(
      targetBlock,
      activeExperience.pitchRef || musicPitchRef,
      activeExperience.temperament || musicTemperament,
      targetBlock.glideSeconds
    );
  }, [isExperienceActive, activeExperience, musicPitchRef, musicTemperament, applyExperienceBlock]);

  // Audition block
  const handleAuditionBlock = useCallback((block: ExperienceBlock | null) => {
    if (!block) {
      if (auditionTimerRef.current) clearTimeout(auditionTimerRef.current);
      if (!isExperienceActive) {
        controller.audio.setMutes((prev: Record<string, boolean>) => {
          let hasUnmuted = false;
          for (const ch of CHORD_VOICE_CHANNELS) {
            if (!prev[ch.id]) {
              hasUnmuted = true;
              break;
            }
          }
          if (!hasUnmuted) return prev; // Avoid redundant re-render if already muted
          const next = { ...prev };
          CHORD_VOICE_CHANNELS.forEach(ch => {
            next[ch.id] = true;
          });
          return next;
        });
      }
      return;
    }

    if (!controller.audioSys.audioEnabled) {
      controller.toggleAudio();
    }
    applyExperienceBlock(block, musicPitchRef, musicTemperament, 0.2);

    if (auditionTimerRef.current) clearTimeout(auditionTimerRef.current);
  }, [controller, musicPitchRef, musicTemperament, applyExperienceBlock, isExperienceActive]);

  // Master Active state evaluates whether any audio or temporal engine component is active
  const isMasterActive = Boolean(
    isExperienceActive ||
    controller.audioSys.audioEnabled ||
    controller.temporal.isBreathActive ||
    isProgressionActive ||
    totalActiveTones > 0
  );

  // Universal Master Play / Pause handler
  const handleToggleMasterPlay = useCallback(() => {
    if (isMasterActive && !isMasterPaused) {
      // 1. Master Pause: ramp down master gain & suspend AudioContext
      controller.audioSys.pauseAudio();

      // 2. Pause Experience if active
      if (isExperienceActive && !isExperiencePaused) {
        handleTogglePlayExperience();
      }

      // 3. Record pause timestamp for breath pacer resumption
      masterPauseTimeRef.current = performance.now() / 1000;

      // 4. Update states & loopDataRef
      isMasterPausedRef.current = true;
      setIsMasterPaused(true);
      if (controller.loopDataRef?.current) {
        controller.loopDataRef.current.isMasterPaused = true;
      }
    } else if (isMasterPaused) {
      // Master Resume: calculate pause duration to prevent breath cycle jumping
      const now = performance.now() / 1000;
      const pauseDuration = masterPauseTimeRef.current > 0 ? (now - masterPauseTimeRef.current) : 0;
      masterPauseTimeRef.current = 0;

      // 1. Resume AudioContext & ramp up master gain
      controller.audioSys.resumeAudio();

      // 2. Offset breath pacer start time so pacing picks up right where it paused
      if (controller.temporal.breathStartTime && pauseDuration > 0) {
        controller.temporal.setBreathStartTime((prev: number) => (prev ? prev + pauseDuration : now));
      }

      // 3. Resume Experience if active & paused
      if (isExperienceActive && isExperiencePaused) {
        handleTogglePlayExperience();
      }

      // 4. Update states & loopDataRef
      isMasterPausedRef.current = false;
      setIsMasterPaused(false);
      if (controller.loopDataRef?.current) {
        controller.loopDataRef.current.isMasterPaused = false;
      }
    } else {
      // Start from Idle: launch selected experience or initialize core audio & pacer
      if (activeExperience || STARTER_EXPERIENCES[0]) {
        handleTogglePlayExperience(activeExperience || STARTER_EXPERIENCES[0]);
      } else {
        if (!controller.audioSys.audioEnabled) {
          controller.audioSys.initAudio(
            controller.atmosphere.reverbConfig,
            controller.temporal.breathConfig,
            controller.temporal.binauralFreqs,
            controller.atmosphere.delayConfig
          );
          controller.audioSys.setAudioEnabled(true);
        }
        if (!controller.temporal.isBreathActive) {
          controller.temporal.setIsBreathActive(true);
          controller.temporal.setBreathStartTime(performance.now() / 1000);
        }
      }
      isMasterPausedRef.current = false;
      setIsMasterPaused(false);
      if (controller.loopDataRef?.current) {
        controller.loopDataRef.current.isMasterPaused = false;
      }
    }
  }, [
    isMasterActive,
    isMasterPaused,
    isExperienceActive,
    isExperiencePaused,
    activeExperience,
    controller,
    handleTogglePlayExperience
  ]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (expAnimFrameRef.current) cancelAnimationFrame(expAnimFrameRef.current);
      if (auditionTimerRef.current) clearTimeout(auditionTimerRef.current);
    };
  }, []);

  const deleteCustomBreathPreset = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const customOnly = breathPresetsList.filter(p => !DEFAULT_BREATH_PRESETS.some(dp => dp.id === p.id) && p.id !== id);
    localStorage.setItem('breath_presets', JSON.stringify(customOnly));
    const fullList = [...DEFAULT_BREATH_PRESETS, ...customOnly];
    setBreathPresetsList(fullList);
    if (deckPreviewId === id) {
      setDeckPreviewId(fullList[0].id);
    }
    setToast({ message: 'Preset Deleted', visible: true });
    setTimeout(() => setToast(t => ({...t, visible: false})), 1500);
  };

  const handleSwipeLens = useCallback((direction: 'PREV' | 'NEXT') => { 
      if (!physicsEngine) return;
      const modes = VISUALIZER_MODES; 
      const currentIndex = modes.indexOf(physicsEngine.activePhysicsMode); 
      let nextIndex = direction === 'NEXT' ? currentIndex + 1 : currentIndex - 1; 
      if (nextIndex >= modes.length) nextIndex = 0; 
      if (nextIndex < 0) nextIndex = modes.length - 1; 
      
      const nextMode = modes[nextIndex];
      const newMods = physicsEngine.setMode(nextMode);
      controller.modulation.setModulations(newMods);

      const displayName = VISUALIZER_PLUGINS[nextMode]?.name || nextMode.replace(/_/g, ' ');
      setToast({ message: displayName, visible: true }); 
      setTimeout(() => setToast(t => ({...t, visible: false})), 1500); 
  }, [physicsEngine, controller.modulation]);

  const getCurrentBreathPresetName = () => {
      const match = DEFAULT_BREATH_PRESETS.find(p => Math.abs(p.config.inhale - controller.temporal.breathConfig.inhale) < 0.1 && Math.abs(p.config.holdIn - controller.temporal.breathConfig.holdIn) < 0.1 && Math.abs(p.config.exhale - controller.temporal.breathConfig.exhale) < 0.1 && Math.abs(p.config.holdOut - controller.temporal.breathConfig.holdOut) < 0.1 );
      return match ? match.name : "Custom Cycle";
  };

  const handlePackageSelect = (pkg: HarmonicPackage) => {
      if (pkg.stacksToUnmute && pkg.stacksToUnmute.length > 0) {
          const newStackMutes = { ...controller.audio.stackMutes };
          Object.keys(newStackMutes).forEach(k => newStackMutes[k] = true);
          pkg.stacksToUnmute.forEach(key => newStackMutes[key] = false);
          controller.audio.setStackMutes(newStackMutes);
      }
      if (pkg.channelsToUnmute && pkg.channelsToUnmute.length > 0) {
          controller.audio.setMutes((prev: Record<string, boolean>) => {
              const next = { ...prev };
              UNIVERSAL_CHANNELS.forEach(ch => next[ch.id] = true);
              pkg.channelsToUnmute!.forEach(id => next[id] = false);
              return next;
          });
      }
      if (pkg.visualMode && physicsEngine) {
          const preset = physicsEngine.physicsLibrary.find((p: Record<string, unknown>) => p.name === pkg.visualMode || p.id === pkg.visualMode);
          if (preset) {
              const loaded = physicsEngine.loadPreset(preset.id as string);
              if (loaded) controller.modulation.setModulations(loaded.modulations || {});
          } else {
              const newMods = physicsEngine.setMode(pkg.visualMode);
              controller.modulation.setModulations(newMods);
          }
          setToast({ message: `${pkg.name} Loaded`, visible: true });
          setTimeout(() => setToast(t => ({...t, visible: false})), 2000);
      }
      if (pkg.breathConfig) controller.temporal.setBreathConfig((prev: Record<string, unknown>) => ({ ...prev, ...pkg.breathConfig }));
      if (pkg.physicsConfig && physicsEngine) physicsEngine.setLatticeConfig((prev: Record<string, unknown>) => ({ ...prev, ...pkg.physicsConfig }));
      if (pkg.immersionConfig) controller.atmosphere.setImmersionConfig((prev: Record<string, unknown>) => ({ ...prev, ...pkg.immersionConfig }));
      if (pkg.entrainmentFreq) controller.temporal.handleGlobalEntrainmentChange(pkg.entrainmentFreq);
      if (pkg.customFrequencies) {
          setCustomFrequencies(prev => ({
              ...prev,
              ...pkg.customFrequencies
          }));
          if (controller.loopDataRef && controller.loopDataRef.current) {
              controller.loopDataRef.current.customFrequencies = {
                  ...(controller.loopDataRef.current.customFrequencies || {}),
                  ...pkg.customFrequencies
              };
          }
      }
  };

  return (
      <div className="absolute inset-0 flex flex-col bg-[#050505] text-white font-sans overflow-hidden border border-white/10 max-w-full" style={{ fontFamily: uiConfig.fontTheme === 'SPIRITUAL' ? 'Cinzel, serif' : uiConfig.fontTheme === 'CYBER' ? 'Share Tech Mono, monospace' : 'Space Grotesk, sans-serif' }}>
          
          {/* TOP HEADER WITH AUDIO MIXER CONTROLS & VISUALIZER FULLSCREEN BUTTONS */}
          <TunerTopHeader
              uiConfig={uiConfig}
              isAudioMixerOpen={isAudioMixerOpen}
              onToggleAudioMixer={() => setIsAudioMixerOpen(!isAudioMixerOpen)}
              onCloseAudioMixer={() => setIsAudioMixerOpen(false)}
              controller={controller}
              onOpenBreathArchitect={() => setShowBreathSheet(true)}
              isPolyvagalModalOpen={isPolyvagalModalOpen}
              onTogglePolyvagalModal={() => setIsPolyvagalModalOpen(!isPolyvagalModalOpen)}
              isExperienceActive={isExperienceActive}
              isExperiencePaused={isExperiencePaused}
              isMasterPlaying={isMasterActive && !isMasterPaused}
              isMasterPaused={isMasterPaused}
              onToggleMasterPlay={handleToggleMasterPlay}
              activeExperience={activeExperience}
              activeBlockIndex={activeBlockIndex}
              blockProgress={blockProgress}
              currentExpCycle={currentExpCycle}
              onTogglePlayExperience={handleTogglePlayExperience}
              onStopExperience={handleStopExperience}
              isExperienceModalOpen={isExperienceModalOpen}
              onToggleExperienceModal={() => setIsExperienceModalOpen(!isExperienceModalOpen)}
              isVisualizerImmersion={isVisualizerImmersion}
              onToggleVisualizerImmersion={toggleVisualizerImmersion}
              viewMode={props.viewMode}
              onToggleViewMode={props.onToggleViewMode}
              onOpenStyleEditor={props.onOpenStyleEditor}
              showStyleEditor={props.showStyleEditor}
              onOpenInfo={props.onOpenInfo}
              starterExperiences={STARTER_EXPERIENCES}
          />
          
          <div className="flex-1 relative min-h-0 flex flex-col w-full max-w-full">
              <div className="flex-1 relative flex flex-col min-h-0 overflow-hidden">
                  
                  {physicsEngine && (
                      <ErrorBoundary moduleName="Visualizer Engine">
                          <VisualizerCanvas 
                              lattice={physicsEngine}
                              physics={physicsEngine}
                              latticeConfig={physicsEngine.latticeConfig || {}}
                              physicsConfig={physicsEngine.latticeConfig || {}}
                              atmosphere={controller.atmosphere}
                              temporal={controller.temporal}
                              audio={controller.audio}
                              audioEnabled={controller.audioSys.audioEnabled}
                              isPowered={props.isPowered || false}
                              isMasterPaused={isMasterPaused}
                              updateAudio={controller.audioSys.updateAudio}
                              triggerHeartPulse={controller.audioSys.triggerHeartPulse}
                              toggleAudio={controller.toggleAudio}
                              loopDataRef={controller.loopDataRef}
                              onSwipeLeft={() => handleSwipeLens('NEXT')}
                              onSwipeRight={() => handleSwipeLens('PREV')}
                              onDragLeft={(dy) => physicsEngine.setLatticeConfig((prev: Record<string, unknown>) => ({...prev, force: Math.max(0.5, Math.min(3.0, ((prev.force as number) || 1.0) + (dy * 0.01)))}))}
                              onDragRight={(dy) => controller.audio.setBaseAperture((prev: number) => Math.max(0, Math.min(100, prev + (dy * 0.5))))}
                              onCenterTap={() => {
                                  const currentModePresets = physicsEngine.physicsLibrary.filter((p: Record<string, unknown>) => p.mode === physicsEngine.activePhysicsMode);
                                  if (currentModePresets.length === 0) return;
                                  const currentIndex = currentModePresets.findIndex((p: Record<string, unknown>) => p.id === physicsEngine.activePhysicsPresetId);
                                  const nextIndex = (currentIndex + 1) % currentModePresets.length;
                                  const nextPreset = currentModePresets[nextIndex];
                                  const loadedMods = physicsEngine.loadPreset(nextPreset.id as string);
                                  if(loadedMods) controller.modulation.setModulations(loadedMods.modulations || {});
                                  setToast({ message: nextPreset.name as string, visible: true });
                                  setTimeout(() => setToast(t => ({...t, visible: false})), 1500);
                              }} 
                              layoutConfig={{ mandala: currentLayout.mandala, pacer: currentLayout.pacer }}
                              sensorMode={props.sensorMode}
                              telemetry={controller.audioSys.telemetry} 
                              bus={controller.bus}
                          />
                      </ErrorBoundary>
                  )}

                  {/* Visualizer Immersion Floating Exit Button & Experience HUD */}
                  <ImmersionExperienceOverlay
                      isVisualizerImmersion={isVisualizerImmersion}
                      isImmersionHudVisible={isImmersionHudVisible}
                      onExitImmersion={() => toggleVisualizerImmersion(false)}
                      isExperienceActive={isExperienceActive}
                      isExperiencePaused={isExperiencePaused}
                      activeExperience={activeExperience}
                      activeBlockIndex={activeBlockIndex}
                      blockProgress={blockProgress}
                      currentExpCycle={currentExpCycle}
                      onTogglePlayExperience={(exp) => handleTogglePlayExperience(exp)}
                      onStopExperience={handleStopExperience}
                      onOpenDesigner={() => {
                          toggleVisualizerImmersion(false);
                          setIsExperienceModalOpen(true);
                      }}
                  />

                  {/* Left / Right Lens Carousel Arrows */}
                  <button onClick={() => handleSwipeLens('PREV')} className={`absolute z-30 flex items-center justify-center transition-opacity group ${isVisualizerImmersion ? 'opacity-0 pointer-events-none' : 'opacity-30 hover:opacity-100'}`} style={{ left: `${currentLayout.sideNav.x}rem`, top: `calc(50% + ${currentLayout.sideNav.y}rem)`, transform: `translate(0, -50%) scale(${currentLayout.sideNav.scale})`, opacity: isVisualizerImmersion ? 0 : currentLayout.sideNav.opacity * 0.3, pointerEvents: (isVisualizerImmersion || currentLayout.sideNav.opacity === 0) ? 'none' : 'auto' }}><ChevronLeft size={32} className="text-white group-hover:text-cyan-400 transition-colors drop-shadow-lg" /></button>
                  <button onClick={() => handleSwipeLens('NEXT')} className={`absolute z-30 flex items-center justify-center transition-opacity group ${isVisualizerImmersion ? 'opacity-0 pointer-events-none' : 'opacity-30 hover:opacity-100'}`} style={{ right: `${currentLayout.sideNav.x}rem`, top: `calc(50% + ${currentLayout.sideNav.y}rem)`, transform: `translate(0, -50%) scale(${currentLayout.sideNav.scale})`, opacity: isVisualizerImmersion ? 0 : currentLayout.sideNav.opacity * 0.3, pointerEvents: (isVisualizerImmersion || currentLayout.sideNav.opacity === 0) ? 'none' : 'auto' }}><ChevronRight size={32} className="text-white group-hover:text-cyan-400 transition-colors drop-shadow-lg" /></button>

                  {/* Top Deck Tuning Controls (Pulse, Heartbeat, Composer Matrix, Pacer, Crystal, Tones) */}
                  <TuningControlsDeck
                      controller={controller}
                      uiConfig={uiConfig}
                      isVisualizerImmersion={isVisualizerImmersion}
                      topButtonsLayout={currentLayout.topButtons}
                      uiX={currentLayout.uiX}
                      bpm={props.bpm}
                      isProgressionActive={isProgressionActive}
                      currentProgressionObj={currentProgressionObj}
                      currentChordIndex={currentChordIndex}
                      activeColorWheelId={activeColorWheelId}
                      onSelectColorWheel={(id) => {
                          setActiveColorWheelId(id);
                          setActiveColorWheelIdState(id);
                      }}
                      onOpenBreathSheet={() => {
                          toggleVisualizerImmersion(false);
                          setShowBreathSheet(true);
                      }}
                      onShowToast={(message, durationMs = 1200) => {
                          setToast({ message, visible: true });
                          setTimeout(() => setToast(t => ({ ...t, visible: false })), durationMs);
                      }}
                  />

                  <div className={`absolute z-40 pointer-events-auto bg-zinc-950/90 backdrop-blur-md border border-white/10 rounded-full px-1.5 sm:px-2.5 py-1 flex items-center gap-0.5 sm:gap-1 shadow-lg transition-all duration-300 max-w-[96vw] sm:max-w-none ${isVisualizerImmersion ? 'opacity-0 pointer-events-none' : 'opacity-100'}`} style={{ bottom: `${currentLayout.pill.y}rem`, left: '50%', transform: `translate(-50%, 0) translate(${currentLayout.pill.x}rem, 0) translateX(${currentLayout.uiX}rem) scale(${currentLayout.pill.scale})`, opacity: isVisualizerImmersion ? 0 : currentLayout.pill.opacity, pointerEvents: (isVisualizerImmersion || currentLayout.pill.opacity === 0) ? 'none' : 'auto' }}>
                      <TunerBottomPill
                          binauralFreq={controller.temporal.binauralFreqs['UNIVERSAL'] || 8.0}
                          isFractalSync={!!controller.atmosphere.immersionConfig.isFractalSync}
                          pulseMode={controller.atmosphere.immersionConfig?.pulseMode || 'BINAURAL'}
                          activeLayers={resolveActiveLayers(controller.atmosphere.immersionConfig)}
                          isLayersDropdownOpen={isLayersDropdownOpen}
                          onToggleLayersDropdown={() => {
                              setIsLayersDropdownOpen(!isLayersDropdownOpen);
                              setIsFreqDropdownOpen(false);
                              setIsToneArrayDropdownOpen(false);
                          }}
                          onCloseLayersDropdown={() => setIsLayersDropdownOpen(false)}
                          onToggleLayer={(layer: EntrainmentLayer) => {
                              const current = resolveActiveLayers(controller.atmosphere.immersionConfig);
                              const next = current.includes(layer)
                                  ? current.filter(l => l !== layer)
                                  : [...current, layer];
                              if (next.length === 0) return;
                              const nextMode = next.length > 1 ? 'HYBRID' : (next[0] === 'isochronic' ? 'ISOCHRONIC' : next[0] === 'monaural' ? 'MONAURAL' : 'BINAURAL');
                              controller.atmosphere.setImmersionConfig((prev: Record<string, unknown>) => ({
                                  ...prev,
                                  activeLayers: next,
                                  pulseMode: nextMode
                              }));
                          }}
                          isConjugatePhase={!!controller.atmosphere.immersionConfig?.isConjugatePhase}
                          onToggleConjugatePhase={(val: boolean) => {
                              controller.atmosphere.setImmersionConfig((prev: Record<string, unknown>) => ({ ...prev, isConjugatePhase: val }));
                          }}
                          isochronicHardEdge={!!controller.atmosphere.immersionConfig?.isochronicHardEdge}
                          onToggleIsochronicHardEdge={(val: boolean) => {
                              controller.atmosphere.setImmersionConfig((prev: Record<string, unknown>) => ({ ...prev, isochronicHardEdge: val }));
                          }}
                          isPACGated={controller.atmosphere.immersionConfig?.isPACGated !== false}
                          onTogglePACGated={(val: boolean) => {
                              controller.atmosphere.setImmersionConfig((prev: Record<string, unknown>) => ({ ...prev, isPACGated: val }));
                          }}
                          activeToneArray={activeToneArray}
                          totalActiveTones={totalActiveTones}
                          musicPitchRef={musicPitchRef}
                          musicTemperament={musicTemperament}
                          isProgressionActive={isProgressionActive}
                          isFreqDropdownOpen={isFreqDropdownOpen}
                          isToneArrayDropdownOpen={isToneArrayDropdownOpen}
                          customBinauralInput={customBinauralInput}
                          presets={PRESETS}
                          onToggleFreqDropdown={() => {
                              setIsFreqDropdownOpen(!isFreqDropdownOpen);
                              setIsLayersDropdownOpen(false);
                              setIsToneArrayDropdownOpen(false);
                          }}
                          onCloseFreqDropdown={() => setIsFreqDropdownOpen(false)}
                          onToggleToneArrayDropdown={() => {
                              setIsToneArrayDropdownOpen(!isToneArrayDropdownOpen);
                              setIsLayersDropdownOpen(false);
                              setIsFreqDropdownOpen(false);
                          }}
                          onCloseToneArrayDropdown={() => setIsToneArrayDropdownOpen(false)}
                          onCustomBinauralInputChange={(v) => setCustomBinauralInput(v)}
                          onApplyCustomBinauralFreq={applyCustomBinauralFreq}
                          onSelectEntrainmentMode={(freq) => controller.temporal.handleGlobalEntrainmentChange(freq)}
                          onTogglePulseMode={() => controller.atmosphere.setImmersionConfig((prev: Record<string, unknown>) => ({...prev, pulseMode: prev.pulseMode === 'ISOCHRONIC' ? 'BINAURAL' : 'ISOCHRONIC'}))}
                          onSelectToneArray={(pkgId) => {
                              setActiveToneArray(pkgId);
                              if (pkgId === 'KNOB' && controller.audio.mutes['UNIVERSAL_799'] !== false) {
                                  controller.audio.handleMuteToggle('UNIVERSAL_799');
                              }
                          }}
                          onOpenCustomToneModal={() => setIsCustomToneModalOpen(true)}
                          onOpenMusicTuningModal={() => setIsMusicTuningModalOpen(true)}
                          onOpenProgressionModal={() => setIsProgressionModalOpen(true)}
                          onClearAllTones={clearAllTones}
                          onToggleFractalSync={() => controller.atmosphere.setImmersionConfig((prev: Record<string, unknown>) => ({...prev, isFractalSync: !prev.isFractalSync}))}
                          getChannelsForPreset={(pkgId) => pkgId === 'CUSTOM' ? customChannels : (pkgId === 'KNOB' ? KNOB_CHANNELS : (pkgId === 'MUSIC_SCALE' ? musicScaleChannels : (PRESETS.find(p => p.id === pkgId)?.channels || UNIVERSAL_CHANNELS)))}
                          isChannelActive={(chId) => !dockMutes[chId]}
                      />
                  </div>

                  {/* Toast Notification positioned strictly above the entrainment pill */}
                  <ToastNotification 
                      message={toast.message} 
                      visible={toast.visible} 
                      style={{ 
                          bottom: `calc(${currentLayout.pill.y}rem + 2.8rem)`, 
                          left: '50%', 
                          transform: `translate(-50%, 0) translate(${currentLayout.pill.x}rem, 0) translateX(${currentLayout.uiX}rem) scale(${currentLayout.pill.scale})` 
                      }} 
                  />

                  <div className={`absolute left-0 right-0 z-40 pointer-events-auto flex flex-col justify-center items-center pb-2 sm:pb-4 transition-opacity duration-300 ${isVisualizerImmersion ? 'opacity-0 pointer-events-none' : 'opacity-100'}`} style={{ bottom: `${currentLayout.dock.y}rem`, transform: `translate(${currentLayout.dock.x}rem, 0) translateX(${currentLayout.uiX}rem) scale(${currentLayout.dock.scale})`, opacity: isVisualizerImmersion ? 0 : currentLayout.dock.opacity, pointerEvents: (isVisualizerImmersion || currentLayout.dock.opacity === 0) ? 'none' : 'auto' }}>
                      <HarmonicDock
                          activeToneArray={activeToneArray}
                          musicPitchRef={musicPitchRef}
                          musicTemperament={musicTemperament}
                          isProgressionActive={isProgressionActive}
                          onMusicPitchChange={handleMusicPitchChange}
                          onMusicTemperamentChange={handleMusicTemperamentChange}
                          onOpenArchitect={() => setIsMusicTuningModalOpen(true)}
                          onOpenMoods={() => setIsProgressionModalOpen(true)}
                          knobFreq={knobFreq}
                          onKnobFreqChange={handleKnobFreqChange}
                          currentChannels={activeToneArray === 'CUSTOM' ? customChannels : (activeToneArray === 'MUSIC_SCALE' ? musicScaleChannels : (PRESETS.find(p => p.id === activeToneArray)?.channels || UNIVERSAL_CHANNELS))}
                          mutes={dockMutes}
                          chordToneIds={currentChordScaleIds}
                          onToggleMute={(id) => controller.audio.handleMuteToggle(id)}
                          onSoloTone={(id, allChannels) => {
                              controller.audio.setMutes((prev: Record<string, boolean>) => {
                                  const next = { ...prev };
                                  allChannels.forEach(ch => next[ch.id] = true);
                                  next[id] = false;
                                  return next;
                              });
                          }}
                          PianoKeyItem={PianoKeyItem}
                          HarmonicDockItem={HarmonicDockItem}
                      />
                  </div>
              </div>

              {showSystemMonitor && (
                  <div className="absolute top-16 left-4 right-4 z-40 animate-in slide-in-from-top-4 fade-in duration-300 pointer-events-none">
                      <div className="pointer-events-auto">
                          <SystemMonitor telemetry={controller.audioSys.telemetry} uiConfig={uiConfig} isAudioEnabled={controller.audioSys.audioEnabled} />
                          <div className="flex justify-end mt-2"><button onClick={() => setShowSystemMonitor(false)} className="text-[10px] uppercase text-slate-500 hover:text-white underline">Close Monitor</button></div>
                      </div>
                  </div>
              )}
          </div>

          {!isVisualizerImmersion && (
              <div className="shrink-0 z-50 bg-black border-t border-white/10 flex flex-col pb-safe transition-transform duration-200 w-full" style={{ transform: `translateY(${currentLayout.footerY}px)`, opacity: currentLayout.meter.opacity, pointerEvents: currentLayout.meter.opacity === 0 ? 'none' : 'auto' }}>
                  <div className="flex justify-between items-center px-4 py-2 border-b border-white/10">
                      <div className="flex items-center gap-2 group cursor-pointer hover:bg-white/5 px-2 py-1 rounded transition-colors shrink-0" onClick={() => { setShowBreathSheet(!showBreathSheet); setDeckPreviewId(controller.activePresetId || 'resonance'); }}>
                          <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500">
                              {isExperienceActive ? "Sequence:" : "Pattern:"}
                          </span>
                          <span className="text-xs font-bold transition-colors truncate max-w-[120px] sm:max-w-[240px]" style={{ color: getPacerColors(controller.temporal.breathConfig?.colorScheme, controller.temporal.breathConfig?.customColor).accent }}>
                              {isExperienceActive 
                                  ? `${activeExperience?.name || 'Experience'}: ${activeExperience?.blocks[activeBlockIndex]?.label || 'Phase ' + (activeBlockIndex + 1)} (${activeExperience?.blocks[activeBlockIndex]?.breathPhase || 'INHALE'})` 
                                  : getCurrentBreathPresetName()
                              }
                          </span>
                          <ChevronDown size={12} className="group-hover:text-white shrink-0" style={{ color: getPacerColors(controller.temporal.breathConfig?.colorScheme, controller.temporal.breathConfig?.customColor).accent }} />
                      </div>
                      <div className="flex items-center gap-3 shrink-0">
                           <span className="hidden sm:block text-[9px] font-bold uppercase tracking-widest text-slate-600">
                               {isExperienceActive ? `${Math.round(blockProgress * 100)}% PHASE` : "UNIVERSAL MODE"}
                           </span>
                           <div className="relative">
                                <button onClick={() => setShowHarmonicMenu(true)} className="flex items-center gap-2 px-2 py-1 rounded hover:bg-white/5 transition-colors group"><Globe size={12} className="text-slate-500 group-hover:text-white" /><span className="text-[10px] font-bold uppercase tracking-widest text-slate-400 group-hover:text-cyan-400 text-right min-w-[60px]">PACKAGES</span></button>
                           </div>
                      </div>
                  </div>
                  <div className="w-full h-8 relative bg-slate-900 flex justify-center overflow-hidden">
                      <div style={{ width: `${currentLayout.meterScale * 100}%`, transform: `translate(${currentLayout.meter.x}rem, ${currentLayout.meter.y}rem) scale(${currentLayout.meter.scale})` }} className="h-full relative origin-bottom">
                          <TideMeter 
                              config={controller.temporal.breathConfig} 
                              uiConfig={uiConfig} 
                              isActive={controller.temporal.isBreathActive || isExperienceActive} 
                              isPaused={isMasterPaused}
                              startTime={controller.temporal.breathStartTime}
                              overrideProgress={isExperienceActive ? blockProgress : undefined}
                              overridePhase={isExperienceActive ? activeSubPhase : undefined}
                              experienceBlocks={isExperienceActive ? activeExperience?.blocks : undefined}
                              activeBlockIndex={isExperienceActive ? activeBlockIndex : undefined}
                          />
                      </div>
                  </div>
              </div>
          )}

          <BreathArchitectSheet
              isOpen={showBreathSheet}
              onClose={() => setShowBreathSheet(false)}
              breathSheetTab={breathSheetTab}
              onTabChange={(tab) => setBreathSheetTab(tab as any)}
              previewPreset={previewPreset}
              deckPreviewId={deckPreviewId}
              onSelectPreviewPreset={(id) => setDeckPreviewId(id)}
              groupedPresets={groupedPresets}
              onActivatePreset={(preset) => {
                  controller.temporal.setBreathConfig({ ...controller.temporal.breathConfig, ...preset.config });
                  setShowBreathSheet(false);
              }}
              onDeleteCustomPreset={deleteCustomBreathPreset}
              customInhale={customInhale}
              setCustomInhale={setCustomInhale}
              customHoldIn={customHoldIn}
              setCustomHoldIn={setCustomHoldIn}
              customExhale={customExhale}
              setCustomExhale={setCustomExhale}
              customHoldOut={customHoldOut}
              setCustomHoldOut={setCustomHoldOut}
              customPresetTitle={customPresetTitle}
              setCustomPresetTitle={setCustomPresetTitle}
              onSaveCustomPreset={saveCustomBreathPreset}
              onApplyCustomPattern={() => {
                  controller.temporal.setBreathConfig({
                      ...controller.temporal.breathConfig,
                      inhale: customInhale,
                      holdIn: customHoldIn,
                      exhale: customExhale,
                      holdOut: customHoldOut
                  });
                  setShowBreathSheet(false);
                  setToast({ message: `Custom Breath: ${customInhale}-${customHoldIn}-${customExhale}-${customHoldOut}`, visible: true });
                  setTimeout(() => setToast(t => ({...t, visible: false})), 1500);
              }}
              controller={controller}
              uiConfig={uiConfig}
          />

          <CustomToneArrayModal
              isOpen={isCustomToneModalOpen}
              onClose={() => setIsCustomToneModalOpen(false)}
              customChannels={customChannels}
              onUpdateChannel={updateCustomChannel}
              onToggleMute={(channelId) => {
                  controller.audio.setMutes((prev: Record<string, boolean>) => ({
                      ...prev,
                      [channelId]: !prev[channelId]
                  }));
              }}
              onRemoveChannel={removeCustomChannel}
              onAddChannel={addCustomChannel}
              onResetToDefault={resetCustomChannelsToDefault}
              onActivateCustomArray={() => {
                  setActiveToneArray('CUSTOM');
                  setIsCustomToneModalOpen(false);
                  setToast({ message: 'Custom Tone Array Active', visible: true });
                  setTimeout(() => setToast(t => ({...t, visible: false})), 1400);
              }}
              mutes={controller.audio.mutes}
          />

          {showHarmonicMenu && (
              <React.Suspense fallback={null}>
                  <HarmonicPackageMenu isOpen={showHarmonicMenu} onClose={() => setShowHarmonicMenu(false)} onSelect={handlePackageSelect} uiConfig={uiConfig} activeBank={activeToneArray} controller={controller} />
              </React.Suspense>
          )}

          {isMusicTuningModalOpen && (
              <React.Suspense fallback={null}>
                  <MusicalTuningModal
                      isOpen={isMusicTuningModalOpen}
                      onClose={() => setIsMusicTuningModalOpen(false)}
                      pitch={musicPitchRef}
                      onPitchChange={handleMusicPitchChange}
                      temperament={musicTemperament}
                      onTemperamentChange={handleMusicTemperamentChange}
                      octaveShift={musicOctaveShift}
                      onOctaveShiftChange={handleMusicOctaveShiftChange}
                      uiConfig={uiConfig}
                  />
              </React.Suspense>
          )}

          {isProgressionModalOpen && (
              <React.Suspense fallback={null}>
                  <MusicalProgressionModal
                      isOpen={isProgressionModalOpen}
                      onClose={() => setIsProgressionModalOpen(false)}
                      pitch={musicPitchRef}
                      temperament={musicTemperament}
                      octaveShift={musicOctaveShift}
                      onPitchChange={handleMusicPitchChange}
                      onTemperamentChange={handleMusicTemperamentChange}
                      onOpenArchitect={() => setIsMusicTuningModalOpen(true)}
                      isProgressionActive={isProgressionActive}
                      onToggleProgression={handleToggleProgression}
                      activeMood={activeMood}
                      onSelectMood={handleSelectMood}
                      activeProgressionId={activeProgressionId}
                      onSelectProgression={handleSelectProgression}
                      currentChordIndex={currentChordIndex}
                      advanceMode={progressionAdvanceMode}
                      onAdvanceModeChange={setProgressionAdvanceMode}
                      onAdvanceChord={handleAdvanceChord}
                      onPlaySingleChord={handlePlaySingleChord}
                      onSelectChordIndex={handleSelectChordIndex}
                      chordGlideConfig={controller.audio.chordGlideConfig}
                      onChordGlideConfigChange={controller.audio.updateChordGlideConfig}
                      customProgressions={customProgressions}
                      onSaveAndActivateProgression={handleSaveAndActivateProgression}
                      onCustomProgressionsChange={() => setCustomProgressions(loadCustomProgressions())}
                      breathConfig={controller.temporal.breathConfig}
                      isBreathActive={controller.temporal.isBreathActive}
                      onToggleBreathPacer={() => controller.temporal.setIsBreathActive((prev: boolean) => !prev)}
                  />
              </React.Suspense>
          )}

          {isPolyvagalModalOpen && (
              <React.Suspense fallback={null}>
                  <PolyvagalModal
                      isOpen={isPolyvagalModalOpen}
                      onClose={() => setIsPolyvagalModalOpen(false)}
                      config={controller.audio.polyvagalConfig}
                      onUpdateConfig={controller.audio.updatePolyvagalConfig}
                      onResetSession={(dur?: number) => {
                          if (controller.audioSys?.resetPolyvagalSession) {
                              controller.audioSys.resetPolyvagalSession(dur);
                          }
                      }}
                      isAudioEnabled={controller.audioSys.audioEnabled}
                      onEnableAudio={() => {
                          if (!controller.audioSys.audioEnabled) {
                              controller.toggleAudio();
                          }
                      }}
                      uiConfig={uiConfig}
                  />
              </React.Suspense>
          )}

          {isExperienceModalOpen && (
              <React.Suspense fallback={null}>
                  <ExperienceDesignerModal
                      isOpen={isExperienceModalOpen}
                      onClose={() => setIsExperienceModalOpen(false)}
                      currentPitch={musicPitchRef}
                      currentTemperament={musicTemperament}
                      isPlaying={isExperienceActive}
                      isPaused={isExperiencePaused}
                      activeExperienceId={activeExperience?.id}
                      activeBlockIndex={activeBlockIndex}
                      blockProgress={blockProgress}
                      currentCycle={currentExpCycle}
                      totalCycles={activeExperience?.targetCycles || 4}
                      onTogglePlayExperience={handleTogglePlayExperience}
                      onPlayAndImmerse={(exp) => handleTogglePlayExperience(exp, { autoImmerse: true })}
                      onToggleVisualizerImmersion={toggleVisualizerImmersion}
                      onStopExperience={handleStopExperience}
                      onAuditionBlock={handleAuditionBlock}
                      onJumpToBlock={handleJumpToExperienceBlock}
                      onPitchChange={(p) => setMusicPitchRef(p)}
                      onTemperamentChange={(t) => setMusicTemperament(t)}
                      globalEntrainmentFreq={controller.temporal.binauralFreqs['UNIVERSAL'] || 8.0}
                      globalEntrainmentLayers={resolveActiveLayers(controller.atmosphere.immersionConfig)}
                      globalSenticEmotion={controller.temporal.breathConfig?.senticState || 'NO_EMOTION'}
                      globalHeartSyncMode={controller.temporal.kickConfig?.syncMode || 'BREATH'}
                      globalBpm={controller.temporal.kickConfig?.bpm || 60}
                      globalComposerWarp={controller.atmosphere.immersionConfig?.composerWarp || 'LINEAR'}
                      globalTimeCrystalTopology={controller.atmosphere.immersionConfig?.timeCrystalTopology || 'FIBONACCI'}
                      globalTimeCrystalEnabled={!!controller.atmosphere.immersionConfig?.isTimeCrystal}
                      globalPulseStyle={controller.audio.feedbackConfig?.pulseStyle || 'BLACK_SHUTTER'}
                  />
              </React.Suspense>
          )}

          {props.viewMode === 'STUDIO' && (
              <StudioPanelsDrawer
                  dockPosition={dockPosition}
                  uiConfig={uiConfig}
                  physicsEngine={physicsEngine}
                  controller={controller}
                  hasSensors={hasSensors}
                  layoutDebug={layoutDebug}
                  currentLayout={currentLayout}
                  onLayoutChange={handleLayoutChange}
                  onResetLayout={() => {
                      setLayoutDebug(prev => ({ ...prev, profiles: LAYOUT_DEFAULTS }));
                      setToast({ message: 'Grid Reset to Defaults', visible: true });
                      setTimeout(() => setToast(t => ({ ...t, visible: false })), 1500);
                  }}
                  onShowToast={(msg) => {
                      setToast({ message: msg, visible: true });
                      setTimeout(() => setToast(t => ({ ...t, visible: false })), 1500);
                  }}
              />
          )}
          
          {showSaveModal && (<div className="absolute inset-0 bg-black/90 backdrop-blur-md flex justify-center items-start pt-20 z-50"><div className="bg-[#1a1a1e] p-6 rounded-2xl border border-white/10 w-72 shadow-2xl"><h3 className="text-white text-xs font-bold mb-4 uppercase tracking-wider text-center">Save Profile</h3><input type="text" placeholder="e.g. Deep Meditation" className="w-full bg-black/50 border border-white/20 rounded-lg p-3 text-white text-xs mb-4 focus:outline-none focus:border-cyan-400 transition-colors" value={newPresetName} onChange={(e) => setNewPresetName(e.target.value)} autoFocus /><div className="flex items-center gap-3 mb-6 cursor-pointer group p-2 rounded-lg hover:bg-white/5" onClick={() => setIsSaveDefault(!isSaveDefault)}><div className={`w-4 h-4 rounded border flex items-center justify-center transition-colors ${isSaveDefault ? 'bg-cyan-500 border-cyan-500' : 'border-slate-600 group-hover:border-slate-400'}`}>{isSaveDefault && <Check size={10} className="text-black stroke-[3]" />}</div><span className={`text-[10px] font-bold uppercase tracking-wider ${isSaveDefault ? 'text-cyan-400' : 'text-slate-500 group-hover:text-slate-300'}`}>Set as startup default</span></div><div className="flex justify-end gap-3"><button onClick={() => setShowSaveModal(false)} className="px-4 py-2 text-slate-400 hover:text-white text-[10px] uppercase font-bold transition-colors">Cancel</button><button onClick={() => { controller.savePreset(newPresetName, isSaveDefault); setShowSaveModal(false); setNewPresetName(''); }} className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-[10px] uppercase font-bold transition-colors shadow-lg shadow-cyan-900/20">Save</button></div></div></div>)}
      </div>
  );
});