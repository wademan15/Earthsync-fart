import React from 'react';
import { TheKnob } from './TheKnob';
import { TuningTemperament, PresetType, getMerrickColor, HarmonicChannel } from './visuals/shared';
import { Anchor, Layers, Droplet, Activity, Zap, Dna, Heart } from 'lucide-react';

interface HarmonicDockProps {
  activeToneArray: PresetType;
  musicPitchRef?: number;
  musicTemperament?: TuningTemperament;
  isProgressionActive?: boolean;
  onMusicPitchChange?: (pitch: number) => void;
  onMusicTemperamentChange?: (temp: TuningTemperament) => void;
  onOpenArchitect?: () => void;
  onOpenMoods?: () => void;
  knobFreq: number;
  onKnobFreqChange: (freq: number) => void;
  currentChannels: HarmonicChannel[];
  mutes: Record<string, boolean>;
  chordToneIds?: Set<string>;
  onToggleMute: (id: string) => void;
  onSoloTone: (id: string, allChannels: HarmonicChannel[]) => void;
  PianoKeyItem: React.ComponentType<{
    label: string;
    note: string;
    isActive: boolean;
    color: string;
    onClick: () => void;
    onContextMenu: (e: React.MouseEvent) => void;
    isChordTone?: boolean;
    isUserActive?: boolean;
  }>;
  HarmonicDockItem: React.ComponentType<{
    label: string;
    icon: React.ElementType;
    isActive: boolean;
    color: string;
    onClick: () => void;
    onContextMenu: (e: React.MouseEvent) => void;
  }>;
}

export const HarmonicDock: React.FC<HarmonicDockProps> = ({
  activeToneArray,
  knobFreq,
  onKnobFreqChange,
  currentChannels,
  mutes,
  chordToneIds,
  onToggleMute,
  onSoloTone,
  PianoKeyItem,
  HarmonicDockItem
}) => {
  const isPianoArray = activeToneArray === 'GM_SCALE' || activeToneArray === 'MUSIC_SCALE';

  return (
    <div className="flex items-center justify-center w-full max-w-[100vw] sm:max-w-lg px-2">
      <style>{`.no-scrollbar::-webkit-scrollbar { display: none; } .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }`}</style>
      {activeToneArray === 'KNOB' ? (
          <TheKnob
            frequency={knobFreq}
            onChange={onKnobFreqChange}
            isMuted={!!mutes['UNIVERSAL_799']}
            onToggleMute={() => onToggleMute('UNIVERSAL_799')}
          />
        ) : (
          <div
            id="harmonic-dock-scroll"
            className={`flex ${isPianoArray ? 'items-start gap-0' : 'items-center gap-1 sm:gap-3'} overflow-x-auto overflow-y-hidden no-scrollbar px-2 ${isPianoArray ? 'max-w-[92vw] sm:max-w-xl' : 'snap-x snap-mandatory max-w-[90vw] sm:max-w-md'} cursor-grab active:cursor-grabbing`}
            onMouseDown={(e) => {
              const slider = e.currentTarget;
              let isDown = true;
              const startX = e.pageX - slider.offsetLeft;
              const scrollLeft = slider.scrollLeft;
              const onMouseUp = () => {
                isDown = false;
                slider.classList.remove('active');
                window.removeEventListener('mouseup', onMouseUp);
                window.removeEventListener('mousemove', onMouseMove);
              };
              const onMouseMove = (ev: MouseEvent) => {
                if (!isDown) return;
                ev.preventDefault();
                const x = ev.pageX - slider.offsetLeft;
                const walk = (x - startX) * 2;
                slider.scrollLeft = scrollLeft - walk;
              };
              window.addEventListener('mouseup', onMouseUp);
              window.addEventListener('mousemove', onMouseMove);
            }}
          >
            {currentChannels.map((channel, i) => (
              <div key={channel.id} className={isPianoArray ? 'shrink-0 flex items-start' : 'snap-center shrink-0'}>
                {isPianoArray ? (
                  <PianoKeyItem
                    label={channel.noteLabel || channel.name}
                    note={channel.noteLabel || 'C'}
                    isActive={!mutes[channel.id] || (chordToneIds ? chordToneIds.has(channel.id) : false)}
                    isChordTone={chordToneIds ? chordToneIds.has(channel.id) : false}
                    isUserActive={!mutes[channel.id]}
                    color={getMerrickColor(channel.freq)}
                    onClick={() => onToggleMute(channel.id)}
                    onContextMenu={(e: React.MouseEvent) => {
                      e.preventDefault();
                      onSoloTone(channel.id, currentChannels);
                    }}
                  />
                ) : (
                  <HarmonicDockItem
                    label={channel.noteLabel || channel.name.split(' ')[1] || channel.name}
                    icon={i === 0 ? Anchor : i === 1 ? Layers : i === 2 ? Droplet : i === 3 ? Activity : i === 4 ? Zap : i === 5 ? Dna : Heart}
                    isActive={!mutes[channel.id]}
                    color={getMerrickColor(channel.freq)}
                    onClick={() => onToggleMute(channel.id)}
                    onContextMenu={(e: React.MouseEvent) => {
                      e.preventDefault();
                      onSoloTone(channel.id, currentChannels);
                    }}
                  />
                )}
              </div>
            ))}
          </div>
        )}
      </div>
  );
};
