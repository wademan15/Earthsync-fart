
import { HRMData } from '../types';

/**
 * STRICT CUSTOMS CONTROL
 * Validates and sanitizes incoming Bluetooth Heart Rate Data.
 * Returns null if the packet is malformed or physiologically impossible.
 */
export const sanitizeHeartRate = (
    value: DataView, 
    currentTimestamp: number
): HRMData | null => {
    try {
        // 1. Structural Integrity Check
        if (!value || value.byteLength < 2) {
            console.warn("[SANITIZER] Packet too short/empty");
            return null;
        }

        // 2. Parse Flags (The standard BLE Protocol)
        const flags = value.getUint8(0);
        const rate16Bits = flags & 0x1;
        const rrPresent = flags & 0x10;
        
        // 3. Extract BPM
        let bpm = 0;
        let offset = 1;

        if (rate16Bits) {
            if (value.byteLength < offset + 2) return null; // Safety check
            bpm = value.getUint16(offset, true);
            offset += 2;
        } else {
            if (value.byteLength < offset + 1) return null; // Safety check
            bpm = value.getUint8(offset);
            offset += 1;
        }

        // 4. Physiological Reality Check (The "Air Gap")
        // No human has a HR of 0 or > 250 while sitting down.
        // Sensors often glitch and send 0 or 255.
        if (bpm < 30 || bpm > 250) {
            console.warn(`[SANITIZER] Rejected Physiological Impossibility: BPM ${bpm}`);
            return null;
        }

        // 5. Handle Energy Expended (Skip if present)
        const energyPresent = flags & 0x8;
        if (energyPresent) {
            if (value.byteLength < offset + 2) return null;
            offset += 2;
        }

        // 6. Extract and Validate RR Intervals
        const rrs: number[] = [];
        if (rrPresent) {
            while (offset + 1 < value.byteLength) {
                const rrRaw = value.getUint16(offset, true);
                offset += 2;
                
                // Convert 1024-tick units to Milliseconds
                const rrMs = (rrRaw / 1024.0) * 1000.0;

                // RR Validation:
                // An RR interval of 100ms = 600 BPM. Impossible.
                // An RR interval of 4000ms = 15 BPM. Unlikely for this use case.
                if (rrMs > 250 && rrMs < 3000) {
                    rrs.push(rrMs);
                } else {
                    // console.warn(`[SANITIZER] Rejected Artifact RR: ${rrMs.toFixed(1)}ms`);
                }
            }
        }

        // 7. Final Payload Construction
        return {
            bpm,
            rrIntervals: rrs,
            timestamp: currentTimestamp
        };

    } catch (error) {
        console.error("[SANITIZER] CRITICAL PARSE FAILURE", error);
        return null;
    }
};

/**
 * ML INFERENCE GUARD
 * Prevents the ML engine from seeing NaN or Infinity
 */
export const sanitizeHemodynamicInput = (
    ppgBuffer: number[], 
    stiffness: number, 
    quality: number
) => {
    // If signal quality is trash, don't waste CPU on ML
    if (quality < 0.5) return null;
    if (!Number.isFinite(stiffness)) return null;
    if (ppgBuffer.some(v => !Number.isFinite(v))) return null;
    
    return {
        buffer: ppgBuffer,
        stiffness,
        quality
    };
};
