
// STATUS: OPTIMIZED FOR EARTHSYNC
// A lightweight Phase Oscillator with Autonomic Modulation.
// Replaces the heavy McSharry-Clifford model for CPU efficiency.

export interface SimulationState {
    voltage: number;
    trajectory: { x: number, y: number, z: number };
    bpm: number;
    phase: number;
    acc: { x: number, y: number, z: number }; 
    ppg: { val: number, redness: number };
}

export class BioSimEngine {
    // State Vectors
    private theta: number = 0; // Phase angle
    
    // Autonomic Drivers
    private breathPhase: number = 0;
    private mayerPhase: number = 0;

    // Configuration
    private baseHr: number = 60;
    private sampleRate: number = 130;
    private isCoherenceLocked: boolean = false;
    
    // Dynamics
    private rsaGain: number = 12;   // Amplitude of RSA (BPM swing)
    private mayerGain: number = 4;  // Amplitude of Mayer waves (BPM swing)

    // Resonance Lock (Aether Mode)
    private isResonanceLocked: boolean = false;
    private resonanceBpm: number = 60;

    constructor(sampleRate: number = 130) {
        this.sampleRate = sampleRate;
    }

    public nextSample(dt: number): SimulationState {
        // 1. Autonomic Modulation (HRV)
        // RSA: 0.25 Hz (15 breaths/min)
        // Mayer: 0.10 Hz (Baroreflex)
        this.breathPhase += 2 * Math.PI * 0.25 * dt;
        this.mayerPhase += 2 * Math.PI * 0.10 * dt;

        // Instantaneous Heart Rate
        let instHr = this.baseHr;

        if (this.isResonanceLocked) {
            // METRONOME PHYSICS
            // Completely override RSA/Mayer with the calculated resonance BPM.
            // We add a tiny bit of micro-jitter to prevent it from sounding robotic,
            // but effectively it's locked to the grid.
            instHr = this.resonanceBpm + ((Math.random() - 0.5) * 0.5);
        } else {
            let rsaMod = 0;
            let mayerMod = 0;

            if (this.isCoherenceLocked) {
                // LOCK MODE: Pure 0.1 Hz (Mayer) Sine Wave
                mayerMod = Math.sin(this.mayerPhase) * (this.mayerGain * 1.5); 
                rsaMod = 0;
            } else {
                // NATURAL MODE: Mix of RSA and Mayer
                rsaMod = Math.sin(this.breathPhase) * this.rsaGain;
                mayerMod = Math.sin(this.mayerPhase) * this.mayerGain;
            }
            instHr += rsaMod + mayerMod;
        }

        // 2. Angular Velocity (dTheta/dt)
        const angularVelocity = (2 * Math.PI * instHr) / 60;
        
        this.theta += angularVelocity * dt;
        
        // Wrap Theta to -PI..PI
        if (this.theta > Math.PI) this.theta -= 2 * Math.PI;

        // 3. Simplified Voltage Output (Visual Trigger Only)
        let voltage = 0;
        if (Math.abs(this.theta) < 0.2) {
             // Simple Gaussian Spike: A * exp(-x^2 / 2c^2)
             voltage = 1.2 * Math.exp( -(this.theta * this.theta) / 0.02 );
        }

        // 4. Simplified Sensors
        const accX = (this.isCoherenceLocked || this.isResonanceLocked)
            ? Math.sin(this.mayerPhase) * 0.1 
            : Math.sin(this.breathPhase) * 0.1;
        
        const ppgVal = (Math.sin(this.theta - 1.5) + 1) * 50 + (Math.random() * 2);

        return {
            voltage: voltage,
            trajectory: { x: Math.cos(this.theta), y: Math.sin(this.theta), z: voltage },
            bpm: instHr,
            phase: this.theta,
            acc: { 
                x: accX, 
                y: 0.98, // Stationary Gravity Vector
                z: 0 
            },
            ppg: { val: ppgVal, redness: 0.95 }
        };
    }

    public setBaseHeartRate(bpm: number) {
        this.baseHr = bpm;
    }

    public setCoherenceMode(locked: boolean) {
        this.isCoherenceLocked = locked;
    }

    /**
     * Locks the heart rate to an integer harmonic of the breath cycle.
     * Effectively turns the heart into a polyrhythmic metronome.
     * @param breathCycleDurationSeconds Total duration of inhale+hold+exhale+hold
     */
    public setResonanceLock(breathCycleDurationSeconds: number) {
        if (breathCycleDurationSeconds <= 0) {
            this.isResonanceLocked = false;
            return;
        }

        this.isResonanceLocked = true;
        
        // Target roughly 60 BPM (1 beat per second) as the base
        // But adjust it so it perfectly divides the breath cycle.
        // Example: Breath 6s. 6 beats fits perfectly. BPM = 60.
        // Example: Breath 5.5s. 60 BPM is not perfect. 
        // Closest integer beat count: 5.5s * (60/60) = 5.5 beats. Round to 6 beats.
        // New BPM = (6 beats / 5.5s) * 60 = 65.45 BPM.
        
        const targetBpm = 65; // Center point
        const cycleFreq = 60 / breathCycleDurationSeconds; // Breaths per minute
        
        // Find integer multiplier (beats per breath) that results in closest BPM to target
        const beatsPerBreath = Math.round(targetBpm / cycleFreq);
        
        this.resonanceBpm = cycleFreq * beatsPerBreath;
        // console.log(`[BioSim] Resonance Lock: Breath=${breathCycleDurationSeconds}s, Beats/Cycle=${beatsPerBreath}, BPM=${this.resonanceBpm.toFixed(2)}`);
    }
}
